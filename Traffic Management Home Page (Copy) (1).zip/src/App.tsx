import { useState } from 'react';
import { Moon, Sun } from 'lucide-react';
import { BottomNav } from './components/BottomNav';
import SplashScreen from './pages/SplashScreen';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { HomePage } from './pages/HomePage';
import DashboardPage from './pages/DashboardPage';
import TrafficMapPage from './pages/TrafficMapPage';
import PredictionPage from './pages/PredictionPage';
import ViolationsPage from './pages/ViolationsPage';
import AlertsPage from './pages/AlertsPage';
import CamerasPage from './pages/CamerasPage';
import ReportsPage from './pages/ReportsPage';
import ProfilePage from './pages/ProfilePage';
import { ThemeProvider, useTheme } from './contexts/ThemeContext';
import { NotificationDrawer } from './components/NotificationDrawer';
import { Toaster } from './components/ui/sonner';
import logoImage from 'figma:asset/7d2f3bc2a6f01951ff61d51e3f541feb142273c0.png';

// Define all page types
export type PageType = 'splash' | 'login' | 'signup' | 'home' | 'dashboard' | 'map' | 'predictions' | 'violations' | 'alerts' | 'cameras' | 'reports' | 'profile';

function AppContent() {
  const [currentPage, setCurrentPage] = useState<PageType>('splash');
  const { isDark, toggleTheme } = useTheme();

  const navigateTo = (page: PageType) => {
    setCurrentPage(page);
  };

  // Show splash, login, or signup without main app layout
  if (currentPage === 'splash') {
    return <SplashScreen onComplete={() => navigateTo('login')} />;
  }

  if (currentPage === 'login') {
    return <LoginPage onLogin={() => navigateTo('home')} onNavigateToSignup={() => navigateTo('signup')} isDark={isDark} />;
  }

  if (currentPage === 'signup') {
    return <SignupPage onSignup={() => navigateTo('home')} onNavigateToLogin={() => navigateTo('login')} isDark={isDark} />;
  }

  // Main app layout with header and bottom nav
  return (
    <div className={`min-h-screen flex flex-col ${isDark ? 'bg-[#121212]' : 'bg-[#f5f7fa]'}`}>
      {/* Header */}
      <header className={`border-b sticky top-0 z-40 ${
        isDark ? 'bg-[#1e1e1e] border-[#333333]' : 'bg-white border-[#e0e0e0]'
      }`}
        style={{ boxShadow: 'var(--shadow-md)' }}
      >
        <div className="max-w-lg mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-3 cursor-pointer" onClick={() => navigateTo('home')}>
              <img 
                src={logoImage} 
                alt="GATYAH Logo" 
                className="w-10 h-10 object-contain"
              />
              <div>
                <div className={`text-lg ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  Gyatah
                </div>
                <div className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                  Smart Traffic Management
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center gap-2">
              {/* Dark Mode Toggle */}
              <button 
                onClick={toggleTheme}
                className={`p-2 rounded-lg transition-colors ${
                  isDark ? 'hover:bg-gray-800 text-gray-300' : 'hover:bg-gray-100 text-gray-600'
                }`}
              >
                {isDark ? <Sun className="w-6 h-6" /> : <Moon className="w-6 h-6" />}
              </button>
              
              {/* Notifications */}
              <NotificationDrawer isDark={isDark} />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-lg mx-auto w-full flex flex-col">
        {currentPage === 'home' && <HomePage navigateTo={navigateTo} isDark={isDark} />}
        {currentPage === 'dashboard' && <DashboardPage isDark={isDark} />}
        {currentPage === 'map' && <TrafficMapPage isDark={isDark} />}
        {currentPage === 'predictions' && <PredictionPage isDark={isDark} />}
        {currentPage === 'violations' && <ViolationsPage isDark={isDark} />}
        {currentPage === 'alerts' && <AlertsPage isDark={isDark} />}
        {currentPage === 'cameras' && <CamerasPage isDark={isDark} />}
        {currentPage === 'reports' && <ReportsPage isDark={isDark} />}
        {currentPage === 'profile' && <ProfilePage navigateTo={navigateTo} isDark={isDark} />}
      </main>

      {/* Bottom Navigation */}
      <BottomNav currentPage={currentPage} navigateTo={navigateTo} isDark={isDark} />
      
      {/* Toast Notifications */}
      <Toaster />
    </div>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AppContent />
    </ThemeProvider>
  );
}