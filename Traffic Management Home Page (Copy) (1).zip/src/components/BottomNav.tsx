import { Home, LayoutDashboard, Map, Camera, AlertTriangle, User, ChevronUp } from 'lucide-react';
import { useState } from 'react';
import type { PageType } from '../App';

interface BottomNavProps {
  currentPage: PageType;
  navigateTo: (page: PageType) => void;
  isDark?: boolean;
}

export function BottomNav({ currentPage, navigateTo, isDark }: BottomNavProps) {
  const [showMore, setShowMore] = useState(false);

  const mainNavItems = [
    { id: 'home' as PageType, label: 'Home', icon: Home },
    { id: 'dashboard' as PageType, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'map' as PageType, label: 'Map', icon: Map },
    { id: 'alerts' as PageType, label: 'Alerts', icon: AlertTriangle },
    { id: 'profile' as PageType, label: 'Profile', icon: User },
  ];

  const moreNavItems = [
    { id: 'predictions' as PageType, label: 'Predictions', icon: '🔮' },
    { id: 'violations' as PageType, label: 'Violations', icon: '🚫' },
    { id: 'cameras' as PageType, label: 'Cameras', icon: '📹' },
    { id: 'reports' as PageType, label: 'Reports', icon: '📊' },
  ];

  return (
    <>
      {/* More Menu Overlay */}
      {showMore && (
        <>
          {/* Backdrop */}
          <div 
            className="fixed inset-0 bg-black/20 backdrop-blur-sm z-40"
            onClick={() => setShowMore(false)}
          />
          
          {/* More Menu */}
          <div
            className={`fixed bottom-20 left-4 right-4 max-w-lg mx-auto rounded-2xl p-4 z-50 ${
              isDark ? 'bg-[#1e1e1e]' : 'bg-white'
            } shadow-2xl animate-in slide-in-from-bottom-5 duration-200`}
          >
            <div className={`text-sm mb-3 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              More Features
            </div>
            <div className="grid grid-cols-4 gap-3">
              {moreNavItems.map((item) => (
                <button
                  key={item.id}
                  onClick={() => {
                    navigateTo(item.id);
                    setShowMore(false);
                  }}
                  className={`flex flex-col items-center gap-2 p-3 rounded-xl transition-all ${
                    currentPage === item.id
                      ? isDark
                        ? 'bg-[#2e7d32]/20 text-[#4caf50]'
                        : 'bg-[#e8f5e9] text-[#2e7d32]'
                      : isDark
                      ? 'hover:bg-gray-800 text-gray-400'
                      : 'hover:bg-gray-50 text-gray-600'
                  }`}
                >
                  <span className="text-2xl">{item.icon}</span>
                  <span className="text-xs text-center">{item.label}</span>
                </button>
              ))}
            </div>
          </div>
        </>
      )}

      {/* Bottom Navigation Bar */}
      <nav className={`fixed bottom-0 left-0 right-0 border-t z-50 ${
        isDark ? 'bg-[#1e1e1e] border-[#333333]' : 'bg-white border-[#e0e0e0]'
      }`}
        style={{ boxShadow: '0 -4px 12px rgba(0, 0, 0, 0.05)' }}
      >
        <div className="max-w-lg mx-auto px-2 py-2">
          <div className="flex items-center justify-around">
            {mainNavItems.map((item) => {
              const Icon = item.icon;
              const isActive = currentPage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => navigateTo(item.id)}
                  className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all relative ${
                    isActive
                      ? isDark
                        ? 'text-[#4caf50] bg-[#2e7d32]/20'
                        : 'text-[#2e7d32] bg-[#e8f5e9]'
                      : isDark 
                        ? 'text-gray-400 hover:text-gray-300 hover:bg-gray-800'
                        : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
                  }`}
                >
                  <Icon className={`w-6 h-6 ${isActive ? 'scale-110' : ''} transition-transform`} />
                  <span className="text-xs">{item.label}</span>
                  {isActive && (
                    <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 w-1 h-1 rounded-full bg-[#2e7d32]" />
                  )}
                </button>
              );
            })}
            
            {/* More Button */}
            <button
              onClick={() => setShowMore(!showMore)}
              className={`flex flex-col items-center gap-1 px-3 py-2 rounded-xl transition-all ${
                showMore
                  ? isDark
                    ? 'text-[#4caf50] bg-[#2e7d32]/20'
                    : 'text-[#2e7d32] bg-[#e8f5e9]'
                  : isDark 
                    ? 'text-gray-400 hover:text-gray-300 hover:bg-gray-800'
                    : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
              }`}
            >
              <ChevronUp className={`w-6 h-6 transition-transform ${showMore ? '' : 'rotate-180'}`} />
              <span className="text-xs">More</span>
            </button>
          </div>
        </div>
      </nav>
    </>
  );
}
