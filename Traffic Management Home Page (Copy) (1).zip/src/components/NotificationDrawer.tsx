import React from 'react';
import { Bell, X, CheckCircle, AlertTriangle, Info, MapPin, Leaf, Users, Trophy } from 'lucide-react';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger, SheetClose } from './ui/sheet';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Separator } from './ui/separator';

interface Notification {
  id: string;
  type: 'success' | 'warning' | 'info' | 'achievement';
  title: string;
  message: string;
  timestamp: string;
  read: boolean;
  icon: any;
  action?: {
    label: string;
    page: string;
  };
}

interface NotificationDrawerProps {
  isDark?: boolean;
}

export function NotificationDrawer({ isDark }: NotificationDrawerProps) {
  const [notifications, setNotifications] = React.useState<Notification[]>([
    {
      id: '1',
      type: 'achievement',
      title: 'New Achievement Unlocked! 🎉',
      message: 'You earned the "Eco Warrior" badge for saving 100kg CO₂',
      timestamp: '2 min ago',
      read: false,
      icon: Trophy,
      action: { label: 'View Profile', page: 'profile' }
    },
    {
      id: '2',
      type: 'warning',
      title: 'Heavy Traffic Alert',
      message: 'MG Road has severe congestion. Alternative route suggested.',
      timestamp: '15 min ago',
      read: false,
      icon: AlertTriangle,
      action: { label: 'View Map', page: 'map' }
    },
    {
      id: '3',
      type: 'info',
      title: 'Quiet Route Available',
      message: 'A peaceful walking path is now available near your location.',
      timestamp: '1 hour ago',
      read: false,
      icon: MapPin,
      action: { label: 'Explore', page: 'map' }
    },
    {
      id: '4',
      type: 'success',
      title: 'Daily Streak Extended! 🔥',
      message: 'You\'ve maintained your eco-friendly commute for 23 days!',
      timestamp: '3 hours ago',
      read: true,
      icon: Leaf
    },
    {
      id: '5',
      type: 'info',
      title: 'Community Update',
      message: 'Sarah Chen mentioned you in a post about carpooling.',
      timestamp: '5 hours ago',
      read: true,
      icon: Users,
      action: { label: 'View Post', page: 'community' }
    },
    {
      id: '6',
      type: 'info',
      title: 'AQI Improvement',
      message: 'Air quality in your area has improved to "Good" level.',
      timestamp: '1 day ago',
      read: true,
      icon: Info
    },
    {
      id: '7',
      type: 'achievement',
      title: 'Level Up!',
      message: 'You reached Level 12. Keep up the great work!',
      timestamp: '2 days ago',
      read: true,
      icon: Trophy
    }
  ]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const markAsRead = (id: string) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
  };

  const markAllAsRead = () => {
    setNotifications(notifications.map(n => ({ ...n, read: true })));
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'success': return isDark ? 'bg-green-900/30 border-green-700' : 'bg-green-50 border-green-200';
      case 'warning': return isDark ? 'bg-orange-900/30 border-orange-700' : 'bg-orange-50 border-orange-200';
      case 'achievement': return isDark ? 'bg-purple-900/30 border-purple-700' : 'bg-purple-50 border-purple-200';
      default: return isDark ? 'bg-blue-900/30 border-blue-700' : 'bg-blue-50 border-blue-200';
    }
  };

  const getIconColor = (type: string) => {
    switch (type) {
      case 'success': return 'text-green-600';
      case 'warning': return 'text-orange-600';
      case 'achievement': return 'text-purple-600';
      default: return 'text-blue-600';
    }
  };

  return (
    <Sheet>
      <SheetTrigger asChild>
        <button className={`relative p-2 rounded-lg transition-colors ${
          isDark ? 'hover:bg-gray-800' : 'hover:bg-gray-100'
        }`}>
          <Bell className={`w-6 h-6 ${isDark ? 'text-gray-300' : 'text-gray-600'}`} />
          {unreadCount > 0 && (
            <div className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"></div>
          )}
        </button>
      </SheetTrigger>
      <SheetContent side="right" className={`w-full sm:max-w-md ${isDark ? 'bg-gray-900 text-gray-100' : 'bg-white'}`}>
        <SheetHeader>
          <div className="flex items-center justify-between">
            <SheetTitle className={isDark ? 'text-gray-100' : 'text-gray-900'}>
              Notifications
              {unreadCount > 0 && (
                <Badge variant="destructive" className="ml-2">{unreadCount}</Badge>
              )}
            </SheetTitle>
            {unreadCount > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={markAllAsRead}
                className={isDark ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'}
              >
                Mark all read
              </Button>
            )}
          </div>
        </SheetHeader>

        <div className="mt-6 space-y-3 max-h-[calc(100vh-120px)] overflow-y-auto pb-6">
          {notifications.map((notification) => {
            const Icon = notification.icon;
            return (
              <div
                key={notification.id}
                className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                  getNotificationColor(notification.type)
                } ${!notification.read ? 'shadow-md' : 'opacity-70'}`}
                onClick={() => markAsRead(notification.id)}
              >
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                    isDark ? 'bg-gray-800' : 'bg-white'
                  }`}>
                    <Icon className={`w-5 h-5 ${getIconColor(notification.type)}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className={`text-sm ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                        {notification.title}
                      </h4>
                      {!notification.read && (
                        <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0 mt-1"></div>
                      )}
                    </div>
                    <p className={`text-xs mt-1 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                      {notification.message}
                    </p>
                    <p className={`text-xs mt-2 ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
                      {notification.timestamp}
                    </p>
                    {notification.action && (
                      <Button 
                        variant="link" 
                        size="sm" 
                        className={`mt-2 p-0 h-auto ${
                          isDark ? 'text-blue-400 hover:text-blue-300' : 'text-blue-600 hover:text-blue-700'
                        }`}
                      >
                        {notification.action.label} →
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </SheetContent>
    </Sheet>
  );
}
