import React from 'react';
import { Share2, Facebook, Twitter, Linkedin, Mail, Link2, Instagram, MessageCircle, Copy, Check } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from './ui/dialog';
import { Button } from './ui/button';
import { toast } from 'sonner@2.0.3';

interface SocialShareDialogProps {
  isDark?: boolean;
}

export function SocialShareDialog({ isDark }: SocialShareDialogProps) {
  const [copied, setCopied] = React.useState(false);
  
  const shareUrl = 'https://gatyah.app/profile/alexj_commute';
  const shareText = "Check out my GATYAH profile! I've saved 342.5kg of CO₂ through eco-friendly commuting. Join me! 🌱";

  const handleCopyLink = () => {
    navigator.clipboard.writeText(shareUrl);
    setCopied(true);
    toast.success('Link copied to clipboard!');
    setTimeout(() => setCopied(false), 2000);
  };

  const socialPlatforms = [
    {
      name: 'WhatsApp',
      icon: MessageCircle,
      color: 'bg-green-500 hover:bg-green-600',
      onClick: () => {
        window.open(`https://wa.me/?text=${encodeURIComponent(shareText + ' ' + shareUrl)}`, '_blank');
      }
    },
    {
      name: 'Facebook',
      icon: Facebook,
      color: 'bg-blue-600 hover:bg-blue-700',
      onClick: () => {
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareUrl)}`, '_blank');
      }
    },
    {
      name: 'Twitter',
      icon: Twitter,
      color: 'bg-sky-500 hover:bg-sky-600',
      onClick: () => {
        window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareText)}&url=${encodeURIComponent(shareUrl)}`, '_blank');
      }
    },
    {
      name: 'LinkedIn',
      icon: Linkedin,
      color: 'bg-blue-700 hover:bg-blue-800',
      onClick: () => {
        window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(shareUrl)}`, '_blank');
      }
    },
    {
      name: 'Instagram',
      icon: Instagram,
      color: 'bg-gradient-to-br from-purple-600 via-pink-600 to-orange-500 hover:from-purple-700 hover:via-pink-700 hover:to-orange-600',
      onClick: () => {
        toast.info('Copy the link and share it on Instagram!');
        handleCopyLink();
      }
    },
    {
      name: 'Email',
      icon: Mail,
      color: 'bg-gray-600 hover:bg-gray-700',
      onClick: () => {
        window.location.href = `mailto:?subject=${encodeURIComponent('Check out my GATYAH profile!')}&body=${encodeURIComponent(shareText + '\n\n' + shareUrl)}`;
      }
    }
  ];

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          variant="outline" 
          className={`flex items-center gap-2 ${
            isDark ? 'border-gray-700 text-gray-300 hover:bg-gray-800' : ''
          }`}
        >
          <Share2 className="w-4 h-4" />
          Share Profile
        </Button>
      </DialogTrigger>
      <DialogContent className={`sm:max-w-md ${isDark ? 'bg-gray-900 text-gray-100 border-gray-800' : ''}`}>
        <DialogHeader>
          <DialogTitle className={isDark ? 'text-gray-100' : ''}>Share Your Profile</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 pt-4">
          <div className={`p-4 rounded-xl border ${
            isDark ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
          }`}>
            <p className={`text-sm mb-3 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
              {shareText}
            </p>
            <div className="flex items-center gap-2">
              <input
                type="text"
                value={shareUrl}
                readOnly
                className={`flex-1 px-3 py-2 text-sm rounded-lg border outline-none ${
                  isDark 
                    ? 'bg-gray-900 border-gray-700 text-gray-300' 
                    : 'bg-white border-gray-300 text-gray-700'
                }`}
              />
              <Button
                size="sm"
                onClick={handleCopyLink}
                className={copied ? 'bg-green-600 hover:bg-green-700' : ''}
              >
                {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          <div>
            <p className={`text-sm mb-3 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Share on social media
            </p>
            <div className="grid grid-cols-3 gap-3">
              {socialPlatforms.map((platform) => {
                const Icon = platform.icon;
                return (
                  <button
                    key={platform.name}
                    onClick={platform.onClick}
                    className={`flex flex-col items-center gap-2 p-4 rounded-xl text-white transition-all hover:scale-105 ${platform.color}`}
                  >
                    <Icon className="w-6 h-6" />
                    <span className="text-xs">{platform.name}</span>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
