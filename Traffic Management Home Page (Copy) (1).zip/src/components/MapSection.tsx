import { MapPin, Navigation as NavigationIcon } from 'lucide-react';

export function MapSection() {
  return (
    <div className="max-w-4xl mx-auto px-4 pt-8 pb-6">
      <div className="text-center">
        {/* Map Icon */}
        <div className="inline-flex items-center justify-center w-24 h-24 bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl mb-6 relative">
          <NavigationIcon className="w-12 h-12 text-white" />
          <div className="absolute -top-1 -right-1 w-6 h-6 bg-green-400 rounded-full"></div>
        </div>

        {/* Title and Description */}
        <h1 className="text-gray-900 mb-3">Interactive Traffic Map</h1>
        <p className="text-gray-600 max-w-md mx-auto">
          Real-time traffic monitoring with live updates, incident alerts, and intelligent route suggestions to save you time.
        </p>
      </div>
    </div>
  );
}
