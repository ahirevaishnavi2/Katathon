import { MapPin, Navigation as NavigationIcon, Clock, Zap, AlertTriangle, TrendingUp } from 'lucide-react';
import { useState } from 'react';

export function RoutePlanner() {
  const [startLocation, setStartLocation] = useState('');
  const [endLocation, setEndLocation] = useState('');

  const routes = [
    {
      id: 1,
      name: 'Fastest Route',
      icon: Zap,
      description: 'Via Highway 101',
      duration: '18 min',
      traffic: 'Light',
      trafficLevel: 25,
      color: 'blue',
    },
    {
      id: 2,
      name: 'Alternative Route',
      icon: TrendingUp,
      description: 'Via Main Street',
      duration: '22 min',
      traffic: 'Moderate',
      trafficLevel: 55,
      color: 'orange',
    },
    {
      id: 3,
      name: 'Avoid Tolls',
      icon: NavigationIcon,
      description: 'Via Park Avenue',
      duration: '25 min',
      traffic: 'Heavy',
      trafficLevel: 85,
      color: 'gray',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
        {/* Section Header */}
        <div className="flex items-center gap-2 mb-6">
          <NavigationIcon className="w-5 h-5 text-blue-600" />
          <h2 className="text-gray-900">Plan Your Route</h2>
        </div>

        {/* Location Inputs */}
        <div className="space-y-4 mb-6">
          {/* Start Location */}
          <div className="relative">
            <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-green-600" />
            <input
              type="text"
              placeholder="Start location"
              value={startLocation}
              onChange={(e) => setStartLocation(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border-2 border-green-200 rounded-xl focus:outline-none focus:border-green-400 transition-colors"
            />
          </div>

          {/* End Location */}
          <div className="relative">
            <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-red-600" />
            <input
              type="text"
              placeholder="End location"
              value={endLocation}
              onChange={(e) => setEndLocation(e.target.value)}
              className="w-full pl-12 pr-4 py-3 border-2 border-red-200 rounded-xl focus:outline-none focus:border-red-400 transition-colors"
            />
          </div>
        </div>

        {/* Find Route Button */}
        <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-xl transition-colors mb-6">
          Find Optimal Route
        </button>

        {/* Route Options */}
        <div className="space-y-3">
          {routes.map((route) => {
            const Icon = route.icon;
            const trafficColor =
              route.trafficLevel < 40
                ? 'text-green-600 bg-green-50'
                : route.trafficLevel < 70
                ? 'text-orange-600 bg-orange-50'
                : 'text-red-600 bg-red-50';

            const borderColor =
              route.trafficLevel < 40
                ? 'border-green-200 hover:border-green-300'
                : route.trafficLevel < 70
                ? 'border-orange-200 hover:border-orange-300'
                : 'border-red-200 hover:border-red-300';

            return (
              <button
                key={route.id}
                className={`w-full flex items-center justify-between p-4 border-2 ${borderColor} rounded-xl transition-all hover:shadow-md`}
              >
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${trafficColor}`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <div className="text-gray-900">{route.name}</div>
                    <div className="text-sm text-gray-500">{route.description}</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="flex items-center gap-1 text-gray-900">
                    <Clock className="w-4 h-4" />
                    <span>{route.duration}</span>
                  </div>
                  <div className="text-sm text-gray-500">{route.traffic}</div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Traffic Legend */}
        <div className="mt-6 pt-6 border-t border-gray-200">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-orange-600" />
              <span className="text-gray-600">Live traffic updates</span>
            </div>
            <span className="text-blue-600">View map →</span>
          </div>
        </div>
      </div>
    </div>
  );
}
