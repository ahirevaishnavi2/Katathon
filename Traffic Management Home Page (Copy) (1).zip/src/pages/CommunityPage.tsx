import React, { useState } from 'react';
import { 
  MessageSquare, 
  ThumbsUp, 
  Share2, 
  AlertTriangle, 
  Leaf, 
  TrendingUp,
  MapPin,
  Award,
  MoreVertical,
  Send,
  Image as ImageIcon,
  Users,
  Clock,
  Filter,
  PlusCircle,
  Heart,
  Bookmark,
  Flag,
  CheckCircle,
  Zap,
  Camera
} from 'lucide-react';
import { Card } from '../components/ui/card';
import { Avatar } from '../components/ui/avatar';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Tabs, TabsList, TabsTrigger } from '../components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Textarea } from '../components/ui/textarea';
import { Separator } from '../components/ui/separator';
import { toast } from 'sonner@2.0.3';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

interface Post {
  id: string;
  type: 'traffic' | 'eco' | 'tip' | 'question';
  author: {
    name: string;
    avatar: string;
    reputation: number;
    badges: string[];
  };
  timestamp: string;
  location?: string;
  content: string;
  image?: string;
  likes: number;
  comments: number;
  shares: number;
  isLiked: boolean;
  isBookmarked: boolean;
  tags?: string[];
  verified?: boolean;
}

interface Comment {
  id: string;
  author: string;
  avatar: string;
  content: string;
  timestamp: string;
  likes: number;
}

interface CommunityPageProps {
  navigateTo: (page: 'home' | 'map' | 'chatbot' | 'community' | 'profile') => void;
  isDark?: boolean;
}

const CommunityPage: React.FC<CommunityPageProps> = ({ navigateTo, isDark }) => {
  const [activeTab, setActiveTab] = useState('all');
  const [showCreatePost, setShowCreatePost] = useState(false);
  const [postType, setPostType] = useState<'traffic' | 'eco' | 'tip' | 'question'>('traffic');
  const [newPostContent, setNewPostContent] = useState('');
  const [expandedComments, setExpandedComments] = useState<string | null>(null);
  const [commentText, setCommentText] = useState('');
  const [visiblePostsCount, setVisiblePostsCount] = useState(12);
  
  const [posts, setPosts] = useState<Post[]>([
    {
      id: '1',
      type: 'traffic',
      author: {
        name: 'Sarah Chen',
        avatar: '👩‍💼',
        reputation: 2450,
        badges: ['🏆', '⚡']
      },
      timestamp: '5 min ago',
      location: 'MG Road Junction',
      content: '🚨 Heavy traffic alert! Road construction causing major delays on MG Road. Alternative route via Church Street is clear.',
      likes: 48,
      comments: 12,
      shares: 8,
      isLiked: true,
      isBookmarked: false,
      tags: ['traffic-alert', 'construction'],
      verified: true
    },
    {
      id: '2',
      type: 'eco',
      author: {
        name: 'Raj Kumar',
        avatar: '👨',
        reputation: 1890,
        badges: ['🌱', '🚴']
      },
      timestamp: '12 min ago',
      content: '🎉 Completed my 30-day cycling challenge! Saved 45kg CO₂ and feeling healthier than ever. Who wants to join next month?',
      image: 'https://images.unsplash.com/photo-1683616667040-8a2e34ad3522?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjeWNsaW5nJTIwYWNoaWV2ZW1lbnQlMjBjZWxlYnJhdGlvbnxlbnwxfHx8fDE3NjI2Nzc4NTR8MA&ixlib=rb-4.1.0&q=80&w=1080',
      likes: 156,
      comments: 24,
      shares: 15,
      isLiked: false,
      isBookmarked: true,
      tags: ['eco-warrior', 'cycling'],
      verified: false
    },
    {
      id: '3',
      type: 'tip',
      author: {
        name: 'Priya Sharma',
        avatar: '👩',
        reputation: 3120,
        badges: ['💡', '🏆', '🌟']
      },
      timestamp: '28 min ago',
      content: '💡 Pro tip: Use the metro between 10 AM - 5 PM for 20% off fares and zero crowd. Perfect for eco-friendly travel!',
      likes: 89,
      comments: 18,
      shares: 31,
      isLiked: true,
      isBookmarked: true,
      tags: ['tips', 'metro', 'savings']
    },
    {
      id: '4',
      type: 'question',
      author: {
        name: 'Mike Johnson',
        avatar: '👨‍💻',
        reputation: 450,
        badges: ['🆕']
      },
      timestamp: '1 hour ago',
      location: 'Whitefield',
      content: 'What\'s the best carpool app that integrates with GeoSense+? Looking for reliable daily commute partners.',
      likes: 23,
      comments: 31,
      shares: 4,
      isLiked: false,
      isBookmarked: false,
      tags: ['question', 'carpool']
    },
    {
      id: '5',
      type: 'eco',
      author: {
        name: 'Anna Martinez',
        avatar: '👩‍🦱',
        reputation: 2780,
        badges: ['🌱', '⚡', '🎖️']
      },
      timestamp: '2 hours ago',
      content: '🌳 Just planted 5 trees as part of GATYAH carbon offset program! Every 1000 eco-points = 1 tree. Let\'s make our city greener!',
      image: 'https://images.unsplash.com/photo-1703012349431-95c3304d098f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cmVlJTIwcGxhbnRpbmclMjBlbnZpcm9ubWVudHxlbnwxfHx8fDE3NjI2Nzc4NTR8MA&ixlib=rb-4.1.0&q=80&w=1080',
      likes: 203,
      comments: 45,
      shares: 52,
      isLiked: true,
      isBookmarked: false,
      tags: ['eco-warrior', 'carbon-offset']
    },
    {
      id: '6',
      type: 'traffic',
      author: {
        name: 'David Lee',
        avatar: '👨‍🔧',
        reputation: 1650,
        badges: ['🚗', '⚡']
      },
      timestamp: '3 hours ago',
      location: 'HSR Layout',
      content: 'Traffic cleared on Outer Ring Road! The accident near HSR has been resolved. Flow back to normal.',
      likes: 67,
      comments: 8,
      shares: 12,
      isLiked: false,
      isBookmarked: false,
      tags: ['traffic-update', 'resolved'],
      verified: true
    },
    {
      id: '7',
      type: 'tip',
      author: {
        name: 'Emma Wilson',
        avatar: '👩‍🎓',
        reputation: 1920,
        badges: ['💡', '🚴']
      },
      timestamp: '4 hours ago',
      content: '🚴‍♀️ Found an amazing bike lane from Koregaon Park to Kalyani Nagar! Clean, well-maintained, and saves 15 mins vs main road.',
      image: 'https://images.unsplash.com/photo-1656166714101-42ea748e3778?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiaWtlJTIwbGFuZSUyMGNpdHl8ZW58MXx8fHwxNzYyNjc3ODU0fDA&ixlib=rb-4.1.0&q=80&w=1080',
      likes: 112,
      comments: 28,
      shares: 34,
      isLiked: true,
      isBookmarked: true,
      tags: ['cycling', 'tips', 'infrastructure']
    },
    {
      id: '8',
      type: 'question',
      author: {
        name: 'Arjun Patel',
        avatar: '👨‍🦱',
        reputation: 890,
        badges: ['🆕']
      },
      timestamp: '5 hours ago',
      location: 'Baner',
      content: 'Anyone know if the new metro line to Baner is operational yet? Want to ditch my car for daily commute!',
      likes: 34,
      comments: 19,
      shares: 6,
      isLiked: false,
      isBookmarked: false,
      tags: ['metro', 'question', 'baner']
    },
    {
      id: '9',
      type: 'eco',
      author: {
        name: 'Carlos Rodriguez',
        avatar: '👨‍🚀',
        reputation: 3450,
        badges: ['🌱', '⚡', '🏆', '🎖️']
      },
      timestamp: '6 hours ago',
      content: '⚡ Switched to an EV 3 months ago using GATYAH recommendations. Already saved 125kg CO₂ and ₹8,500 on fuel! Best decision ever.',
      image: 'https://images.unsplash.com/photo-1593941707874-ef25b8b4a92b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxlbGVjdHJpYyUyMGNhciUyMGNoYXJnaW5nfGVufDF8fHx8MTc2MjU5NzQxOHww&ixlib=rb-4.1.0&q=80&w=1080',
      likes: 289,
      comments: 67,
      shares: 95,
      isLiked: true,
      isBookmarked: true,
      tags: ['electric-vehicle', 'savings', 'eco-warrior'],
      verified: true
    },
    {
      id: '10',
      type: 'traffic',
      author: {
        name: 'Meera Krishnan',
        avatar: '👩‍⚕️',
        reputation: 2150,
        badges: ['🚗', '💡']
      },
      timestamp: '8 hours ago',
      location: 'FC Road',
      content: '🚨 Road flooding on FC Road near Sambhaji Park. Avoid the area. Municipal team has been notified.',
      image: 'https://images.unsplash.com/photo-1657069343871-fd1476990d04?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyb2FkJTIwZmxvb2RpbmclMjB3YXRlcnxlbnwxfHx8fDE3NjI2Nzc4NTZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      likes: 156,
      comments: 42,
      shares: 78,
      isLiked: false,
      isBookmarked: false,
      tags: ['weather-alert', 'traffic'],
      verified: true
    },
    {
      id: '11',
      type: 'tip',
      author: {
        name: 'Tom Anderson',
        avatar: '👨‍🏫',
        reputation: 1580,
        badges: ['💡', '🚌']
      },
      timestamp: '10 hours ago',
      content: '🚌 Pro commuter tip: PMPML bus #4 runs every 10 mins during peak hours. Way faster than driving! Plus you can work/read on the way.',
      likes: 78,
      comments: 15,
      shares: 22,
      isLiked: false,
      isBookmarked: true,
      tags: ['public-transport', 'tips', 'productivity']
    },
    {
      id: '12',
      type: 'eco',
      author: {
        name: 'Nina Gupta',
        avatar: '👩‍🔬',
        reputation: 2890,
        badges: ['🌱', '🚴', '🏆']
      },
      timestamp: '12 hours ago',
      content: '🎯 Monthly challenge update: Our carpooling group saved 234kg CO₂ this month! That\'s equivalent to planting 10 trees. Who wants to join us?',
      image: 'https://images.unsplash.com/photo-1719778532480-544012d378a5?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXJwb29sJTIwZnJpZW5kcyUyMGNhcnxlbnwxfHx8fDE3NjI2Nzc4NTV8MA&ixlib=rb-4.1.0&q=80&w=1080',
      likes: 198,
      comments: 53,
      shares: 41,
      isLiked: true,
      isBookmarked: false,
      tags: ['carpool', 'challenge', 'eco-warrior']
    }
  ]);

  const trendingTopics = [
    { tag: 'metro-expansion', posts: 234, trend: '+12%' },
    { tag: 'cycle-challenge', posts: 189, trend: '+45%' },
    { tag: 'traffic-alert', posts: 567, trend: '+8%' },
    { tag: 'carpool-monday', posts: 145, trend: '+23%' }
  ];

  const topContributors = [
    { name: 'Priya Sharma', avatar: '👩', points: 3120 },
    { name: 'Anna Martinez', avatar: '👩‍🦱', points: 2780 },
    { name: 'Sarah Chen', avatar: '👩‍💼', points: 2450 }
  ];

  const mockComments: Comment[] = [
    {
      id: 'c1',
      author: 'John Doe',
      avatar: '👨‍💼',
      content: 'Thanks for the update! Saved me 30 minutes.',
      timestamp: '2 min ago',
      likes: 5
    },
    {
      id: 'c2',
      author: 'Lisa Wang',
      avatar: '👩‍💻',
      content: 'Is the construction going to continue tomorrow?',
      timestamp: '4 min ago',
      likes: 2
    }
  ];

  const handleLike = (postId: string) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        const newIsLiked = !post.isLiked;
        toast.success(newIsLiked ? 'Post liked!' : 'Like removed', {
          position: 'top-center',
        });
        return {
          ...post,
          isLiked: newIsLiked,
          likes: post.isLiked ? post.likes - 1 : post.likes + 1
        };
      }
      return post;
    }));
  };

  const handleBookmark = (postId: string) => {
    setPosts(posts.map(post => {
      if (post.id === postId) {
        toast.success(post.isBookmarked ? 'Removed from bookmarks' : 'Added to bookmarks', {
          position: 'top-center',
        });
        return {
          ...post,
          isBookmarked: !post.isBookmarked
        };
      }
      return post;
    }));
  };

  const handleShare = (postId: string) => {
    toast.success('Link copied to clipboard!', {
      position: 'top-center',
    });
  };

  const handleCreatePost = () => {
    if (!newPostContent.trim()) {
      toast.error('Please enter some content', {
        position: 'top-center',
      });
      return;
    }

    const newPost: Post = {
      id: Date.now().toString(),
      type: postType,
      author: {
        name: 'You',
        avatar: '😊',
        reputation: 890,
        badges: ['🆕']
      },
      timestamp: 'Just now',
      content: newPostContent,
      likes: 0,
      comments: 0,
      shares: 0,
      isLiked: false,
      isBookmarked: false
    };

    setPosts([newPost, ...posts]);
    setNewPostContent('');
    setShowCreatePost(false);
    toast.success('Post published successfully!', {
      position: 'top-center',
    });
  };

  const handleComment = (postId: string) => {
    if (!commentText.trim()) return;

    setPosts(posts.map(post => {
      if (post.id === postId) {
        return {
          ...post,
          comments: post.comments + 1
        };
      }
      return post;
    }));

    setCommentText('');
    toast.success('Comment added!', {
      position: 'top-center',
    });
  };

  const handleLoadMore = () => {
    setVisiblePostsCount(prev => prev + 6);
  };

  const getPostIcon = (type: string) => {
    switch (type) {
      case 'traffic':
        return <AlertTriangle className="w-4 h-4" />;
      case 'eco':
        return <Leaf className="w-4 h-4" />;
      case 'tip':
        return <Zap className="w-4 h-4" />;
      case 'question':
        return <MessageSquare className="w-4 h-4" />;
      default:
        return null;
    }
  };

  const getPostColor = (type: string) => {
    switch (type) {
      case 'traffic':
        return 'bg-red-500/10 text-red-600 border-red-200';
      case 'eco':
        return 'bg-green-500/10 text-green-600 border-green-200';
      case 'tip':
        return 'bg-blue-500/10 text-blue-600 border-blue-200';
      case 'question':
        return 'bg-purple-500/10 text-purple-600 border-purple-200';
      default:
        return '';
    }
  };

  const filteredPosts = posts.filter(post => {
    if (activeTab === 'all') return true;
    if (activeTab === 'traffic') return post.type === 'traffic';
    if (activeTab === 'eco') return post.type === 'eco';
    if (activeTab === 'nearby') return post.location;
    return true;
  }).slice(0, visiblePostsCount);

  return (
    <div className={`min-h-screen pb-20 ${
      isDark ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-blue-50 to-green-50'
    }`}>
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white p-4 sticky top-0 z-10 shadow-lg">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-white">Community Feed</h1>
            <p className="text-blue-100 text-sm">Connect, share, and help others</p>
          </div>
          <Dialog open={showCreatePost} onOpenChange={setShowCreatePost}>
            <DialogTrigger asChild>
              <Button 
                size="sm" 
                className="bg-white text-blue-600 hover:bg-blue-50"
              >
                <PlusCircle className="w-4 h-4 mr-1" />
                Post
              </Button>
            </DialogTrigger>
            <DialogContent className={`max-w-md ${isDark ? 'bg-gray-900 text-gray-100 border-gray-800' : ''}`}>
              <DialogHeader>
                <DialogTitle className={isDark ? 'text-gray-100' : ''}>Create New Post</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="grid grid-cols-4 gap-2">
                  {(['traffic', 'eco', 'tip', 'question'] as const).map(type => (
                    <button
                      key={type}
                      onClick={() => setPostType(type)}
                      className={`p-3 rounded-lg border-2 transition-all ${
                        postType === type 
                          ? 'border-blue-500 bg-blue-50' 
                          : isDark ? 'border-gray-700 hover:border-gray-600 bg-gray-800' : 'border-gray-200 hover:border-gray-300'
                      }`}
                    >
                      <div className="flex flex-col items-center gap-1">
                        {getPostIcon(type)}
                        <span className={`text-xs capitalize ${isDark ? 'text-gray-300' : ''}`}>{type}</span>
                      </div>
                    </button>
                  ))}
                </div>
                
                <Textarea
                  placeholder="What's happening in your area?"
                  value={newPostContent}
                  onChange={(e) => setNewPostContent(e.target.value)}
                  className={`min-h-[120px] ${isDark ? 'bg-gray-800 border-gray-700 text-gray-200 placeholder:text-gray-500' : ''}`}
                />
                
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="flex-1">
                    <MapPin className="w-4 h-4 mr-1" />
                    Add Location
                  </Button>
                  <Button variant="outline" size="sm" className="flex-1">
                    <Camera className="w-4 h-4 mr-1" />
                    Add Photo
                  </Button>
                </div>
                
                <Button 
                  onClick={handleCreatePost}
                  className="w-full bg-gradient-to-r from-blue-600 to-green-600"
                >
                  Publish Post
                </Button>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Filter Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full bg-white/10 grid grid-cols-4">
            <TabsTrigger value="all" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-600">
              All
            </TabsTrigger>
            <TabsTrigger value="traffic" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-600">
              Traffic
            </TabsTrigger>
            <TabsTrigger value="eco" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-600">
              Eco
            </TabsTrigger>
            <TabsTrigger value="nearby" className="text-white data-[state=active]:bg-white data-[state=active]:text-blue-600">
              Nearby
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      <div className="p-4 space-y-4">
        {/* Trending Topics */}
        <Card className={`p-4 shadow-lg ${isDark ? 'bg-gray-800 border-gray-700' : 'bg-white'}`}>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-orange-500" />
              <span className={isDark ? 'text-gray-100' : 'text-gray-900'}>Trending Now</span>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            {trendingTopics.map((topic, index) => (
              <button
                key={index}
                className={`p-2 rounded-lg border transition-all text-left ${
                  isDark 
                    ? 'bg-gradient-to-r from-gray-700 to-gray-600 border-gray-600 hover:border-blue-500' 
                    : 'bg-gradient-to-r from-blue-50 to-green-50 border-blue-100 hover:border-blue-300'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm text-blue-400">#{topic.tag}</span>
                  <Badge variant="secondary" className={`text-xs ${isDark ? 'bg-green-900 text-green-300' : 'bg-green-100 text-green-700'}`}>
                    {topic.trend}
                  </Badge>
                </div>
                <p className={`text-xs mt-1 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{topic.posts} posts</p>
              </button>
            ))}
          </div>
        </Card>

        {/* Top Contributors */}
        <Card className={`p-4 shadow-lg border ${
          isDark 
            ? 'bg-gradient-to-r from-amber-900/30 to-yellow-900/30 border-amber-800' 
            : 'bg-gradient-to-r from-amber-50 to-yellow-50 border-amber-200'
        }`}>
          <div className="flex items-center gap-2 mb-3">
            <Award className={`w-5 h-5 ${isDark ? 'text-amber-400' : 'text-amber-600'}`} />
            <span className={isDark ? 'text-gray-100' : 'text-gray-900'}>Top Contributors This Week</span>
          </div>
          <div className="flex gap-3">
            {topContributors.map((contributor, index) => (
              <div key={index} className="flex-1 text-center">
                <div className="relative inline-block">
                  <div className="text-3xl mb-1">{contributor.avatar}</div>
                  {index === 0 && (
                    <div className="absolute -top-1 -right-1 text-lg">👑</div>
                  )}
                </div>
                <p className={`text-xs ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>{contributor.name.split(' ')[0]}</p>
                <p className={`text-xs ${isDark ? 'text-amber-400' : 'text-amber-600'}`}>{contributor.points} pts</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Posts Feed */}
        <div className="space-y-4">
          {filteredPosts.map((post) => (
            <Card key={post.id} className={`overflow-hidden shadow-lg hover:shadow-xl transition-shadow ${
              isDark ? 'bg-gray-800 border-gray-700' : ''
            }`}>
              {/* Post Header */}
              <div className="p-4">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex gap-3 flex-1">
                    <div className="text-3xl">{post.author.avatar}</div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={isDark ? 'text-gray-100' : 'text-gray-900'}>{post.author.name}</span>
                        {post.verified && (
                          <CheckCircle className="w-4 h-4 text-blue-500 fill-current" />
                        )}
                        {post.author.badges.map((badge, i) => (
                          <span key={i} className="text-sm">{badge}</span>
                        ))}
                      </div>
                      <div className={`flex items-center gap-2 mt-1 text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                        <Clock className="w-3 h-3" />
                        <span>{post.timestamp}</span>
                        {post.location && (
                          <>
                            <span>•</span>
                            <MapPin className="w-3 h-3" />
                            <span>{post.location}</span>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                  <button className={`${isDark ? 'text-gray-500 hover:text-gray-300' : 'text-gray-400 hover:text-gray-600'}`}>
                    <MoreVertical className="w-5 h-5" />
                  </button>
                </div>

                {/* Post Type Badge */}
                <Badge className={`mb-3 border ${getPostColor(post.type)}`}>
                  <span className="flex items-center gap-1">
                    {getPostIcon(post.type)}
                    <span className="capitalize">{post.type}</span>
                  </span>
                </Badge>

                {/* Post Content */}
                <p className={`mb-3 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>{post.content}</p>

                {/* Post Image */}
                {post.image && (
                  <div className="mb-3 rounded-lg overflow-hidden aspect-video">
                    <ImageWithFallback 
                      src={post.image} 
                      alt={post.content.substring(0, 50)}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}

                {/* Tags */}
                {post.tags && (
                  <div className="flex gap-2 mb-3 flex-wrap">
                    {post.tags.map((tag, i) => (
                      <span key={i} className={`text-xs px-2 py-1 rounded-full ${
                        isDark ? 'text-blue-400 bg-blue-900/30' : 'text-blue-600 bg-blue-50'
                      }`}>
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}

                {/* Engagement Stats */}
                <div className={`flex items-center gap-4 py-2 text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                  <span className="flex items-center gap-1">
                    <Heart className="w-4 h-4" />
                    {post.likes}
                  </span>
                  <span className="flex items-center gap-1">
                    <MessageSquare className="w-4 h-4" />
                    {post.comments}
                  </span>
                  <span className="flex items-center gap-1">
                    <Share2 className="w-4 h-4" />
                    {post.shares}
                  </span>
                </div>
              </div>

              <Separator className={isDark ? 'bg-gray-700' : ''} />

              {/* Action Buttons */}
              <div className="flex items-center p-2">
                <Button
                  variant="ghost"
                  size="sm"
                  className={`flex-1 ${post.isLiked ? 'text-red-500' : isDark ? 'text-gray-400' : 'text-gray-600'}`}
                  onClick={() => handleLike(post.id)}
                >
                  <ThumbsUp className={`w-4 h-4 mr-1 ${post.isLiked ? 'fill-current' : ''}`} />
                  Like
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`flex-1 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}
                  onClick={() => setExpandedComments(expandedComments === post.id ? null : post.id)}
                >
                  <MessageSquare className="w-4 h-4 mr-1" />
                  Comment
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`flex-1 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}
                  onClick={() => handleShare(post.id)}
                >
                  <Share2 className="w-4 h-4 mr-1" />
                  Share
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className={`${post.isBookmarked ? 'text-amber-500' : isDark ? 'text-gray-400' : 'text-gray-600'}`}
                  onClick={() => handleBookmark(post.id)}
                >
                  <Bookmark className={`w-4 h-4 ${post.isBookmarked ? 'fill-current' : ''}`} />
                </Button>
              </div>

              {/* Comments Section */}
              {expandedComments === post.id && (
                <>
                  <Separator className={isDark ? 'bg-gray-700' : ''} />
                  <div className={`p-4 space-y-3 ${isDark ? 'bg-gray-900' : 'bg-gray-50'}`}>
                    {mockComments.map(comment => (
                      <div key={comment.id} className="flex gap-3">
                        <div className="text-2xl">{comment.avatar}</div>
                        <div className="flex-1">
                          <div className={`p-3 rounded-lg ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
                            <span className={`text-sm ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>{comment.author}</span>
                            <p className={`text-sm mt-1 ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>{comment.content}</p>
                          </div>
                          <div className={`flex items-center gap-3 mt-1 text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
                            <span>{comment.timestamp}</span>
                            <button className={`${isDark ? 'hover:text-blue-400' : 'hover:text-blue-600'}`}>Like ({comment.likes})</button>
                            <button className={`${isDark ? 'hover:text-blue-400' : 'hover:text-blue-600'}`}>Reply</button>
                          </div>
                        </div>
                      </div>
                    ))}

                    {/* Add Comment */}
                    <div className="flex gap-2 pt-2">
                      <input
                        type="text"
                        placeholder="Write a comment..."
                        value={commentText}
                        onChange={(e) => setCommentText(e.target.value)}
                        className={`flex-1 px-3 py-2 border rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 ${
                          isDark 
                            ? 'bg-gray-800 border-gray-700 text-gray-200 placeholder:text-gray-500' 
                            : 'border-gray-300'
                        }`}
                      />
                      <Button
                        size="sm"
                        onClick={() => handleComment(post.id)}
                        className="bg-gradient-to-r from-blue-600 to-green-600"
                      >
                        <Send className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </>
              )}
            </Card>
          ))}
        </div>

        {/* Load More */}
        {visiblePostsCount < posts.length && (
          <Button 
            variant="outline" 
            className={`w-full ${isDark ? 'border-gray-700 text-gray-300 hover:bg-gray-800' : ''}`}
            onClick={handleLoadMore}
          >
            Load More Posts
          </Button>
        )}
      </div>
    </div>
  );
};

export default CommunityPage;
