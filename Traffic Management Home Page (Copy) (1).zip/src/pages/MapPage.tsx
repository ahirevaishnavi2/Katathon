import { MapPin, Navigation2, Zap, Wind, Leaf, Car, Volume2, Search, Layers, ChevronDown, X, Coffee, Utensils, Bus, Train, Building2, Hospital, ShoppingBag, School, TrendingUp, AlertTriangle } from 'lucide-react';
import { useState } from 'react';

interface LayerType {
  id: string;
  name: string;
  icon: any;
  color: string;
  enabled: boolean;
}

interface POIType {
  id: number;
  name: string;
  type: 'park' | 'ev' | 'safe' | 'transit' | 'cafe' | 'restaurant' | 'hospital' | 'school' | 'shopping';
  lat: number;
  lng: number;
  icon: string;
  category: string;
}

interface RouteOption {
  id: number;
  name: string;
  duration: string;
  distance: string;
  co2Saved: number;
  trafficLevel: 'low' | 'medium' | 'high';
  badge: 'green' | 'amber' | 'red';
}

interface MapPageProps {
  isDark?: boolean;
}

export function MapPage({ isDark }: MapPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [showLayers, setShowLayers] = useState(false);
  const [showRoutes, setShowRoutes] = useState(false);
  const [selectedRoute, setSelectedRoute] = useState<number | null>(null);
  const [mapCenter, setMapCenter] = useState({ x: 50, y: 50 }); // percentage positions
  const [mapZoom, setMapZoom] = useState(1);

  const [layers, setLayers] = useState<LayerType[]>([
    { id: 'traffic', name: 'Traffic', icon: Car, color: 'bg-red-500', enabled: true },
    { id: 'aqi', name: 'Air Quality', icon: Wind, color: 'bg-blue-500', enabled: true },
    { id: 'noise', name: 'Noise', icon: Volume2, color: 'bg-purple-500', enabled: false },
    { id: 'quiet', name: 'Quiet Routes', icon: Leaf, color: 'bg-green-500', enabled: false },
  ]);

  const pois: POIType[] = [
    // Parks & Green Spaces
    { id: 1, name: 'Sarasbaug Park', type: 'park', lat: 18.508, lng: 73.847, icon: '🌳', category: 'Parks' },
    { id: 2, name: 'Peshwe Park', type: 'park', lat: 18.512, lng: 73.863, icon: '🌳', category: 'Parks' },
    { id: 3, name: 'Sambhaji Park', type: 'park', lat: 18.528, lng: 73.849, icon: '🌳', category: 'Parks' },
    { id: 4, name: 'Bund Garden', type: 'park', lat: 18.533, lng: 73.884, icon: '🌲', category: 'Parks' },
    { id: 5, name: 'Empress Garden', type: 'park', lat: 18.517, lng: 73.878, icon: '🌲', category: 'Parks' },
    
    // EV Charging Stations
    { id: 6, name: 'EV Hub FC Road', type: 'ev', lat: 18.518, lng: 73.854, icon: '⚡', category: 'EV Charging' },
    { id: 7, name: 'EV Station Kalyani Nagar', type: 'ev', lat: 18.548, lng: 73.902, icon: '⚡', category: 'EV Charging' },
    { id: 8, name: 'EV Charging Kothrud', type: 'ev', lat: 18.506, lng: 73.824, icon: '⚡', category: 'EV Charging' },
    { id: 9, name: 'EV Point Koregaon Park', type: 'ev', lat: 18.542, lng: 73.893, icon: '⚡', category: 'EV Charging' },
    
    // Safe Walk Zones
    { id: 10, name: 'Safe Walk Zone', type: 'safe', lat: 18.515, lng: 73.851, icon: '🚶', category: 'Safety' },
    { id: 11, name: 'Pedestrian Plaza', type: 'safe', lat: 18.522, lng: 73.867, icon: '🚶', category: 'Safety' },
    { id: 12, name: 'Walking Path MG Road', type: 'safe', lat: 18.525, lng: 73.873, icon: '🚶', category: 'Safety' },
    
    // Transit Hubs
    { id: 13, name: 'Pune Railway Station', type: 'transit', lat: 18.528, lng: 73.874, icon: '🚉', category: 'Transit' },
    { id: 14, name: 'Shivajinagar Bus Stand', type: 'transit', lat: 18.530, lng: 73.851, icon: '🚌', category: 'Transit' },
    { id: 15, name: 'Swargate Bus Terminal', type: 'transit', lat: 18.501, lng: 73.867, icon: '🚌', category: 'Transit' },
    { id: 16, name: 'Metro Station PMC', type: 'transit', lat: 18.524, lng: 73.859, icon: '🚇', category: 'Transit' },
    
    // Restaurants & Cafes
    { id: 17, name: 'German Bakery', type: 'cafe', lat: 18.541, lng: 73.890, icon: '☕', category: 'Food' },
    { id: 18, name: 'Cafe Goodluck', type: 'cafe', lat: 18.524, lng: 73.869, icon: '☕', category: 'Food' },
    { id: 19, name: 'Vaishali Restaurant', type: 'restaurant', lat: 18.524, lng: 73.869, icon: '🍽️', category: 'Food' },
    { id: 20, name: 'Malaka Spice', type: 'restaurant', lat: 18.542, lng: 73.888, icon: '🍽️', category: 'Food' },
    
    // Hospitals
    { id: 21, name: 'Ruby Hall Clinic', type: 'hospital', lat: 18.525, lng: 73.868, icon: '🏥', category: 'Healthcare' },
    { id: 22, name: 'Sahyadri Hospital', type: 'hospital', lat: 18.511, lng: 73.863, icon: '🏥', category: 'Healthcare' },
    
    // Schools
    { id: 23, name: 'Symbiosis School', type: 'school', lat: 18.503, lng: 73.819, icon: '🎓', category: 'Education' },
    { id: 24, name: 'Bishop\'s School', type: 'school', lat: 18.544, lng: 73.889, icon: '🎓', category: 'Education' },
    
    // Shopping
    { id: 25, name: 'Phoenix Marketcity', type: 'shopping', lat: 18.559, lng: 73.912, icon: '🛍️', category: 'Shopping' },
    { id: 26, name: 'SGS Mall', type: 'shopping', lat: 18.512, lng: 73.824, icon: '🛍️', category: 'Shopping' },
    { id: 27, name: 'Amanora Mall', type: 'shopping', lat: 18.517, lng: 73.915, icon: '🛍️', category: 'Shopping' },
    
    // More Parks
    { id: 28, name: 'Taljai Tekdi', type: 'park', lat: 18.516, lng: 73.833, icon: '🌲', category: 'Parks' },
    { id: 29, name: 'Shaniwar Wada', type: 'park', lat: 18.519, lng: 73.856, icon: '🏛️', category: 'Heritage' },
    
    // More EV Stations
    { id: 30, name: 'EV Hub Baner', type: 'ev', lat: 18.559, lng: 73.781, icon: '⚡', category: 'EV Charging' },
    { id: 31, name: 'EV Station Hadapsar', type: 'ev', lat: 18.508, lng: 73.927, icon: '⚡', category: 'EV Charging' },
    
    // More Cafes & Restaurants
    { id: 32, name: 'Barista FC Road', type: 'cafe', lat: 18.520, lng: 73.852, icon: '☕', category: 'Food' },
    { id: 33, name: 'Cafe Coffee Day', type: 'cafe', lat: 18.527, lng: 73.863, icon: '☕', category: 'Food' },
    { id: 34, name: 'Burger King', type: 'restaurant', lat: 18.523, lng: 73.857, icon: '🍔', category: 'Food' },
    { id: 35, name: 'McDonald\'s', type: 'restaurant', lat: 18.532, lng: 73.878, icon: '🍔', category: 'Food' },
    
    // More Safe Walk Zones
    { id: 36, name: 'Safe Path Deccan', type: 'safe', lat: 18.516, lng: 73.845, icon: '🚶', category: 'Safety' },
    { id: 37, name: 'Walking Zone Kothrud', type: 'safe', lat: 18.502, lng: 73.832, icon: '🚶', category: 'Safety' },
    
    // More Transit
    { id: 38, name: 'Hadapsar Bus Stop', type: 'transit', lat: 18.505, lng: 73.928, icon: '🚌', category: 'Transit' },
    { id: 39, name: 'Baner Metro Station', type: 'transit', lat: 18.558, lng: 73.784, icon: '🚇', category: 'Transit' },
    
    // Hospitals
    { id: 40, name: 'Columbia Asia Hospital', type: 'hospital', lat: 18.510, lng: 73.826, icon: '🏥', category: 'Healthcare' },
    { id: 41, name: 'Deenanath Hospital', type: 'hospital', lat: 18.507, lng: 73.841, icon: '🏥', category: 'Healthcare' },
  ];

  const routes: RouteOption[] = [
    {
      id: 1,
      name: 'Eco-Friendly Route',
      duration: '18 min',
      distance: '5.2 km',
      co2Saved: 420,
      trafficLevel: 'low',
      badge: 'green',
    },
    {
      id: 2,
      name: 'Balanced Route',
      duration: '15 min',
      distance: '6.8 km',
      co2Saved: 180,
      trafficLevel: 'medium',
      badge: 'amber',
    },
    {
      id: 3,
      name: 'Fastest Route',
      duration: '12 min',
      distance: '7.5 km',
      co2Saved: 0,
      trafficLevel: 'high',
      badge: 'red',
    },
  ];

  const toggleLayer = (id: string) => {
    setLayers(layers.map(layer => 
      layer.id === id ? { ...layer, enabled: !layer.enabled } : layer
    ));
  };

  const getBadgeColor = (badge: string) => {
    switch (badge) {
      case 'green': return 'bg-green-500';
      case 'amber': return 'bg-amber-500';
      case 'red': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const getTrafficText = (level: string) => {
    switch (level) {
      case 'low': return 'Light Traffic';
      case 'medium': return 'Moderate Traffic';
      case 'high': return 'Heavy Traffic';
      default: return 'Unknown';
    }
  };

  const getPOIColor = (type: string) => {
    switch (type) {
      case 'park': return 'border-green-500 bg-green-50';
      case 'ev': return 'border-blue-500 bg-blue-50';
      case 'safe': return 'border-emerald-500 bg-emerald-50';
      case 'transit': return 'border-purple-500 bg-purple-50';
      case 'cafe':
      case 'restaurant': return 'border-orange-500 bg-orange-50';
      case 'hospital': return 'border-red-500 bg-red-50';
      case 'school': return 'border-indigo-500 bg-indigo-50';
      case 'shopping': return 'border-pink-500 bg-pink-50';
      default: return 'border-gray-300 bg-white';
    }
  };

  const handleSearch = () => {
    if (searchQuery.trim()) {
      // Simulate map movement when searching
      setMapCenter({ 
        x: 40 + Math.random() * 20, 
        y: 40 + Math.random() * 20 
      });
      setShowRoutes(true);
    }
  };

  const handleZoomIn = () => {
    setMapZoom(Math.min(mapZoom + 0.2, 2));
  };

  const handleZoomOut = () => {
    setMapZoom(Math.max(mapZoom - 0.2, 0.5));
  };

  return (
    <div className={`flex-1 flex flex-col relative overflow-hidden ${isDark ? 'bg-gray-900' : ''}`}>
      {/* Search Bar */}
      <div className="absolute top-4 left-4 right-4 z-30">
        <div className={`rounded-2xl shadow-2xl border flex items-center gap-3 px-4 py-3.5 ${
          isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'
        }`}>
          <Search className={`w-5 h-5 ${isDark ? 'text-gray-400' : 'text-gray-400'}`} />
          <input
            type="text"
            placeholder="Search location, POI..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
            className={`flex-1 outline-none placeholder-gray-400 ${
              isDark ? 'bg-transparent text-gray-200' : 'text-gray-900'
            }`}
          />
          {searchQuery && (
            <button onClick={() => setSearchQuery('')}>
              <X className={`w-5 h-5 ${isDark ? 'text-gray-500' : 'text-gray-400'}`} />
            </button>
          )}
        </div>
      </div>

      {/* Map Area - More Realistic */}
      <div className={`flex-1 relative overflow-hidden ${isDark ? 'bg-gray-800' : 'bg-[#e5e3df]'}`}>
        {/* Base map layer with realistic colors */}
        <div 
          className="absolute inset-0 transition-transform duration-500 cursor-move"
          style={{
            background: isDark 
              ? 'linear-gradient(180deg, #2d3748 0%, #1a202c 100%)' 
              : 'linear-gradient(180deg, #f2f1ed 0%, #e5e3df 100%)',
            transform: `scale(${mapZoom}) translate(${(mapCenter.x - 50) * 2}%, ${(mapCenter.y - 50) * 2}%)`,
          }}
          onWheel={(e) => {
            e.preventDefault();
            if (e.deltaY < 0) {
              handleZoomIn();
            } else {
              handleZoomOut();
            }
          }}>
          {/* Water bodies */}
          <div className="absolute top-[15%] right-[10%] w-[25%] h-[20%] bg-[#aad3df] rounded-full opacity-70"></div>
          <div className="absolute bottom-[20%] left-[5%] w-[20%] h-[15%] bg-[#aad3df] rounded-full opacity-70"></div>

          {/* Green areas (parks) */}
          <div className="absolute top-[10%] left-[15%] w-[18%] h-[18%] bg-[#c8e6c9] rounded-lg opacity-60"></div>
          <div className="absolute bottom-[25%] right-[20%] w-[22%] h-[20%] bg-[#c8e6c9] rounded-lg opacity-60"></div>
          <div className="absolute top-[40%] left-[40%] w-[15%] h-[15%] bg-[#c8e6c9] rounded-lg opacity-60"></div>

          {/* Major Roads - More realistic styling */}
          {/* Horizontal roads */}
          <div className="absolute top-[20%] left-0 right-0 h-[5px] bg-white shadow-sm">
            <div className="absolute inset-0 bg-gradient-to-b from-gray-300 to-gray-400"></div>
          </div>
          <div className="absolute top-[35%] left-0 right-0 h-[6px] bg-white shadow-md">
            <div className="absolute inset-0 bg-gradient-to-b from-gray-300 to-gray-500"></div>
            <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-yellow-300 opacity-70" style={{ 
              backgroundImage: 'repeating-linear-gradient(90deg, #ffd700 0, #ffd700 20px, transparent 20px, transparent 40px)' 
            }}></div>
          </div>
          <div className="absolute top-[50%] left-0 right-0 h-[8px] bg-white shadow-lg">
            <div className="absolute inset-0 bg-gradient-to-b from-gray-400 to-gray-600"></div>
            <div className="absolute top-1/2 left-0 right-0 h-[1px] bg-yellow-300 opacity-70" style={{ 
              backgroundImage: 'repeating-linear-gradient(90deg, #ffd700 0, #ffd700 30px, transparent 30px, transparent 60px)' 
            }}></div>
          </div>
          <div className="absolute top-[65%] left-0 right-0 h-[5px] bg-white shadow-sm">
            <div className="absolute inset-0 bg-gradient-to-b from-gray-300 to-gray-400"></div>
          </div>
          <div className="absolute top-[80%] left-0 right-0 h-[4px] bg-white shadow-sm">
            <div className="absolute inset-0 bg-gradient-to-b from-gray-200 to-gray-300"></div>
          </div>

          {/* Vertical roads */}
          <div className="absolute top-0 bottom-0 left-[15%] w-[5px] bg-white shadow-sm">
            <div className="absolute inset-0 bg-gradient-to-r from-gray-300 to-gray-400"></div>
          </div>
          <div className="absolute top-0 bottom-0 left-[30%] w-[6px] bg-white shadow-md">
            <div className="absolute inset-0 bg-gradient-to-r from-gray-300 to-gray-500"></div>
          </div>
          <div className="absolute top-0 bottom-0 left-[50%] w-[8px] bg-white shadow-lg">
            <div className="absolute inset-0 bg-gradient-to-r from-gray-400 to-gray-600"></div>
          </div>
          <div className="absolute top-0 bottom-0 left-[70%] w-[5px] bg-white shadow-sm">
            <div className="absolute inset-0 bg-gradient-to-r from-gray-300 to-gray-400"></div>
          </div>
          <div className="absolute top-0 bottom-0 left-[85%] w-[4px] bg-white shadow-sm">
            <div className="absolute inset-0 bg-gradient-to-r from-gray-200 to-gray-300"></div>
          </div>

          {/* Minor roads network */}
          <div className="absolute top-[25%] left-0 right-0 h-[3px] bg-gray-100 opacity-60"></div>
          <div className="absolute top-[42%] left-0 right-0 h-[3px] bg-gray-100 opacity-60"></div>
          <div className="absolute top-[58%] left-0 right-0 h-[3px] bg-gray-100 opacity-60"></div>
          <div className="absolute top-[72%] left-0 right-0 h-[3px] bg-gray-100 opacity-60"></div>
          <div className="absolute top-0 bottom-0 left-[22%] w-[3px] bg-gray-100 opacity-60"></div>
          <div className="absolute top-0 bottom-0 left-[40%] w-[3px] bg-gray-100 opacity-60"></div>
          <div className="absolute top-0 bottom-0 left-[60%] w-[3px] bg-gray-100 opacity-60"></div>
          <div className="absolute top-0 bottom-0 left-[78%] w-[3px] bg-gray-100 opacity-60"></div>

          {/* Traffic Layer Overlays with animation */}
          {layers.find(l => l.id === 'traffic' && l.enabled) && (
            <>
              <div className="absolute top-[50%] left-0 w-[45%] h-[8px] bg-red-500 opacity-50 animate-pulse" 
                style={{ filter: 'blur(2px)' }}></div>
              <div className="absolute top-[35%] left-[30%] right-[20%] h-[6px] bg-orange-500 opacity-40 animate-pulse" 
                style={{ filter: 'blur(2px)', animationDelay: '0.5s' }}></div>
              <div className="absolute top-[50%] left-[50%] bottom-0 w-[8px] bg-yellow-500 opacity-35" 
                style={{ filter: 'blur(2px)' }}></div>
            </>
          )}
          
          {/* Air Quality Layer with gradient zones */}
          {layers.find(l => l.id === 'aqi' && l.enabled) && (
            <>
              <div className="absolute top-[10%] right-[5%] w-[35%] h-[30%] bg-green-400 opacity-15 rounded-full blur-3xl"></div>
              <div className="absolute bottom-[25%] left-[10%] w-[40%] h-[35%] bg-emerald-400 opacity-15 rounded-full blur-3xl"></div>
              <div className="absolute top-[45%] right-[30%] w-[25%] h-[25%] bg-yellow-400 opacity-12 rounded-full blur-3xl"></div>
            </>
          )}
          
          {/* Noise Layer */}
          {layers.find(l => l.id === 'noise' && l.enabled) && (
            <>
              <div className="absolute top-[48%] left-[48%] w-[30%] h-[30%] bg-purple-500 opacity-15 rounded-full blur-3xl"></div>
              <div className="absolute bottom-[15%] right-[15%] w-[25%] h-[25%] bg-purple-400 opacity-12 rounded-full blur-3xl"></div>
              <div className="absolute top-[20%] left-[20%] w-[20%] h-[20%] bg-purple-600 opacity-10 rounded-full blur-3xl"></div>
            </>
          )}

          {/* Quiet Routes Layer */}
          {layers.find(l => l.id === 'quiet' && l.enabled) && (
            <>
              <div className="absolute top-[25%] left-[15%] right-[70%] h-[3px] bg-green-500 opacity-60" 
                style={{ filter: 'blur(1px)' }}></div>
              <div className="absolute top-[25%] bottom-[60%] left-[30%] w-[3px] bg-green-500 opacity-60" 
                style={{ filter: 'blur(1px)' }}></div>
            </>
          )}

          {/* POI Markers - Professional styling */}
          {pois.map((poi) => (
            <div
              key={poi.id}
              className="absolute"
              style={{
                left: `${(poi.lng - 73.80) * 1500}%`,
                top: `${(18.56 - poi.lat) * 1500}%`,
              }}
            >
              <div className="relative group">
                <div className={`w-9 h-9 rounded-full shadow-lg border-2 flex items-center justify-center text-base hover:scale-125 transition-all cursor-pointer ${getPOIColor(poi.type)}`}>
                  {poi.icon}
                </div>
                {/* Professional tooltip */}
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-xl z-50">
                  <div className="font-medium">{poi.name}</div>
                  <div className="text-gray-400 text-[10px] mt-0.5">{poi.category}</div>
                  {/* Arrow */}
                  <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-px">
                    <div className="border-4 border-transparent border-t-gray-900"></div>
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Current Location Pin - Enhanced */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
            <div className="relative">
              <div className="w-5 h-5 bg-blue-600 rounded-full border-4 border-white shadow-2xl z-10 relative"></div>
              <div className="absolute inset-0 w-5 h-5 bg-blue-400 rounded-full animate-ping"></div>
              <div className="absolute inset-0 w-5 h-5 bg-blue-300 rounded-full animate-ping" style={{ animationDelay: '0.5s' }}></div>
            </div>
          </div>

          {/* Route Lines - Enhanced when selected */}
          {selectedRoute && (
            <>
              <svg className="absolute inset-0 w-full h-full pointer-events-none">
                <defs>
                  <filter id="glow">
                    <feGaussianBlur stdDeviation="2" result="coloredBlur"/>
                    <feMerge>
                      <feMergeNode in="coloredBlur"/>
                      <feMergeNode in="SourceGraphic"/>
                    </feMerge>
                  </filter>
                </defs>
                <path
                  d={selectedRoute === 1 
                    ? "M 50% 50% Q 55% 35%, 65% 38% T 78% 45%" 
                    : selectedRoute === 2
                    ? "M 50% 50% L 60% 48% L 70% 46% L 78% 45%"
                    : "M 50% 50% L 58% 50% L 68% 50% L 78% 45%"
                  }
                  stroke={selectedRoute === 1 ? '#10b981' : selectedRoute === 2 ? '#f59e0b' : '#ef4444'}
                  strokeWidth="5"
                  fill="none"
                  strokeDasharray="10,5"
                  className="animate-pulse"
                  filter="url(#glow)"
                  opacity="0.8"
                />
              </svg>
            </>
          )}
        </div>
      </div>

      {/* Zoom Controls */}
      <div className="absolute top-24 left-4 z-30 flex flex-col gap-2">
        <button
          onClick={handleZoomIn}
          className={`rounded-xl shadow-xl p-3 hover:scale-105 transition-all ${
            isDark ? 'bg-gray-800 border border-gray-700 text-gray-200 hover:bg-gray-700' : 'bg-white border border-gray-100 hover:bg-gray-50'
          }`}
        >
          <span className="text-xl">+</span>
        </button>
        <button
          onClick={handleZoomOut}
          className={`rounded-xl shadow-xl p-3 hover:scale-105 transition-all ${
            isDark ? 'bg-gray-800 border border-gray-700 text-gray-200 hover:bg-gray-700' : 'bg-white border border-gray-100 hover:bg-gray-50'
          }`}
        >
          <span className="text-xl">−</span>
        </button>
      </div>

      {/* Layer Toggle Button */}
      <button
        onClick={() => setShowLayers(!showLayers)}
        className={`absolute top-24 right-4 z-30 rounded-xl shadow-xl border p-3 transition-all ${
          showLayers 
            ? 'bg-blue-50 border-blue-200' 
            : isDark 
              ? 'bg-gray-800 border-gray-700 hover:bg-gray-700' 
              : 'bg-white border-gray-100 hover:bg-gray-50'
        }`}
      >
        <Layers className={`w-6 h-6 ${showLayers ? 'text-blue-600' : isDark ? 'text-gray-200' : 'text-gray-700'}`} />
      </button>

      {/* Current Location Button */}
      <button className="absolute top-48 right-4 z-30 bg-blue-600 rounded-xl shadow-xl p-3 hover:bg-blue-700 transition-all hover:scale-105">
        <Navigation2 className="w-6 h-6 text-white" />
      </button>

      {/* Layer Panel - Enhanced */}
      {showLayers && (
        <div className={`absolute top-24 right-20 z-30 rounded-2xl shadow-2xl border p-4 w-52 animate-in fade-in slide-in-from-right-5 duration-200 ${
          isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'
        }`}>
          <div className="flex items-center justify-between mb-4">
            <span className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>Map Layers</span>
            <button onClick={() => setShowLayers(false)} className={`rounded-lg p-1 transition-colors ${
              isDark ? 'hover:bg-gray-700' : 'hover:bg-gray-100'
            }`}>
              <X className={`w-4 h-4 ${isDark ? 'text-gray-400' : 'text-gray-400'}`} />
            </button>
          </div>
          <div className="space-y-2">
            {layers.map((layer) => {
              const Icon = layer.icon;
              return (
                <button
                  key={layer.id}
                  onClick={() => toggleLayer(layer.id)}
                  className={`w-full flex items-center gap-3 p-2.5 rounded-xl transition-all ${
                    layer.enabled ? 'bg-blue-50 border-2 border-blue-200 shadow-sm' : 'bg-gray-50 border-2 border-transparent hover:border-gray-200'
                  }`}
                >
                  <div className={`w-3 h-3 rounded-full ${layer.color} ${!layer.enabled && 'opacity-30'} shadow-sm`}></div>
                  <Icon className={`w-4 h-4 ${layer.enabled ? 'text-blue-600' : isDark ? 'text-gray-500' : 'text-gray-400'}`} />
                  <span className={`text-sm flex-1 text-left ${layer.enabled ? (isDark ? 'text-gray-200' : 'text-gray-900') : (isDark ? 'text-gray-600' : 'text-gray-500')}`}>
                    {layer.name}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Route Options Bottom Sheet - Enhanced */}
      <div className={`absolute bottom-0 left-0 right-0 z-40 rounded-t-3xl shadow-2xl border-t ${
        isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'
      }`}>
        <div className={`px-4 py-3 border-b ${isDark ? 'border-gray-700' : 'border-gray-100'}`}>
          <button
            onClick={() => setShowRoutes(!showRoutes)}
            className="w-full flex items-center justify-between"
          >
            <div className="flex items-center gap-2">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${
                isDark ? 'bg-blue-900/50' : 'bg-blue-100'
              }`}>
                <Navigation2 className="w-5 h-5 text-blue-600" />
              </div>
              <span className={isDark ? 'text-gray-200' : 'text-gray-900'}>Route Options</span>
            </div>
            <ChevronDown className={`w-5 h-5 transition-transform ${showRoutes ? 'rotate-180' : ''} ${
              isDark ? 'text-gray-500' : 'text-gray-400'
            }`} />
          </button>
        </div>

        {showRoutes && (
          <div className="p-4 space-y-3 max-h-64 overflow-y-auto">
            {routes.map((route) => (
              <button
                key={route.id}
                onClick={() => setSelectedRoute(route.id)}
                className={`w-full border-2 rounded-2xl p-4 transition-all ${
                  selectedRoute === route.id
                    ? 'border-blue-600 bg-blue-50 shadow-lg scale-[1.02]'
                    : isDark 
                      ? 'border-gray-700 hover:border-gray-600 bg-gray-700 hover:shadow-md'
                      : 'border-gray-200 hover:border-gray-300 bg-white hover:shadow-md'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-3 h-3 rounded-full ${getBadgeColor(route.badge)} shadow-sm`}></div>
                    <span className={isDark ? 'text-gray-200' : 'text-gray-900'}>{route.name}</span>
                  </div>
                  {route.co2Saved > 0 && (
                    <div className="flex items-center gap-1 text-green-600 text-sm bg-green-50 px-2 py-1 rounded-lg">
                      <Leaf className="w-3.5 h-3.5" />
                      <span>-{route.co2Saved}g</span>
                    </div>
                  )}
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-4">
                    <div>
                      <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>Duration</div>
                      <div className={isDark ? 'text-gray-200' : 'text-gray-900'}>{route.duration}</div>
                    </div>
                    <div>
                      <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>Distance</div>
                      <div className={isDark ? 'text-gray-200' : 'text-gray-900'}>{route.distance}</div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>Traffic</div>
                    <div className={`text-sm ${
                      route.trafficLevel === 'low' ? 'text-green-600' :
                      route.trafficLevel === 'medium' ? 'text-amber-600' :
                      'text-red-600'
                    }`}>
                      {getTrafficText(route.trafficLevel)}
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}

        {!showRoutes && selectedRoute && (
          <div className="p-4">
            <button className="w-full bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white py-3.5 rounded-xl transition-all flex items-center justify-center gap-2 shadow-lg hover:shadow-xl hover:scale-[1.02]">
              <Navigation2 className="w-5 h-5" />
              <span>Start Navigation</span>
            </button>
          </div>
        )}
      </div>

      {/* Legend - Enhanced */}
      <div className={`absolute bottom-36 left-4 z-30 rounded-xl shadow-xl border p-3 ${
        isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-100'
      }`}>
        <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Route Quality</div>
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-green-500 shadow-sm"></div>
            <span className={`text-xs ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Eco-Friendly</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-amber-500 shadow-sm"></div>
            <span className={`text-xs ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Balanced</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500 shadow-sm"></div>
            <span className={`text-xs ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Heavy Traffic</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-blue-500 shadow-sm"></div>
            <span className={`text-xs ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Disable Friendly</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-purple-500 shadow-sm"></div>
            <span className={`text-xs ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>Pets Friendly</span>
          </div>
        </div>
      </div>
    </div>
  );
}
