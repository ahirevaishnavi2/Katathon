import { Activity, AlertTriangle, Camera, TrendingUp, TrendingDown, BarChart3 } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface DashboardPageProps {
  isDark?: boolean;
}

const congestionData = [
  { time: '6AM', level: 20 },
  { time: '9AM', level: 75 },
  { time: '12PM', level: 45 },
  { time: '3PM', level: 60 },
  { time: '6PM', level: 90 },
  { time: '9PM', level: 35 },
];

const violationData = [
  { type: 'Speeding', count: 45 },
  { type: 'Red Light', count: 32 },
  { type: 'Wrong Lane', count: 28 },
  { type: 'No Helmet', count: 19 },
];

export default function DashboardPage({ isDark }: DashboardPageProps) {
  const metrics = [
    {
      title: 'Traffic Exemption Score',
      value: '8.5',
      unit: '/10',
      change: '+0.3',
      trend: 'up',
      icon: Activity,
      gradient: 'from-[#2e7d32] to-[#1b5e20]',
      bgColor: isDark ? 'bg-[#2e7d32]/20' : 'bg-[#e8f5e9]',
    },
    {
      title: 'Congestion Level',
      value: '65',
      unit: '%',
      change: '-5%',
      trend: 'down',
      icon: TrendingUp,
      gradient: 'from-[#1976d2] to-[#0d47a1]',
      bgColor: isDark ? 'bg-[#1976d2]/20' : 'bg-[#e3f2fd]',
    },
    {
      title: 'Active Alerts',
      value: '12',
      unit: '',
      change: '+3',
      trend: 'up',
      icon: AlertTriangle,
      gradient: 'from-[#ff9800] to-[#f57c00]',
      bgColor: isDark ? 'bg-[#ff9800]/20' : 'bg-[#fff3e0]',
    },
    {
      title: 'Violations Detected',
      value: '124',
      unit: '',
      change: '-8',
      trend: 'down',
      icon: BarChart3,
      gradient: 'from-[#d32f2f] to-[#c62828]',
      bgColor: isDark ? 'bg-[#d32f2f]/20' : 'bg-[#ffebee]',
    },
    {
      title: 'Active Cameras',
      value: '48',
      unit: '/52',
      change: '92%',
      trend: 'up',
      icon: Camera,
      gradient: 'from-[#7b1fa2] to-[#6a1b9a]',
      bgColor: isDark ? 'bg-[#7b1fa2]/20' : 'bg-[#f3e5f5]',
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto pb-24 px-4 py-6">
      {/* Page Title */}
      <div className="mb-6">
        <h1 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
          Dashboard
        </h1>
        <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
          Real-time traffic management overview
        </p>
      </div>

      {/* KPI Metrics Grid */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          const isPositive = metric.trend === 'up';
          const TrendIcon = isPositive ? TrendingUp : TrendingDown;
          
          return (
            <div
              key={index}
              className={`rounded-2xl p-4 transition-all ${
                isDark ? 'bg-[#1e1e1e]' : 'bg-white'
              }`}
              style={{ boxShadow: 'var(--shadow)' }}
            >
              <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${metric.bgColor}`}>
                <Icon className={`w-6 h-6 ${isDark ? 'text-white' : 'text-gray-700'}`} />
              </div>
              
              <div className={`text-xs mb-1 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                {metric.title}
              </div>
              
              <div className="flex items-baseline gap-1 mb-2">
                <span className={`text-2xl ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  {metric.value}
                </span>
                <span className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                  {metric.unit}
                </span>
              </div>
              
              <div className="flex items-center gap-1">
                <TrendIcon className={`w-3 h-3 ${isPositive ? 'text-[#4caf50]' : 'text-[#ef5350]'}`} />
                <span className={`text-xs ${isPositive ? 'text-[#4caf50]' : 'text-[#ef5350]'}`}>
                  {metric.change}
                </span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Congestion Timeline */}
      <div
        className={`rounded-2xl p-5 mb-6 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow)' }}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
              Congestion Timeline
            </h3>
            <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Today's traffic pattern
            </p>
          </div>
        </div>
        
        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={congestionData}>
            <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#333' : '#e0e0e0'} />
            <XAxis 
              dataKey="time" 
              stroke={isDark ? '#9e9e9e' : '#666'}
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke={isDark ? '#9e9e9e' : '#666'}
              style={{ fontSize: '12px' }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: isDark ? '#1e1e1e' : '#fff',
                border: `1px solid ${isDark ? '#333' : '#e0e0e0'}`,
                borderRadius: '12px',
              }}
            />
            <Line 
              type="monotone" 
              dataKey="level" 
              stroke="#1976d2" 
              strokeWidth={3}
              dot={{ fill: '#1976d2', r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Violations by Type */}
      <div
        className={`rounded-2xl p-5 mb-6 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow)' }}
      >
        <div className="mb-4">
          <h3 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            Violations by Type
          </h3>
          <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Last 24 hours
          </p>
        </div>
        
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={violationData}>
            <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#333' : '#e0e0e0'} />
            <XAxis 
              dataKey="type" 
              stroke={isDark ? '#9e9e9e' : '#666'}
              style={{ fontSize: '11px' }}
            />
            <YAxis 
              stroke={isDark ? '#9e9e9e' : '#666'}
              style={{ fontSize: '12px' }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: isDark ? '#1e1e1e' : '#fff',
                border: `1px solid ${isDark ? '#333' : '#e0e0e0'}`,
                borderRadius: '12px',
              }}
            />
            <Bar dataKey="count" fill="#2e7d32" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4">
        <div
          className={`rounded-2xl p-5 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
          style={{ boxShadow: 'var(--shadow)' }}
        >
          <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Avg. Response Time
          </div>
          <div className={`text-2xl mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            4.2 <span className="text-sm">min</span>
          </div>
          <div className="flex items-center gap-1">
            <TrendingDown className="w-3 h-3 text-[#4caf50]" />
            <span className="text-xs text-[#4caf50]">-1.2 min</span>
          </div>
        </div>

        <div
          className={`rounded-2xl p-5 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
          style={{ boxShadow: 'var(--shadow)' }}
        >
          <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            System Uptime
          </div>
          <div className={`text-2xl mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            99.8 <span className="text-sm">%</span>
          </div>
          <div className="flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-[#4caf50]" />
            <span className="text-xs text-[#4caf50]">Excellent</span>
          </div>
        </div>
      </div>
    </div>
  );
}
