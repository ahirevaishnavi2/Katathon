import { Camera, MapPin, Circle, ExternalLink, Search, Activity, Zap, TrendingUp } from 'lucide-react';
import { useState } from 'react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';

interface CamerasPageProps {
  isDark?: boolean;
}

export default function CamerasPage({ isDark }: CamerasPageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatus, setSelectedStatus] = useState<'all' | 'online' | 'offline'>('all');

  const cameraImages = [
    'https://images.unsplash.com/photo-1757359315231-2a2b890a65f6?w=400&h=225&fit=crop&q=80',
    'https://images.unsplash.com/photo-1733149086985-7e607db85843?w=400&h=225&fit=crop&q=80',
    'https://images.unsplash.com/photo-1544535031-b2fe56200d38?w=400&h=225&fit=crop&q=80',
    'https://images.unsplash.com/photo-1501829634390-7c98deb33171?w=400&h=225&fit=crop&q=80',
    'https://images.unsplash.com/photo-1552657787-6ea206193eca?w=400&h=225&fit=crop&q=80',
    'https://images.unsplash.com/photo-1758635732050-4188091f3d1e?w=400&h=225&fit=crop&q=80',
    'https://images.unsplash.com/photo-1630241772217-5d4926c594cc?w=400&h=225&fit=crop&q=80',
    'https://images.unsplash.com/photo-1687069295578-ea662f5e490e?w=400&h=225&fit=crop&q=80',
  ];

  const cameras = [
    {
      id: 'CAM-001',
      name: 'FC Road Junction',
      location: 'FC Road, Pune',
      status: 'online',
      quality: 'HD',
      lastUpdate: '2 mins ago',
      image: cameraImages[0],
    },
    {
      id: 'CAM-002',
      name: 'Shivajinagar Circle',
      location: 'Shivajinagar, Pune',
      status: 'online',
      quality: '4K',
      lastUpdate: '1 min ago',
      image: cameraImages[1],
    },
    {
      id: 'CAM-003',
      name: 'Deccan Gymkhana',
      location: 'Deccan, Pune',
      status: 'online',
      quality: 'HD',
      lastUpdate: '3 mins ago',
      image: cameraImages[2],
    },
    {
      id: 'CAM-004',
      name: 'Swargate Square',
      location: 'Swargate, Pune',
      status: 'offline',
      quality: 'HD',
      lastUpdate: '15 mins ago',
      image: cameraImages[3],
    },
    {
      id: 'CAM-005',
      name: 'Kothrud Depot',
      location: 'Kothrud, Pune',
      status: 'online',
      quality: 'HD',
      lastUpdate: '1 min ago',
      image: cameraImages[4],
    },
    {
      id: 'CAM-006',
      name: 'Hadapsar Signal',
      location: 'Hadapsar, Pune',
      status: 'offline',
      quality: '4K',
      lastUpdate: '22 mins ago',
      image: cameraImages[5],
    },
    {
      id: 'CAM-007',
      name: 'Wakad Junction',
      location: 'Wakad, Pune',
      status: 'online',
      quality: 'HD',
      lastUpdate: '4 mins ago',
      image: cameraImages[6],
    },
    {
      id: 'CAM-008',
      name: 'Hinjewadi IT Park',
      location: 'Hinjewadi, Pune',
      status: 'online',
      quality: '4K',
      lastUpdate: '2 mins ago',
      image: cameraImages[7],
    },
  ];

  const filteredCameras = cameras.filter(camera => {
    const matchesSearch = camera.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         camera.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = selectedStatus === 'all' || camera.status === selectedStatus;
    return matchesSearch && matchesStatus;
  });

  const onlineCount = cameras.filter(c => c.status === 'online').length;
  const offlineCount = cameras.filter(c => c.status === 'offline').length;
  const uptimePercentage = Math.round((onlineCount / cameras.length) * 100);

  return (
    <div className="flex-1 overflow-y-auto pb-24 px-4 py-6">
      {/* Page Title */}
      <div className="mb-6">
        <h1 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
          Live Cameras
        </h1>
        <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
          Monitor traffic cameras across the city
        </p>
      </div>

      {/* Enhanced Status Summary */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div
          className={`rounded-2xl p-5 relative overflow-hidden ${isDark ? 'bg-gradient-to-br from-[#1e1e1e] to-[#2a2a2a]' : 'bg-gradient-to-br from-white to-gray-50'}`}
          style={{ boxShadow: 'var(--shadow-lg)' }}
        >
          <div className="absolute top-2 right-2 opacity-10">
            <Camera className="w-16 h-16" />
          </div>
          <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Total
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <div className={`text-3xl ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
              {cameras.length}
            </div>
            <Activity className="w-4 h-4 text-[#1976d2]" />
          </div>
          <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
            Cameras
          </div>
        </div>

        <div
          className={`rounded-2xl p-5 relative overflow-hidden ${isDark ? 'bg-gradient-to-br from-[#2e7d32]/20 to-[#1b5e20]/20' : 'bg-gradient-to-br from-[#e8f5e9] to-[#c8e6c9]'}`}
          style={{ boxShadow: 'var(--shadow-lg)' }}
        >
          <div className="absolute top-2 right-2 opacity-20">
            <Zap className="w-16 h-16 text-[#4caf50]" />
          </div>
          <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Online
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <div className="text-3xl text-[#4caf50]">
              {onlineCount}
            </div>
            <div className="px-2 py-0.5 rounded-full bg-[#4caf50]/20 text-[#4caf50] text-xs">
              Live
            </div>
          </div>
          <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
            Active streams
          </div>
        </div>

        <div
          className={`rounded-2xl p-5 relative overflow-hidden ${isDark ? 'bg-gradient-to-br from-[#1976d2]/20 to-[#1565c0]/20' : 'bg-gradient-to-br from-[#e3f2fd] to-[#bbdefb]'}`}
          style={{ boxShadow: 'var(--shadow-lg)' }}
        >
          <div className="absolute top-2 right-2 opacity-20">
            <TrendingUp className="w-16 h-16 text-[#1976d2]" />
          </div>
          <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Uptime
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <div className="text-3xl text-[#1976d2]">
              {uptimePercentage}%
            </div>
          </div>
          <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
            System health
          </div>
        </div>
      </div>

      {/* Search and Filter */}
      <div className="space-y-3 mb-6">
        {/* Search */}
        <div
          className={`rounded-2xl px-4 py-3 flex items-center gap-3 ${
            isDark ? 'bg-[#1e1e1e]' : 'bg-white'
          }`}
          style={{ boxShadow: 'var(--shadow)' }}
        >
          <Search className={`w-5 h-5 ${isDark ? 'text-gray-500' : 'text-gray-400'}`} />
          <input
            type="text"
            placeholder="Search cameras..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className={`flex-1 bg-transparent outline-none ${
              isDark ? 'text-gray-200 placeholder-gray-500' : 'text-gray-900 placeholder-gray-400'
            }`}
          />
        </div>

        {/* Status Filter */}
        <div
          className={`rounded-2xl p-2 flex gap-2 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
          style={{ boxShadow: 'var(--shadow)' }}
        >
          {[
            { label: 'All', value: 'all' as const },
            { label: 'Online', value: 'online' as const },
            { label: 'Offline', value: 'offline' as const },
          ].map((btn) => (
            <button
              key={btn.value}
              onClick={() => setSelectedStatus(btn.value)}
              className={`flex-1 py-2 px-3 rounded-xl text-sm transition-all ${
                selectedStatus === btn.value
                  ? 'bg-gradient-to-r from-[#2e7d32] to-[#1b5e20] text-white shadow-md'
                  : isDark
                  ? 'text-gray-400 hover:bg-gray-800'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              {btn.label}
            </button>
          ))}
        </div>
      </div>

      {/* Cameras Grid */}
      <div className="grid grid-cols-1 gap-4">
        {filteredCameras.map((camera) => {
          const isOnline = camera.status === 'online';

          return (
            <div
              key={camera.id}
              className={`rounded-2xl p-4 transition-all ${
                isDark ? 'bg-[#1e1e1e]' : 'bg-white'
              }`}
              style={{ boxShadow: 'var(--shadow)' }}
            >
              {/* Camera Thumbnail */}
              <div className="relative mb-4 rounded-xl overflow-hidden bg-gray-900 aspect-video">
                <ImageWithFallback
                  src={camera.image}
                  alt={camera.name}
                  className="w-full h-full object-cover"
                />
                
                {/* Offline overlay */}
                {!isOnline && (
                  <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                    <div className="text-white text-sm">Camera Offline</div>
                  </div>
                )}

                {/* Status Indicator */}
                <div className="absolute top-3 right-3 flex items-center gap-2">
                  <div className={`px-3 py-1.5 rounded-full text-xs backdrop-blur-md ${
                    isOnline 
                      ? 'bg-[#4caf50]/90 text-white' 
                      : 'bg-[#ef5350]/90 text-white'
                  }`}>
                    <div className="flex items-center gap-1.5">
                      <Circle 
                        className={`w-2 h-2 fill-current ${isOnline ? 'animate-pulse' : ''}`}
                      />
                      <span>{isOnline ? 'LIVE' : 'OFFLINE'}</span>
                    </div>
                  </div>
                </div>

                {/* Quality Badge */}
                <div className="absolute top-3 left-3">
                  <div className="px-2.5 py-1 rounded-lg text-xs bg-black/60 backdrop-blur-md text-white font-medium">
                    {camera.quality}
                  </div>
                </div>

                {/* Recording indicator */}
                {isOnline && (
                  <div className="absolute bottom-3 left-3 flex items-center gap-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                    <span className="text-xs text-white bg-black/50 backdrop-blur-sm px-2 py-0.5 rounded">
                      Recording
                    </span>
                  </div>
                )}
              </div>

              {/* Camera Info */}
              <div className="space-y-3">
                <div>
                  <div className="flex items-start justify-between mb-1">
                    <div className="flex-1">
                      <h3 className={`text-sm mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                        {camera.name}
                      </h3>
                      <div className="flex items-center gap-1 text-xs">
                        <MapPin className={`w-3 h-3 ${isDark ? 'text-gray-500' : 'text-gray-500'}`} />
                        <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                          {camera.location}
                        </span>
                      </div>
                    </div>
                    
                    <div className={`text-xs px-2 py-1 rounded-lg ${isDark ? 'bg-gray-800 text-gray-400' : 'bg-gray-100 text-gray-600'}`}>
                      {camera.id}
                    </div>
                  </div>

                  <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
                    Updated {camera.lastUpdate}
                  </div>
                </div>

                {/* Actions */}
                <div className="flex gap-2">
                  <button
                    className={`flex-1 py-2 px-4 rounded-xl border transition-all ${
                      isDark
                        ? 'border-gray-700 text-gray-300 hover:bg-gray-800'
                        : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    View Stream
                  </button>
                  <button
                    className={`p-2 rounded-xl border transition-all ${
                      isDark
                        ? 'border-gray-700 text-gray-300 hover:bg-gray-800'
                        : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    <ExternalLink className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Empty State */}
      {filteredCameras.length === 0 && (
        <div
          className={`rounded-2xl p-8 text-center ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
          style={{ boxShadow: 'var(--shadow)' }}
        >
          <Camera className={`w-12 h-12 mx-auto mb-3 ${isDark ? 'text-gray-600' : 'text-gray-400'}`} />
          <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            No cameras found
          </div>
        </div>
      )}
    </div>
  );
}
