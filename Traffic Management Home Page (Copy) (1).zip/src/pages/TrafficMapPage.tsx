import { MapPin, Camera, AlertTriangle, ZoomIn, ZoomOut, Layers, Navigation2, Building2, Utensils, ShoppingBag, Hospital, School, Fuel, Coffee } from 'lucide-react';
import { useState } from 'react';

interface TrafficMapPageProps {
  isDark?: boolean;
}

export default function TrafficMapPage({ isDark }: TrafficMapPageProps) {
  const [selectedLayer, setSelectedLayer] = useState('traffic');
  const [mapZoom, setMapZoom] = useState(1);

  // Points of Interest
  const pois = [
    { id: 1, type: 'restaurant', name: 'Central Cafe', icon: Utensils, x: 30, y: 25, color: '#ff9800' },
    { id: 2, type: 'mall', name: 'City Mall', icon: ShoppingBag, x: 70, y: 35, color: '#e91e63' },
    { id: 3, type: 'hospital', name: 'City Hospital', icon: Hospital, x: 25, y: 65, color: '#ef5350' },
    { id: 4, type: 'school', name: 'ABC School', icon: School, x: 60, y: 70, color: '#1976d2' },
    { id: 5, type: 'office', name: 'Tech Park', icon: Building2, x: 80, y: 20, color: '#9e9e9e' },
    { id: 6, type: 'gas', name: 'Fuel Station', icon: Fuel, x: 40, y: 80, color: '#4caf50' },
    { id: 7, type: 'cafe', name: 'Coffee Shop', icon: Coffee, x: 50, y: 45, color: '#795548' },
  ];

  const trafficZones = [
    { id: 1, area: 'FC Road Junction', severity: 'high', congestion: 85, x: 35, y: 40 },
    { id: 2, area: 'Shivajinagar Circle', severity: 'medium', congestion: 62, x: 55, y: 30 },
    { id: 3, area: 'Deccan Gymkhana', severity: 'low', congestion: 35, x: 45, y: 55 },
    { id: 4, area: 'Swargate Square', severity: 'high', congestion: 78, x: 65, y: 60 },
  ];

  const cameras = [
    { id: 'CAM-001', name: 'FC Road', status: 'online', x: 35, y: 40 },
    { id: 'CAM-002', name: 'Shivajinagar', status: 'online', x: 55, y: 30 },
    { id: 'CAM-003', name: 'Deccan', status: 'online', x: 45, y: 55 },
    { id: 'CAM-004', name: 'Swargate', status: 'offline', x: 65, y: 60 },
    { id: 'CAM-005', name: 'Tech Park', status: 'online', x: 80, y: 20 },
    { id: 'CAM-006', name: 'Hospital Rd', status: 'online', x: 25, y: 65 },
  ];

  const alerts = [
    { id: 1, type: 'Heavy Traffic', severity: 'high', x: 35, y: 40 },
    { id: 2, type: 'Road Closure', severity: 'medium', x: 70, y: 35 },
    { id: 3, type: 'Accident', severity: 'high', x: 25, y: 65 },
    { id: 4, type: 'Construction', severity: 'low', x: 60, y: 70 },
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return { bg: '#ef5350', glow: 'rgba(239, 83, 80, 0.3)' };
      case 'medium': return { bg: '#ff9800', glow: 'rgba(255, 152, 0, 0.3)' };
      case 'low': return { bg: '#4caf50', glow: 'rgba(76, 175, 80, 0.3)' };
      default: return { bg: '#9e9e9e', glow: 'rgba(158, 158, 158, 0.3)' };
    }
  };

  // Calculate zoom level based on selected layer
  const getZoomLevel = () => {
    if (selectedLayer === 'cameras') return mapZoom * 1.2;
    if (selectedLayer === 'alerts') return mapZoom * 1.15;
    return mapZoom;
  };

  const currentZoom = getZoomLevel();

  return (
    <div className="flex-1 overflow-hidden relative">
      {/* Map Container */}
      <div className={`w-full h-full ${isDark ? 'bg-[#1a1a1a]' : 'bg-[#e5e3df]'}`}>
        {/* Base Map with Google Maps-like styling */}
        <div 
          className="absolute inset-0 transition-all duration-500"
          style={{
            background: isDark 
              ? 'linear-gradient(180deg, #2d3748 0%, #1a202c 50%, #171923 100%)' 
              : 'linear-gradient(180deg, #f8f9fa 0%, #e9ecef 50%, #dee2e6 100%)',
            transform: `scale(${currentZoom})`,
            transformOrigin: 'center center',
          }}
        >
          {/* Enhanced Road Network */}
          {/* Main highways - thicker */}
          <div className="absolute top-[30%] left-0 right-0 h-[10px] bg-gradient-to-b from-gray-400 via-gray-500 to-gray-600 shadow-lg">
            <div className="absolute inset-0 border-t-2 border-b-2 border-yellow-400/30" />
          </div>
          <div className="absolute top-[50%] left-0 right-0 h-[12px] bg-gradient-to-b from-gray-400 via-gray-500 to-gray-600 shadow-xl">
            <div className="absolute top-1/2 left-0 right-0 h-[2px] bg-yellow-400/50 -translate-y-1/2" />
          </div>
          <div className="absolute top-[70%] left-0 right-0 h-[10px] bg-gradient-to-b from-gray-400 via-gray-500 to-gray-600 shadow-lg">
            <div className="absolute inset-0 border-t-2 border-b-2 border-yellow-400/30" />
          </div>
          
          {/* Vertical roads */}
          <div className="absolute top-0 bottom-0 left-[20%] w-[8px] bg-gradient-to-r from-gray-400 via-gray-500 to-gray-600 shadow-md" />
          <div className="absolute top-0 bottom-0 left-[40%] w-[10px] bg-gradient-to-r from-gray-400 via-gray-500 to-gray-600 shadow-lg">
            <div className="absolute left-1/2 top-0 bottom-0 w-[2px] bg-yellow-400/50 -translate-x-1/2" />
          </div>
          <div className="absolute top-0 bottom-0 left-[60%] w-[8px] bg-gradient-to-r from-gray-400 via-gray-500 to-gray-600 shadow-md" />
          <div className="absolute top-0 bottom-0 left-[80%] w-[10px] bg-gradient-to-r from-gray-400 via-gray-500 to-gray-600 shadow-lg">
            <div className="absolute left-1/2 top-0 bottom-0 w-[2px] bg-yellow-400/50 -translate-x-1/2" />
          </div>

          {/* Building blocks for realism */}
          {[
            { x: 15, y: 15, w: 12, h: 18 }, { x: 48, y: 12, w: 15, h: 15 },
            { x: 72, y: 45, w: 20, h: 22 }, { x: 10, y: 52, w: 18, h: 12 },
            { x: 52, y: 62, w: 12, h: 15 }, { x: 28, y: 73, w: 15, h: 10 },
          ].map((block, idx) => (
            <div
              key={`block-${idx}`}
              className={`absolute ${isDark ? 'bg-gray-700/40' : 'bg-gray-300/40'} rounded-sm`}
              style={{
                left: `${block.x}%`,
                top: `${block.y}%`,
                width: `${block.w}%`,
                height: `${block.h}%`,
              }}
            />
          ))}

          {/* POIs - shown prominently when not in traffic layer */}
          {selectedLayer !== 'traffic' && pois.map((poi) => {
            const Icon = poi.icon;
            return (
              <div
                key={poi.id}
                className="absolute transition-all duration-300"
                style={{
                  left: `${poi.x}%`,
                  top: `${poi.y}%`,
                  transform: 'translate(-50%, -50%)',
                  opacity: selectedLayer === 'traffic' ? 0.3 : 1,
                }}
              >
                <div className="relative group cursor-pointer">
                  <div 
                    className="w-8 h-8 rounded-full flex items-center justify-center shadow-lg text-white"
                    style={{ backgroundColor: poi.color }}
                  >
                    <Icon className="w-4 h-4" />
                  </div>
                  
                  {/* Tooltip */}
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-gray-900 text-white text-xs rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-xl z-50">
                    {poi.name}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Traffic Heatmap Overlay - prominent in traffic view */}
          {selectedLayer === 'traffic' && trafficZones.map((zone) => {
            const color = getSeverityColor(zone.severity);
            return (
              <div
                key={zone.id}
                className="absolute transition-all duration-500"
                style={{
                  left: `${zone.x}%`,
                  top: `${zone.y}%`,
                  transform: 'translate(-50%, -50%)',
                }}
              >
                {/* Pulsing heatmap */}
                <div
                  className="w-40 h-40 rounded-full animate-pulse opacity-50 blur-2xl"
                  style={{ backgroundColor: color.bg }}
                />
                <div
                  className="absolute inset-0 w-40 h-40 rounded-full opacity-30 blur-3xl"
                  style={{ backgroundColor: color.bg }}
                />
                
                {/* Zone marker */}
                <div 
                  className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 px-4 py-2 rounded-xl text-sm text-white backdrop-blur-sm shadow-xl"
                  style={{ backgroundColor: color.bg }}
                >
                  {zone.congestion}%
                </div>
              </div>
            );
          })}

          {/* Camera Markers - enlarged in cameras view */}
          {(selectedLayer === 'cameras' || selectedLayer === 'traffic') && cameras.map((camera) => (
            <div
              key={camera.id}
              className="absolute transition-all duration-500"
              style={{
                left: `${camera.x}%`,
                top: `${camera.y}%`,
                transform: `translate(-50%, -50%) scale(${selectedLayer === 'cameras' ? 1.3 : 1})`,
              }}
            >
              <div className={`relative group cursor-pointer`}>
                <div className={`rounded-xl flex items-center justify-center shadow-lg transition-all ${
                  selectedLayer === 'cameras' ? 'w-14 h-14' : 'w-10 h-10'
                } ${
                  camera.status === 'online'
                    ? 'bg-[#2e7d32] text-white'
                    : 'bg-[#757575] text-white'
                }`}>
                  <Camera className={selectedLayer === 'cameras' ? 'w-7 h-7' : 'w-5 h-5'} />
                </div>
                
                {camera.status === 'online' && (
                  <div className="absolute -top-1 -right-1 w-4 h-4 bg-[#4caf50] rounded-full border-2 border-white animate-pulse" />
                )}

                {/* Tooltip */}
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-xl z-50">
                  <div className="font-medium">{camera.name}</div>
                  <div className="text-gray-400 text-[10px]">{camera.id}</div>
                  <div className="absolute top-full left-1/2 -translate-x-1/2">
                    <div className="border-4 border-transparent border-t-gray-900" />
                  </div>
                </div>
              </div>
            </div>
          ))}

          {/* Alert Markers - enlarged in alerts view */}
          {(selectedLayer === 'alerts' || selectedLayer === 'traffic') && alerts.map((alert) => {
            const color = getSeverityColor(alert.severity);
            return (
              <div
                key={alert.id}
                className="absolute transition-all duration-500"
                style={{
                  left: `${alert.x}%`,
                  top: `${alert.y}%`,
                  transform: `translate(-50%, -50%) scale(${selectedLayer === 'alerts' ? 1.3 : 1})`,
                }}
              >
                <div className="relative group cursor-pointer">
                  <div 
                    className={`rounded-xl flex items-center justify-center shadow-lg text-white animate-pulse ${
                      selectedLayer === 'alerts' ? 'w-14 h-14' : 'w-10 h-10'
                    }`}
                    style={{ backgroundColor: color.bg }}
                  >
                    <AlertTriangle className={selectedLayer === 'alerts' ? 'w-7 h-7' : 'w-5 h-5'} />
                  </div>

                  {/* Pulsing ring for alerts view */}
                  {selectedLayer === 'alerts' && (
                    <div 
                      className="absolute inset-0 w-14 h-14 rounded-xl animate-ping opacity-40"
                      style={{ backgroundColor: color.bg }}
                    />
                  )}

                  {/* Tooltip */}
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none shadow-xl z-50">
                    <div className="font-medium">{alert.type}</div>
                    <div className="text-gray-400 text-[10px] capitalize">{alert.severity} priority</div>
                    <div className="absolute top-full left-1/2 -translate-x-1/2">
                      <div className="border-4 border-transparent border-t-gray-900" />
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {/* Current Location */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2">
            <div className="relative">
              <div className="w-5 h-5 bg-[#1976d2] rounded-full border-4 border-white shadow-2xl z-10 relative" />
              <div className="absolute inset-0 w-5 h-5 bg-[#42a5f5] rounded-full animate-ping" />
            </div>
          </div>
        </div>
      </div>

      {/* Controls Overlay */}
      <div className="absolute top-4 left-4 right-4 z-20">
        {/* Layer Selector */}
        <div
          className={`rounded-2xl p-2 flex gap-2 ${
            isDark ? 'bg-[#1e1e1e]/95' : 'bg-white/95'
          } backdrop-blur-md shadow-lg`}
        >
          {[
            { id: 'traffic', label: 'Traffic', icon: '🚗' },
            { id: 'cameras', label: 'Cameras', icon: '📹' },
            { id: 'alerts', label: 'Alerts', icon: '⚠️' },
          ].map((layer) => (
            <button
              key={layer.id}
              onClick={() => setSelectedLayer(layer.id)}
              className={`flex-1 py-2 px-3 rounded-xl text-sm transition-all flex items-center justify-center gap-2 ${
                selectedLayer === layer.id
                  ? 'bg-gradient-to-r from-[#2e7d32] to-[#1b5e20] text-white shadow-md'
                  : isDark
                  ? 'text-gray-400 hover:bg-gray-800'
                  : 'text-gray-600 hover:bg-gray-50'
              }`}
            >
              <span>{layer.icon}</span>
              <span>{layer.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Zoom Controls */}
      <div className="absolute top-24 right-4 z-20 flex flex-col gap-2">
        <button
          onClick={() => setMapZoom(Math.min(mapZoom + 0.2, 2))}
          className={`rounded-xl p-3 shadow-lg backdrop-blur-md transition-all hover:scale-105 ${
            isDark ? 'bg-[#1e1e1e]/95 text-gray-200' : 'bg-white/95'
          }`}
        >
          <ZoomIn className="w-5 h-5" />
        </button>
        <button
          onClick={() => setMapZoom(Math.max(mapZoom - 0.2, 0.5))}
          className={`rounded-xl p-3 shadow-lg backdrop-blur-md transition-all hover:scale-105 ${
            isDark ? 'bg-[#1e1e1e]/95 text-gray-200' : 'bg-white/95'
          }`}
        >
          <ZoomOut className="w-5 h-5" />
        </button>
        <button
          className={`rounded-xl p-3 shadow-lg backdrop-blur-md transition-all hover:scale-105 ${
            isDark ? 'bg-[#1e1e1e]/95 text-gray-200' : 'bg-white/95'
          }`}
        >
          <Navigation2 className="w-5 h-5" />
        </button>
      </div>

      {/* Legend */}
      <div
        className={`absolute bottom-24 left-4 rounded-2xl p-4 ${
          isDark ? 'bg-[#1e1e1e]/95' : 'bg-white/95'
        } backdrop-blur-md shadow-lg`}
      >
        <div className={`text-xs mb-3 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
          {selectedLayer === 'traffic' && 'Traffic Severity'}
          {selectedLayer === 'cameras' && 'Camera Status'}
          {selectedLayer === 'alerts' && 'Alert Levels'}
        </div>
        <div className="space-y-2">
          {selectedLayer === 'traffic' && [
            { label: 'High', color: '#ef5350' },
            { label: 'Medium', color: '#ff9800' },
            { label: 'Low', color: '#4caf50' },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: item.color }}
              />
              <span className={`text-xs ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                {item.label}
              </span>
            </div>
          ))}
          {selectedLayer === 'cameras' && [
            { label: 'Online', color: '#4caf50' },
            { label: 'Offline', color: '#757575' },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: item.color }}
              />
              <span className={`text-xs ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                {item.label}
              </span>
            </div>
          ))}
          {selectedLayer === 'alerts' && [
            { label: 'High Priority', color: '#ef5350' },
            { label: 'Medium Priority', color: '#ff9800' },
            { label: 'Low Priority', color: '#4caf50' },
          ].map((item) => (
            <div key={item.label} className="flex items-center gap-2">
              <div
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: item.color }}
              />
              <span className={`text-xs ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                {item.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Route Suggestions - only show in traffic view */}
      {selectedLayer === 'traffic' && (
        <div
          className={`absolute bottom-24 right-4 rounded-2xl p-4 w-48 ${
            isDark ? 'bg-[#1e1e1e]/95' : 'bg-white/95'
          } backdrop-blur-md shadow-lg`}
        >
          <div className={`text-xs mb-3 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Suggested Routes
          </div>
          <div className="space-y-2">
            {[
              { name: 'Fastest', time: '12 min', color: '#ef5350' },
              { name: 'Balanced', time: '15 min', color: '#ff9800' },
              { name: 'Eco-Friendly', time: '18 min', color: '#4caf50' },
            ].map((route) => (
              <button
                key={route.name}
                className={`w-full p-2 rounded-lg text-left transition-all ${
                  isDark
                    ? 'bg-gray-800 hover:bg-gray-700'
                    : 'bg-gray-50 hover:bg-gray-100'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-2 h-2 rounded-full"
                      style={{ backgroundColor: route.color }}
                    />
                    <span className={`text-xs ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                      {route.name}
                    </span>
                  </div>
                  <span className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                    {route.time}
                  </span>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
