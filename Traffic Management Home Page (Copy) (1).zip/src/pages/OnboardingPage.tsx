import { useState } from 'react';
import { ChevronRight, MapPin, Bell, Leaf, ChevronLeft, Check } from 'lucide-react';

interface OnboardingPageProps {
  onComplete: () => void;
  onSkip: () => void;
}

export function OnboardingPage({ onComplete, onSkip }: OnboardingPageProps) {
  const [step, setStep] = useState(0);
  const [selectedInterests, setSelectedInterests] = useState<string[]>([]);

  const interests = [
    { id: 'walks', label: 'Quiet Walks', icon: '🚶' },
    { id: 'commute', label: 'Eco Commute', icon: '🚌' },
    { id: 'deliveries', label: 'Deliveries', icon: '📦' },
    { id: 'cycling', label: 'Cycling', icon: '🚴' },
    { id: 'running', label: 'Running', icon: '🏃' },
    { id: 'ev', label: 'EV Charging', icon: '⚡' },
  ];

  const toggleInterest = (id: string) => {
    setSelectedInterests(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const steps = [
    {
      title: 'Welcome to GeoSense+',
      subtitle: 'Your smart companion for sustainable, stress-free travel',
      content: (
        <div className="space-y-6">
          <div className="w-32 h-32 mx-auto bg-gradient-to-br from-green-500 to-blue-500 rounded-full flex items-center justify-center">
            <Leaf className="w-16 h-16 text-white" />
          </div>
          <div className="space-y-4 text-center">
            <div className="flex items-center gap-3 p-4 bg-green-50 rounded-xl">
              <div className="w-10 h-10 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Check className="w-6 h-6 text-white" />
              </div>
              <p className="text-gray-700 text-left">Real-time eco-friendly routes</p>
            </div>
            <div className="flex items-center gap-3 p-4 bg-blue-50 rounded-xl">
              <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Check className="w-6 h-6 text-white" />
              </div>
              <p className="text-gray-700 text-left">Track your carbon savings</p>
            </div>
            <div className="flex items-center gap-3 p-4 bg-purple-50 rounded-xl">
              <div className="w-10 h-10 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0">
                <Check className="w-6 h-6 text-white" />
              </div>
              <p className="text-gray-700 text-left">Join community challenges</p>
            </div>
          </div>
        </div>
      ),
    },
    {
      title: 'Enable Permissions',
      subtitle: 'We need a few permissions to provide you with the best experience',
      content: (
        <div className="space-y-4">
          <div className="p-6 bg-white border-2 border-gray-200 rounded-xl">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                <MapPin className="w-6 h-6 text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-gray-900 mb-2">Location Services</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Required to show real-time routes, traffic, and air quality in your area.
                </p>
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg transition-colors">
                  Enable Location
                </button>
              </div>
            </div>
          </div>
          
          <div className="p-6 bg-white border-2 border-gray-200 rounded-xl">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center flex-shrink-0">
                <Bell className="w-6 h-6 text-orange-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-gray-900 mb-2">Notifications</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Get alerts for high AQI, traffic jams, and challenge updates.
                </p>
                <button className="w-full bg-orange-600 hover:bg-orange-700 text-white py-3 rounded-lg transition-colors">
                  Enable Notifications
                </button>
              </div>
            </div>
          </div>

          <p className="text-sm text-gray-500 text-center">
            You can change these settings anytime in your profile.
          </p>
        </div>
      ),
    },
    {
      title: 'Choose Your Interests',
      subtitle: 'Tell us how you like to travel so we can personalize your experience',
      content: (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            {interests.map((interest) => (
              <button
                key={interest.id}
                onClick={() => toggleInterest(interest.id)}
                className={`p-4 border-2 rounded-xl transition-all ${
                  selectedInterests.includes(interest.id)
                    ? 'border-green-600 bg-green-50'
                    : 'border-gray-200 bg-white hover:border-gray-300'
                }`}
              >
                <div className="text-4xl mb-2">{interest.icon}</div>
                <div className="text-sm text-gray-900">{interest.label}</div>
                {selectedInterests.includes(interest.id) && (
                  <div className="mt-2">
                    <Check className="w-5 h-5 text-green-600 mx-auto" />
                  </div>
                )}
              </button>
            ))}
          </div>
          <p className="text-sm text-gray-500 text-center">
            Select at least one to continue
          </p>
        </div>
      ),
    },
    {
      title: 'Quick Tutorial',
      subtitle: 'Three simple tips to get started',
      content: (
        <div className="space-y-4">
          <div className="p-6 bg-gradient-to-r from-blue-50 to-blue-100 rounded-xl">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center flex-shrink-0 text-white">
                1
              </div>
              <div>
                <h3 className="text-gray-900 mb-2">Chat with GeoSense+</h3>
                <p className="text-sm text-gray-600">
                  Ask questions like "Show me a quiet jog route near me" or "How much CO₂ did I save today?"
                </p>
              </div>
            </div>
          </div>

          <div className="p-6 bg-gradient-to-r from-green-50 to-green-100 rounded-xl">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center flex-shrink-0 text-white">
                2
              </div>
              <div>
                <h3 className="text-gray-900 mb-2">Tap the Map</h3>
                <p className="text-sm text-gray-600">
                  View live traffic, air quality, and eco-friendly routes with a single tap.
                </p>
              </div>
            </div>
          </div>

          <div className="p-6 bg-gradient-to-r from-purple-50 to-purple-100 rounded-xl">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-purple-600 rounded-full flex items-center justify-center flex-shrink-0 text-white">
                3
              </div>
              <div>
                <h3 className="text-gray-900 mb-2">Earn Badges</h3>
                <p className="text-sm text-gray-600">
                  Complete challenges, save carbon, and earn rewards to unlock discounts!
                </p>
              </div>
            </div>
          </div>
        </div>
      ),
    },
  ];

  const currentStep = steps[step];
  const isLastStep = step === steps.length - 1;
  const canProceed = step !== 2 || selectedInterests.length > 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex flex-col">
      <div className="flex-1 flex flex-col max-w-2xl mx-auto w-full px-4 py-8">
        {/* Progress */}
        <div className="mb-8">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-600">Step {step + 1} of {steps.length}</span>
            <button
              onClick={onSkip}
              className="text-sm text-gray-500 hover:text-gray-700"
            >
              Skip
            </button>
          </div>
          <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-green-600 to-blue-600 transition-all duration-300"
              style={{ width: `${((step + 1) / steps.length) * 100}%` }}
            />
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col">
          <div className="text-center mb-8">
            <h1 className="text-gray-900 mb-2">{currentStep.title}</h1>
            <p className="text-gray-600">{currentStep.subtitle}</p>
          </div>

          <div className="flex-1">
            {currentStep.content}
          </div>
        </div>

        {/* Navigation */}
        <div className="flex items-center gap-3 mt-8">
          {step > 0 && (
            <button
              onClick={() => setStep(step - 1)}
              className="flex items-center gap-2 px-6 py-3 border-2 border-gray-300 text-gray-700 rounded-xl hover:bg-gray-50 transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
              Back
            </button>
          )}
          
          <button
            onClick={() => {
              if (isLastStep) {
                onComplete();
              } else {
                setStep(step + 1);
              }
            }}
            disabled={!canProceed}
            className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-green-600 to-blue-600 text-white rounded-xl hover:from-green-700 hover:to-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isLastStep ? 'Get Started' : 'Continue'}
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}
