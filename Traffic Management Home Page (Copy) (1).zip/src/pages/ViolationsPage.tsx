import { Upload, Video, CheckCircle, AlertTriangle, Clock, X, PlayCircle, Check } from 'lucide-react';
import { useState } from 'react';

interface ViolationsPageProps {
  isDark?: boolean;
}

export default function ViolationsPage({ isDark }: ViolationsPageProps) {
  const [showGallery, setShowGallery] = useState(false);
  const [selectedVideo, setSelectedVideo] = useState<any>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<any>(null);

  // Mock gallery videos
  const galleryVideos = [
    {
      id: 1,
      thumbnail: 'https://images.unsplash.com/photo-1687069295578-ea662f5e490e?w=400&h=225&fit=crop&q=80',
      name: 'Red Light Violation',
      duration: '5s',
      violation: 'Red Light Violation',
      vehicleType: 'Sedan',
      confidence: 94.5,
    },
    {
      id: 2,
      thumbnail: 'https://images.unsplash.com/photo-1544535031-b2fe56200d38?w=400&h=225&fit=crop&q=80',
      name: 'Speeding',
      duration: '5s',
      violation: 'Speed Limit Exceeded',
      vehicleType: 'SUV',
      confidence: 91.2,
    },
    {
      id: 3,
      thumbnail: 'https://images.unsplash.com/photo-1757359315231-2a2b890a65f6?w=400&h=225&fit=crop&q=80',
      name: 'Wrong Lane',
      duration: '5s',
      violation: 'Wrong Lane Usage',
      vehicleType: 'Truck',
      confidence: 88.7,
    },
    {
      id: 4,
      thumbnail: 'https://images.unsplash.com/photo-1501829634390-7c98deb33171?w=400&h=225&fit=crop&q=80',
      name: 'No Helmet',
      duration: '5s',
      violation: 'No Helmet Detected',
      vehicleType: 'Motorcycle',
      confidence: 96.3,
    },
    {
      id: 5,
      thumbnail: 'https://images.unsplash.com/photo-1733149086985-7e607db85843?w=400&h=225&fit=crop&q=80',
      name: 'Illegal Turn',
      duration: '5s',
      violation: 'Illegal U-Turn',
      vehicleType: 'Hatchback',
      confidence: 89.8,
    },
    {
      id: 6,
      thumbnail: 'https://images.unsplash.com/photo-1552657787-6ea206193eca?w=400&h=225&fit=crop&q=80',
      name: 'Parking Violation',
      duration: '5s',
      violation: 'No Parking Zone',
      vehicleType: 'Van',
      confidence: 92.5,
    },
  ];

  const handleVideoSelect = (video: any) => {
    setSelectedVideo(video);
    setShowGallery(false);
    setIsAnalyzing(true);
    setAnalysisResult(null);
    
    // Simulate AI analysis
    setTimeout(() => {
      setIsAnalyzing(false);
      setAnalysisResult({
        violationType: video.violation,
        confidence: video.confidence,
        timestamp: '00:00:03',
        vehicleType: video.vehicleType,
        licenseplate: generateLicensePlate(),
        severity: video.confidence > 93 ? 'High' : video.confidence > 88 ? 'Medium' : 'Low',
        location: 'FC Road Junction',
      });
    }, 3000);
  };

  const generateLicensePlate = () => {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const numbers = '0123456789';
    return `MH${numbers[Math.floor(Math.random() * 10)]}${numbers[Math.floor(Math.random() * 10)]}${letters[Math.floor(Math.random() * 26)]}${letters[Math.floor(Math.random() * 26)]}${numbers[Math.floor(Math.random() * 10)]}${numbers[Math.floor(Math.random() * 10)]}${numbers[Math.floor(Math.random() * 10)]}${numbers[Math.floor(Math.random() * 10)]}`;
  };

  const recentViolations = [
    {
      id: 'V-2024-001',
      type: 'Speeding',
      vehicleType: 'Sedan',
      time: '2 hours ago',
      confidence: 96,
      severity: 'Medium',
      location: 'Shivajinagar',
    },
    {
      id: 'V-2024-002',
      type: 'Wrong Lane',
      vehicleType: 'SUV',
      time: '3 hours ago',
      confidence: 89,
      severity: 'Low',
      location: 'Deccan Gymkhana',
    },
    {
      id: 'V-2024-003',
      type: 'No Helmet',
      vehicleType: 'Motorcycle',
      time: '5 hours ago',
      confidence: 92,
      severity: 'High',
      location: 'Swargate',
    },
    {
      id: 'V-2024-004',
      type: 'Red Light',
      vehicleType: 'Hatchback',
      time: '6 hours ago',
      confidence: 94,
      severity: 'High',
      location: 'FC Road',
    },
    {
      id: 'V-2024-005',
      type: 'Illegal Parking',
      vehicleType: 'Truck',
      time: '7 hours ago',
      confidence: 88,
      severity: 'Low',
      location: 'JM Road',
    },
  ];

  const getSeverityColor = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'high':
        return {
          bg: isDark ? 'bg-[#d32f2f]/20' : 'bg-[#ffebee]',
          text: 'text-[#ef5350]',
          border: 'border-[#ef5350]',
        };
      case 'medium':
        return {
          bg: isDark ? 'bg-[#ff9800]/20' : 'bg-[#fff3e0]',
          text: 'text-[#ff9800]',
          border: 'border-[#ff9800]',
        };
      default:
        return {
          bg: isDark ? 'bg-[#1976d2]/20' : 'bg-[#e3f2fd]',
          text: 'text-[#1976d2]',
          border: 'border-[#1976d2]',
        };
    }
  };

  const getVehicleIcon = (type: string) => {
    const icons: { [key: string]: string } = {
      'Sedan': '🚗',
      'SUV': '🚙',
      'Truck': '🚚',
      'Motorcycle': '🏍️',
      'Hatchback': '🚗',
      'Van': '🚐',
    };
    return icons[type] || '🚗';
  };

  return (
    <div className="flex-1 overflow-y-auto pb-24 px-4 py-6">
      {/* Page Title */}
      <div className="mb-6">
        <h1 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
          Violations Detection
        </h1>
        <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
          AI-powered traffic violation analysis
        </p>
      </div>

      {/* Upload Card */}
      <div
        className={`rounded-2xl p-6 mb-6 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow)' }}
      >
        <div className="flex items-center gap-3 mb-4">
          <div className={`p-3 rounded-xl ${isDark ? 'bg-[#2e7d32]/20' : 'bg-[#e8f5e9]'}`}>
            <Video className="w-5 h-5 text-[#4caf50]" />
          </div>
          <div>
            <h3 className={`${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
              Upload Video
            </h3>
            <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Upload traffic footage for analysis
            </p>
          </div>
        </div>

        {!selectedVideo ? (
          <button 
            onClick={() => setShowGallery(true)}
            className={`
              w-full flex flex-col items-center justify-center
              border-2 border-dashed rounded-xl p-8 cursor-pointer
              transition-all hover:border-[#2e7d32]
              ${isDark ? 'border-gray-700 bg-gray-800/50 hover:bg-gray-800' : 'border-gray-300 bg-gray-50 hover:bg-gray-100'}
            `}
          >
            <Upload className={`w-12 h-12 mb-3 ${isDark ? 'text-gray-400' : 'text-gray-400'}`} />
            <div className={`text-sm mb-1 ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
              Click to select violation video
            </div>
            <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
              Choose from gallery
            </div>
          </button>
        ) : (
          <div className="space-y-4">
            {/* Video Preview */}
            <div className="relative">
              <img
                src={selectedVideo.thumbnail}
                alt={selectedVideo.name}
                className="w-full rounded-xl"
                style={{ maxHeight: '200px', objectFit: 'cover' }}
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="w-16 h-16 rounded-full bg-black/50 backdrop-blur-sm flex items-center justify-center">
                  <PlayCircle className="w-10 h-10 text-white" />
                </div>
              </div>
              <button
                onClick={() => {
                  setSelectedVideo(null);
                  setAnalysisResult(null);
                }}
                className={`absolute top-2 right-2 p-2 rounded-lg ${
                  isDark ? 'bg-gray-900/80' : 'bg-white/80'
                } backdrop-blur-sm`}
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Analyzing State */}
            {isAnalyzing && (
              <div className={`p-4 rounded-xl text-center ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
                <div className="flex items-center justify-center gap-2 mb-2">
                  <div className="w-2 h-2 bg-[#2e7d32] rounded-full animate-bounce" />
                  <div className="w-2 h-2 bg-[#2e7d32] rounded-full animate-bounce [animation-delay:0.2s]" />
                  <div className="w-2 h-2 bg-[#2e7d32] rounded-full animate-bounce [animation-delay:0.4s]" />
                </div>
                <div className={`text-sm ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
                  Analyzing video with AI...
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Analysis Result */}
      {analysisResult && (
        <div
          className={`rounded-2xl p-6 mb-6 border-2 ${
            isDark ? 'bg-[#1e1e1e] border-[#ef5350]' : 'bg-white border-[#ef5350]'
          }`}
          style={{ boxShadow: 'var(--shadow-lg)' }}
        >
          <div className="flex items-start justify-between mb-5">
            <div className="flex items-start gap-3">
              <div className={`p-3 rounded-xl ${isDark ? 'bg-[#d32f2f]/20' : 'bg-[#ffebee]'}`}>
                <AlertTriangle className="w-6 h-6 text-[#ef5350]" />
              </div>
              <div>
                <h3 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  Violation Detected
                </h3>
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                  Analysis complete
                </p>
              </div>
            </div>
            
            <div className={`px-3 py-1 rounded-full text-xs ${getSeverityColor(analysisResult.severity).bg} ${getSeverityColor(analysisResult.severity).text}`}>
              {analysisResult.severity} Priority
            </div>
          </div>

          {/* Details Grid */}
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className={`p-4 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
              <div className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                Violation Type
              </div>
              <div className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                {analysisResult.violationType}
              </div>
            </div>

            <div className={`p-4 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
              <div className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                Confidence
              </div>
              <div className="text-sm text-[#4caf50]">
                {analysisResult.confidence}%
              </div>
            </div>

            <div className={`p-4 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
              <div className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                Vehicle Type
              </div>
              <div className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'} flex items-center gap-2`}>
                <span>{getVehicleIcon(analysisResult.vehicleType)}</span>
                <span>{analysisResult.vehicleType}</span>
              </div>
            </div>

            <div className={`p-4 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
              <div className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                Timestamp
              </div>
              <div className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                {analysisResult.timestamp}
              </div>
            </div>
          </div>

          <div className={`p-4 rounded-xl mb-4 ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
            <div className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
              License Plate
            </div>
            <div className={`text-lg ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
              {analysisResult.licenseplate}
            </div>
          </div>

          <button className="w-full py-3 rounded-xl border-2 border-[#2e7d32] text-[#2e7d32] hover:bg-[#2e7d32] hover:text-white transition-all">
            Generate Report
          </button>
        </div>
      )}

      {/* Recent Violations */}
      <div
        className={`rounded-2xl p-5 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow)' }}
      >
        <div className="mb-4">
          <h3 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            Recent Violations
          </h3>
          <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Latest detected violations
          </p>
        </div>

        <div className="space-y-3">
          {recentViolations.map((violation) => {
            const severityStyle = getSeverityColor(violation.severity);
            
            return (
              <div
                key={violation.id}
                className={`p-4 rounded-xl border ${
                  isDark ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className={`text-sm mb-1 ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                      {violation.type}
                    </div>
                    <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                      {violation.id}
                    </div>
                  </div>
                  
                  <div className={`px-2 py-1 rounded-full text-xs ${severityStyle.bg} ${severityStyle.text}`}>
                    {violation.severity}
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="flex items-center gap-2">
                    <span>{getVehicleIcon(violation.vehicleType)}</span>
                    <div>
                      <span className={isDark ? 'text-gray-500' : 'text-gray-600'}>Type: </span>
                      <span className={isDark ? 'text-gray-300' : 'text-gray-900'}>{violation.vehicleType}</span>
                    </div>
                  </div>
                  <div>
                    <span className={isDark ? 'text-gray-500' : 'text-gray-600'}>Confidence: </span>
                    <span className="text-[#4caf50]">{violation.confidence}%</span>
                  </div>
                  <div>
                    <span className={isDark ? 'text-gray-500' : 'text-gray-600'}>Location: </span>
                    <span className={isDark ? 'text-gray-300' : 'text-gray-900'}>{violation.location}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <Clock className={`w-3 h-3 ${isDark ? 'text-gray-500' : 'text-gray-600'}`} />
                    <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>{violation.time}</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Gallery Modal */}
      {showGallery && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div
            className={`w-full max-w-2xl rounded-3xl p-6 max-h-[80vh] overflow-y-auto ${
              isDark ? 'bg-[#1e1e1e]' : 'bg-white'
            }`}
            style={{ boxShadow: 'var(--shadow-lg)' }}
          >
            {/* Header */}
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className={`text-lg mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  Select Violation Video
                </h2>
                <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                  Choose a traffic violation video to analyze
                </p>
              </div>
              <button
                onClick={() => setShowGallery(false)}
                className={`p-2 rounded-xl ${
                  isDark ? 'hover:bg-gray-800' : 'hover:bg-gray-100'
                }`}
              >
                <X className={`w-5 h-5 ${isDark ? 'text-gray-400' : 'text-gray-600'}`} />
              </button>
            </div>

            {/* Gallery Grid */}
            <div className="grid grid-cols-2 gap-4">
              {galleryVideos.map((video) => (
                <button
                  key={video.id}
                  onClick={() => handleVideoSelect(video)}
                  className={`relative group rounded-xl overflow-hidden transition-all hover:scale-105 ${
                    isDark ? 'hover:bg-gray-800' : 'hover:bg-gray-50'
                  }`}
                >
                  <img
                    src={video.thumbnail}
                    alt={video.name}
                    className="w-full h-32 object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition-all flex items-center justify-center">
                    <PlayCircle className="w-12 h-12 text-white opacity-80 group-hover:opacity-100" />
                  </div>
                  <div className="absolute top-2 left-2 px-2 py-1 rounded-lg bg-black/60 backdrop-blur-sm text-white text-xs">
                    {video.duration}
                  </div>
                  <div className={`p-3 ${isDark ? 'bg-gray-800' : 'bg-white'}`}>
                    <div className={`text-sm mb-1 ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                      {video.name}
                    </div>
                    <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                      {video.violation}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
