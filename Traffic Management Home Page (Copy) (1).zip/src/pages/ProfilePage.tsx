import React, { useState, useRef, useEffect } from 'react';
import { 
  User, 
  Leaf, 
  Award, 
  TrendingUp, 
  Settings, 
  Bell,
  Shield,
  HelpCircle,
  LogOut,
  ChevronRight,
  Trophy,
  Target,
  Calendar,
  MapPin,
  Car,
  Bike,
  Train,
  Footprints,
  Zap,
  Star,
  Crown,
  Edit2,
  Share2,
  BarChart3,
  Medal,
  Flame,
  CheckCircle2,
  Clock
} from 'lucide-react';
import type { PageType } from '../App';
import { Card } from '../components/ui/card';
import { Avatar, AvatarFallback } from '../components/ui/avatar';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { Progress } from '../components/ui/progress';
import { Separator } from '../components/ui/separator';
import { Switch } from '../components/ui/switch';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '../components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '../components/ui/dialog';
import { Label } from '../components/ui/label';
import { Input } from '../components/ui/input';
import { toast } from 'sonner@2.0.3';
import { SocialShareDialog } from '../components/SocialShareDialog';

interface Achievement {
  id: string;
  icon: string;
  title: string;
  description: string;
  unlockedDate?: string;
  locked: boolean;
  progress?: number;
  total?: number;
}

interface Challenge {
  id: string;
  title: string;
  description: string;
  reward: number;
  progress: number;
  total: number;
  expiresIn: string;
  category: 'eco' | 'social' | 'commute';
}

interface ProfilePageProps {
  navigateTo: (page: PageType) => void;
  isDark?: boolean;
}

const ProfilePage: React.FC<ProfilePageProps> = ({ navigateTo, isDark }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [notifications, setNotifications] = useState(true);
  const [locationSharing, setLocationSharing] = useState(true);
  const [showEditProfile, setShowEditProfile] = useState(false);
  const [isImpactHighlighted, setIsImpactHighlighted] = useState(false);
  const impactRef = useRef<HTMLDivElement>(null);

  // Intersection Observer for Environmental Impact section
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            setIsImpactHighlighted(true);
            setTimeout(() => setIsImpactHighlighted(false), 2000);
          }
        });
      },
      { threshold: 0.5 }
    );

    if (impactRef.current) {
      observer.observe(impactRef.current);
    }

    return () => {
      if (impactRef.current) {
        observer.unobserve(impactRef.current);
      }
    };
  }, []);

  const [userStats, setUserStats] = useState({
    name: 'Alex Johnson',
    username: '@alexj_commute',
    memberSince: 'January 2025',
    location: 'Bangalore, India',
    carbonSaved: 342.5, // kg
    ecoPoints: 2850,
    rank: 'Eco Champion',
    rankIcon: '🏆',
    level: 12,
    nextLevelPoints: 3000,
    totalTrips: 156,
    streakDays: 23,
    badges: 15,
    reputation: 2450
  });

  const [editedName, setEditedName] = useState(userStats.name);
  const [editedUsername, setEditedUsername] = useState(userStats.username);
  const [editedLocation, setEditedLocation] = useState(userStats.location);

  const achievements: Achievement[] = [
    {
      id: '1',
      icon: '🌱',
      title: 'Eco Warrior',
      description: 'Saved 100kg of CO₂',
      unlockedDate: 'Oct 15, 2025',
      locked: false
    },
    {
      id: '2',
      icon: '🔥',
      title: '30-Day Streak',
      description: 'Logged eco-friendly trips for 30 days',
      unlockedDate: 'Oct 28, 2025',
      locked: false
    },
    {
      id: '3',
      icon: '🚴',
      title: 'Pedal Power',
      description: 'Completed 50 bike trips',
      unlockedDate: 'Nov 2, 2025',
      locked: false
    },
    {
      id: '4',
      icon: '🌟',
      title: 'Community Hero',
      description: 'Helped 100 community members',
      unlockedDate: 'Nov 5, 2025',
      locked: false
    },
    {
      id: '5',
      icon: '👑',
      title: 'Top 10%',
      description: 'Ranked in top 10% of users',
      locked: false
    },
    {
      id: '6',
      icon: '🎯',
      title: 'Perfect Week',
      description: 'Complete 7 eco-trips in a row',
      locked: true,
      progress: 5,
      total: 7
    },
    {
      id: '7',
      icon: '🚇',
      title: 'Metro Master',
      description: 'Take 100 metro trips',
      locked: true,
      progress: 67,
      total: 100
    },
    {
      id: '8',
      icon: '🌍',
      title: 'Planet Saver',
      description: 'Save 500kg of CO₂',
      locked: true,
      progress: 342,
      total: 500
    }
  ];

  const activeChallenges: Challenge[] = [
    {
      id: 'c1',
      title: 'Carpool Week',
      description: 'Share 5 carpool rides this week',
      reward: 250,
      progress: 3,
      total: 5,
      expiresIn: '3 days',
      category: 'social'
    },
    {
      id: 'c2',
      title: 'Metro Mondays',
      description: 'Use metro for your Monday commute',
      reward: 100,
      progress: 1,
      total: 4,
      expiresIn: '18 days',
      category: 'eco'
    },
    {
      id: 'c3',
      title: 'Walk & Win',
      description: 'Walk 10km this month',
      reward: 300,
      progress: 6.5,
      total: 10,
      expiresIn: '25 days',
      category: 'commute'
    }
  ];

  const travelStats = [
    { icon: Car, label: 'Car', trips: 45, percentage: 29, color: 'text-red-500' },
    { icon: Bike, label: 'Bike', trips: 52, percentage: 33, color: 'text-green-500' },
    { icon: Train, label: 'Metro', trips: 38, percentage: 24, color: 'text-blue-500' },
    { icon: Footprints, label: 'Walk', trips: 21, percentage: 14, color: 'text-purple-500' }
  ];

  const recentActivity = [
    { date: 'Today, 9:30 AM', action: 'Bike ride to office', points: '+25', icon: '🚴' },
    { date: 'Yesterday, 6:45 PM', action: 'Carpooled with 3 people', points: '+40', icon: '🚗' },
    { date: 'Nov 5, 8:15 AM', action: 'Metro commute', points: '+15', icon: '🚇' },
    { date: 'Nov 4, 7:00 PM', action: 'Walked 2km', points: '+10', icon: '🚶' }
  ];

  const handleEditProfile = () => {
    setUserStats({
      ...userStats,
      name: editedName,
      username: editedUsername,
      location: editedLocation
    });
    toast.success('Profile updated successfully!', {
      position: 'top-center',
    });
    setShowEditProfile(false);
  };

  const handleShareProfile = () => {
    toast.success('Profile link copied to clipboard!', {
      position: 'top-center',
    });
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'eco': return 'bg-green-500';
      case 'social': return 'bg-blue-500';
      case 'commute': return 'bg-purple-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className={`min-h-screen pb-20 ${
      isDark ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-blue-50 to-green-50'
    }`}>
      {/* Profile Header */}
      <div className="bg-gradient-to-r from-blue-600 to-green-600 text-white pb-24 pt-4 px-4 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-0 left-0 w-64 h-64 bg-white rounded-full -translate-x-1/2 -translate-y-1/2"></div>
          <div className="absolute bottom-0 right-0 w-96 h-96 bg-white rounded-full translate-x-1/2 translate-y-1/2"></div>
        </div>

        <div className="relative">
          {/* Action Buttons */}
          <div className="flex justify-end gap-2 mb-4">
            <SocialShareDialog isDark={isDark} />
            <Dialog open={showEditProfile} onOpenChange={(open) => {
              if (open) {
                setEditedName(userStats.name);
                setEditedUsername(userStats.username);
                setEditedLocation(userStats.location);
              }
              setShowEditProfile(open);
            }}>
              <DialogTrigger asChild>
                <Button size="sm" variant="ghost" className="text-white hover:bg-white/20">
                  <Edit2 className="w-4 h-4" />
                </Button>
              </DialogTrigger>
              <DialogContent className={isDark ? 'bg-gray-900 text-gray-100 border-gray-800' : ''}>
                <DialogHeader>
                  <DialogTitle className={isDark ? 'text-gray-100' : ''}>Edit Profile</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <Label className={isDark ? 'text-gray-300' : ''}>Name</Label>
                    <Input 
                      value={editedName} 
                      onChange={(e) => setEditedName(e.target.value)}
                      className={isDark ? 'bg-gray-800 border-gray-700 text-gray-200' : ''} 
                    />
                  </div>
                  <div>
                    <Label className={isDark ? 'text-gray-300' : ''}>Username</Label>
                    <Input 
                      value={editedUsername} 
                      onChange={(e) => setEditedUsername(e.target.value)}
                      className={isDark ? 'bg-gray-800 border-gray-700 text-gray-200' : ''} 
                    />
                  </div>
                  <div>
                    <Label className={isDark ? 'text-gray-300' : ''}>Location</Label>
                    <Input 
                      value={editedLocation} 
                      onChange={(e) => setEditedLocation(e.target.value)}
                      className={isDark ? 'bg-gray-800 border-gray-700 text-gray-200' : ''} 
                    />
                  </div>
                  <Button 
                    onClick={handleEditProfile} 
                    className="w-full bg-gradient-to-r from-blue-600 to-green-600"
                  >
                    Save Changes
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          {/* Profile Info */}
          <div className="flex items-start gap-4">
            <div className="relative">
              <Avatar className="w-20 h-20 border-4 border-white shadow-xl">
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-green-500 text-white text-2xl">
                  {userStats.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div className="absolute -bottom-1 -right-1 text-2xl">{userStats.rankIcon}</div>
            </div>
            <div className="flex-1">
              <h1 className="text-white text-2xl mb-1">{userStats.name}</h1>
              <p className="text-blue-100 text-sm mb-2">{userStats.username}</p>
              <Badge className="bg-white/20 text-white border-white/30">
                {userStats.rank}
              </Badge>
            </div>
          </div>

          {/* Level Progress */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-blue-100 text-sm">Level {userStats.level}</span>
              <span className="text-blue-100 text-sm">{userStats.ecoPoints}/{userStats.nextLevelPoints} pts</span>
            </div>
            <Progress value={(userStats.ecoPoints / userStats.nextLevelPoints) * 100} className="h-2 bg-white/20" />
          </div>
        </div>
      </div>

      {/* Stats Cards - Overlapping Header */}
      <div className="px-4 -mt-16 relative z-10">
        <div className="grid grid-cols-3 gap-3 mb-4">
          <Card className={`p-4 text-center shadow-lg hover:shadow-xl transition-shadow ${
            isDark ? 'bg-gray-800 border-gray-700' : ''
          }`}>
            <div className={`flex items-center justify-center w-10 h-10 rounded-full mx-auto mb-2 ${
              isDark ? 'bg-green-900/30' : 'bg-green-100'
            }`}>
              <Leaf className={`w-5 h-5 ${isDark ? 'text-green-400' : 'text-green-600'}`} />
            </div>
            <div className={`text-xl ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>{userStats.carbonSaved}</div>
            <p className={`text-xs mt-1 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>kg CO₂ saved</p>
          </Card>

          <Card className={`p-4 text-center shadow-lg hover:shadow-xl transition-shadow ${
            isDark ? 'bg-gray-800 border-gray-700' : ''
          }`}>
            <div className={`flex items-center justify-center w-10 h-10 rounded-full mx-auto mb-2 ${
              isDark ? 'bg-amber-900/30' : 'bg-amber-100'
            }`}>
              <Flame className={`w-5 h-5 ${isDark ? 'text-amber-400' : 'text-amber-600'}`} />
            </div>
            <div className={`text-xl ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>{userStats.streakDays}</div>
            <p className={`text-xs mt-1 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>day streak</p>
          </Card>

          <Card className={`p-4 text-center shadow-lg hover:shadow-xl transition-shadow ${
            isDark ? 'bg-gray-800 border-gray-700' : ''
          }`}>
            <div className={`flex items-center justify-center w-10 h-10 rounded-full mx-auto mb-2 ${
              isDark ? 'bg-purple-900/30' : 'bg-purple-100'
            }`}>
              <Trophy className={`w-5 h-5 ${isDark ? 'text-purple-400' : 'text-purple-600'}`} />
            </div>
            <div className={`text-xl ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>{userStats.badges}</div>
            <p className={`text-xs mt-1 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>achievements</p>
          </Card>
        </div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="w-full grid grid-cols-3 mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="achievements">Badges</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-4">
            {/* Active Challenges */}
            <Card className={`p-4 shadow-lg ${isDark ? 'bg-gray-800 border-gray-700' : ''}`}>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Target className={`w-5 h-5 ${isDark ? 'text-blue-400' : 'text-blue-600'}`} />
                  <span className={isDark ? 'text-gray-100' : 'text-gray-900'}>Active Challenges</span>
                </div>
                <Button variant="ghost" size="sm" className={isDark ? 'text-blue-400' : 'text-blue-600'}>
                  View All
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
              <div className="space-y-3">
                {activeChallenges.map(challenge => (
                  <div key={challenge.id} className={`p-3 rounded-lg border ${
                    isDark 
                      ? 'bg-gradient-to-r from-gray-700 to-gray-600 border-gray-600' 
                      : 'bg-gradient-to-r from-blue-50 to-green-50 border-blue-100'
                  }`}>
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className={`text-sm ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>{challenge.title}</span>
                          <Badge variant="secondary" className={`text-xs ${
                            isDark ? 'bg-gray-700 text-gray-300' : ''
                          }`}>
                            +{challenge.reward} pts
                          </Badge>
                        </div>
                        <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>{challenge.description}</p>
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className={`flex items-center justify-between text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
                        <span>{challenge.progress}/{challenge.total} completed</span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {challenge.expiresIn}
                        </span>
                      </div>
                      <div className={`relative h-2 rounded-full overflow-hidden ${
                        isDark ? 'bg-gray-700' : 'bg-gray-200'
                      }`}>
                        <div 
                          className={`absolute inset-y-0 left-0 ${getCategoryColor(challenge.category)} rounded-full transition-all`}
                          style={{ width: `${(challenge.progress / challenge.total) * 100}%` }}
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </Card>

            {/* Travel Statistics */}
            <Card className="p-4 shadow-lg">
              <div className="flex items-center gap-2 mb-4">
                <BarChart3 className="w-5 h-5 text-blue-600" />
                <span className="text-gray-900">Travel Breakdown</span>
              </div>
              <div className="space-y-3">
                {travelStats.map((stat, index) => (
                  <div key={index}>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <stat.icon className={`w-4 h-4 ${stat.color}`} />
                        <span className="text-sm text-gray-700">{stat.label}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-900">{stat.trips} trips</span>
                        <span className="text-xs text-gray-500">{stat.percentage}%</span>
                      </div>
                    </div>
                    <Progress value={stat.percentage} className="h-1.5" />
                  </div>
                ))}
              </div>
            </Card>

            {/* Recent Activity */}
            <Card className="p-4 shadow-lg">
              <div className="flex items-center gap-2 mb-4">
                <Calendar className="w-5 h-5 text-blue-600" />
                <span className="text-gray-900">Recent Activity</span>
              </div>
              <div className="space-y-3">
                {recentActivity.map((activity, index) => (
                  <div key={index} className="flex items-start gap-3">
                    <div className="text-2xl">{activity.icon}</div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-900">{activity.action}</p>
                      <p className="text-xs text-gray-500">{activity.date}</p>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-700">
                      {activity.points}
                    </Badge>
                  </div>
                ))}
              </div>
            </Card>

            {/* Impact Summary */}
            <Card 
              ref={impactRef}
              className={`p-4 bg-gradient-to-r from-green-50 to-blue-50 border-green-200 shadow-lg transition-all duration-500 ${
                isImpactHighlighted 
                  ? 'ring-4 ring-green-400 ring-offset-2 scale-105 shadow-2xl' 
                  : ''
              }`}
            >
              <div className="flex items-center gap-2 mb-3">
                <Leaf className={`w-5 h-5 text-green-600 transition-transform duration-500 ${
                  isImpactHighlighted ? 'animate-bounce' : ''
                }`} />
                <span className="text-gray-900">Your Environmental Impact</span>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className={`transition-all duration-500 ${
                  isImpactHighlighted ? 'scale-110' : ''
                }`}>
                  <div className="text-2xl text-green-600 mb-1">{userStats.carbonSaved}kg</div>
                  <p className="text-xs text-gray-600">CO₂ emissions prevented</p>
                  <p className="text-xs text-green-600 mt-1">≈ 17 trees planted</p>
                </div>
                <div className={`transition-all duration-500 ${
                  isImpactHighlighted ? 'scale-110' : ''
                }`}>
                  <div className="text-2xl text-blue-600 mb-1">{userStats.totalTrips}</div>
                  <p className="text-xs text-gray-600">Eco-friendly trips</p>
                  <p className="text-xs text-blue-600 mt-1">Top 15% globally</p>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Achievements Tab */}
          <TabsContent value="achievements" className="space-y-4">
            <Card className="p-4 shadow-lg">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Award className="w-5 h-5 text-amber-600" />
                  <span className="text-gray-900">Achievements</span>
                </div>
                <Badge variant="secondary">{achievements.filter(a => !a.locked).length}/{achievements.length}</Badge>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {achievements.map(achievement => (
                  <div 
                    key={achievement.id}
                    className={`p-4 rounded-xl border-2 text-center transition-all ${
                      achievement.locked 
                        ? 'bg-gray-50 border-gray-200 opacity-60' 
                        : 'bg-gradient-to-br from-amber-50 to-yellow-50 border-amber-200 shadow-md'
                    }`}
                  >
                    <div className="text-4xl mb-2 filter" style={{ filter: achievement.locked ? 'grayscale(1)' : 'none' }}>
                      {achievement.icon}
                    </div>
                    <div className="text-sm text-gray-900 mb-1">{achievement.title}</div>
                    <p className="text-xs text-gray-600 mb-2">{achievement.description}</p>
                    {achievement.locked && achievement.progress !== undefined ? (
                      <div className="space-y-1">
                        <Progress value={(achievement.progress / (achievement.total || 1)) * 100} className="h-1.5" />
                        <p className="text-xs text-gray-500">{achievement.progress}/{achievement.total}</p>
                      </div>
                    ) : !achievement.locked && achievement.unlockedDate ? (
                      <div className="flex items-center justify-center gap-1 text-xs text-green-600">
                        <CheckCircle2 className="w-3 h-3" />
                        <span>{achievement.unlockedDate}</span>
                      </div>
                    ) : null}
                  </div>
                ))}
              </div>
            </Card>

            {/* Leaderboard Position */}
            <Card className="p-4 bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200 shadow-lg">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-12 h-12 bg-purple-100 rounded-full">
                  <Crown className="w-6 h-6 text-purple-600" />
                </div>
                <div className="flex-1">
                  <div className="text-sm text-gray-600">Your Global Rank</div>
                  <div className="text-2xl text-purple-600">#127</div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-gray-600">out of</div>
                  <div className="text-sm text-gray-900">12,458 users</div>
                </div>
              </div>
            </Card>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-4">
            {/* Account Settings */}
            <Card className="p-4 shadow-lg">
              <div className="flex items-center gap-2 mb-4">
                <User className="w-5 h-5 text-blue-600" />
                <span className="text-gray-900">Account Settings</span>
              </div>
              <div className="space-y-3">
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <Edit2 className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-900">Edit Profile</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <Shield className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-900">Privacy & Security</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <MapPin className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-900">Location Preferences</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>
              </div>
            </Card>

            {/* Notifications */}
            <Card className="p-4 shadow-lg">
              <div className="flex items-center gap-2 mb-4">
                <Bell className="w-5 h-5 text-blue-600" />
                <span className="text-gray-900">Notifications</span>
              </div>
              <div className="space-y-3">
                <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                  <div className="flex items-center gap-3 flex-1">
                    <div>
                      <div className="text-sm text-gray-900">Push Notifications</div>
                      <p className="text-xs text-gray-500">Receive alerts and updates</p>
                    </div>
                  </div>
                  <Switch checked={notifications} onCheckedChange={setNotifications} />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg bg-gray-50">
                  <div className="flex items-center gap-3 flex-1">
                    <div>
                      <div className="text-sm text-gray-900">Location Sharing</div>
                      <p className="text-xs text-gray-500">Share location with community</p>
                    </div>
                  </div>
                  <Switch checked={locationSharing} onCheckedChange={setLocationSharing} />
                </div>
              </div>
            </Card>

            {/* App Preferences */}
            <Card className="p-4 shadow-lg">
              <div className="flex items-center gap-2 mb-4">
                <Settings className="w-5 h-5 text-blue-600" />
                <span className="text-gray-900">App Preferences</span>
              </div>
              <div className="space-y-3">
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <Zap className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-900">Default Transport Mode</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">Metro</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </div>
                </button>
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <div className="flex items-center gap-3">
                    <Target className="w-4 h-4 text-gray-600" />
                    <span className="text-sm text-gray-900">Monthly Carbon Goal</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-gray-500">50 kg</span>
                    <ChevronRight className="w-4 h-4 text-gray-400" />
                  </div>
                </button>
              </div>
            </Card>

            {/* Support & Info */}
            <Card className="p-4 shadow-lg">
              <div className="flex items-center gap-2 mb-4">
                <HelpCircle className="w-5 h-5 text-blue-600" />
                <span className="text-gray-900">Support & Information</span>
              </div>
              <div className="space-y-3">
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <span className="text-sm text-gray-900">Help Center</span>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <span className="text-sm text-gray-900">Terms of Service</span>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-gray-50 transition-colors">
                  <span className="text-sm text-gray-900">Privacy Policy</span>
                  <ChevronRight className="w-4 h-4 text-gray-400" />
                </button>
                <Separator />
                <div className="p-3 text-center">
                  <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>GATYAH v1.0.0</p>
                  <p className={`text-xs mt-1 ${isDark ? 'text-gray-500' : 'text-gray-400'}`}>© 2025 All rights reserved</p>
                </div>
              </div>
            </Card>

            {/* Logout Button */}
            <Button 
              variant="outline" 
              className="w-full text-red-600 border-red-200 hover:bg-red-50"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Log Out
            </Button>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ProfilePage;
