import { Brain, TrendingUp, Clock, MapPin, AlertCircle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from 'recharts';

interface PredictionPageProps {
  isDark?: boolean;
}

const hourlyPredictions = [
  { hour: '10AM', congestion: 45, confidence: 92 },
  { hour: '11AM', congestion: 55, confidence: 89 },
  { hour: '12PM', congestion: 68, confidence: 87 },
  { hour: '1PM', congestion: 72, confidence: 85 },
  { hour: '2PM', congestion: 65, confidence: 88 },
  { hour: '3PM', congestion: 78, confidence: 84 },
  { hour: '4PM', congestion: 85, confidence: 82 },
  { hour: '5PM', congestion: 92, confidence: 86 },
  { hour: '6PM', congestion: 88, confidence: 88 },
];

export default function PredictionPage({ isDark }: PredictionPageProps) {
  const currentPrediction = {
    congestion: 68,
    confidence: 87,
    trend: 'increasing',
    peakTime: '5:30 PM',
    status: 'Moderate',
  };

  const getStatusColor = (level: number) => {
    if (level < 50) return { bg: isDark ? 'bg-[#2e7d32]/20' : 'bg-[#e8f5e9]', text: 'text-[#4caf50]', label: 'Low' };
    if (level < 75) return { bg: isDark ? 'bg-[#ff9800]/20' : 'bg-[#fff3e0]', text: 'text-[#ff9800]', label: 'Moderate' };
    return { bg: isDark ? 'bg-[#d32f2f]/20' : 'bg-[#ffebee]', text: 'text-[#ef5350]', label: 'High' };
  };

  const status = getStatusColor(currentPrediction.congestion);

  return (
    <div className="flex-1 overflow-y-auto pb-24 px-4 py-6">
      {/* Page Title */}
      <div className="mb-6">
        <div className="flex items-center gap-2 mb-2">
          <Brain className={`w-6 h-6 ${isDark ? 'text-[#4caf50]' : 'text-[#2e7d32]'}`} />
          <h1 className={isDark ? 'text-gray-100' : 'text-gray-900'}>
            AI Predictions
          </h1>
        </div>
        <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
          ML-powered traffic congestion forecasts
        </p>
      </div>

      {/* Current Prediction Card */}
      <div
        className={`rounded-2xl p-6 mb-6 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow-lg)' }}
      >
        <div className="flex items-start justify-between mb-5">
          <div>
            <div className={`text-xs mb-1 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Current Congestion Prediction
            </div>
            <div className="flex items-baseline gap-2">
              <span className={`text-4xl ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                {currentPrediction.congestion}%
              </span>
              <span className={`px-3 py-1 rounded-full text-xs ${status.bg} ${status.text}`}>
                {status.label}
              </span>
            </div>
          </div>
          
          <div className={`px-4 py-2 rounded-xl ${isDark ? 'bg-[#2e7d32]/20' : 'bg-[#e8f5e9]'}`}>
            <div className={`text-xs mb-1 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Confidence
            </div>
            <div className="flex items-center gap-1">
              <div className="text-xl text-[#4caf50]">{currentPrediction.confidence}%</div>
            </div>
          </div>
        </div>

        {/* Confidence Bar */}
        <div className="mb-5">
          <div className="flex items-center justify-between text-xs mb-2">
            <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>Prediction Accuracy</span>
            <span className="text-[#4caf50]">High Confidence</span>
          </div>
          <div className={`w-full h-2 rounded-full ${isDark ? 'bg-gray-700' : 'bg-gray-200'}`}>
            <div 
              className="h-2 rounded-full bg-gradient-to-r from-[#2e7d32] to-[#4caf50]"
              style={{ width: `${currentPrediction.confidence}%` }}
            />
          </div>
        </div>

        {/* Key Insights */}
        <div className="grid grid-cols-2 gap-4">
          <div className={`p-3 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
            <div className="flex items-center gap-2 mb-1">
              <TrendingUp className="w-4 h-4 text-[#ff9800]" />
              <span className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Trend</span>
            </div>
            <div className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
              {currentPrediction.trend}
            </div>
          </div>

          <div className={`p-3 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
            <div className="flex items-center gap-2 mb-1">
              <Clock className="w-4 h-4 text-[#1976d2]" />
              <span className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Peak Time</span>
            </div>
            <div className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
              {currentPrediction.peakTime}
            </div>
          </div>
        </div>
      </div>

      {/* Hourly Forecast Chart */}
      <div
        className={`rounded-2xl p-5 mb-6 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow-lg)' }}
      >
        <div className="mb-4">
          <h3 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            Hourly Forecast
          </h3>
          <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            AI-powered traffic predictions for the next 9 hours
          </p>
        </div>

        <ResponsiveContainer width="100%" height={240}>
          <AreaChart data={hourlyPredictions}>
            <defs>
              <linearGradient id="congestionGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#1976d2" stopOpacity={0.4}/>
                <stop offset="100%" stopColor="#1976d2" stopOpacity={0}/>
              </linearGradient>
              <filter id="shadow">
                <feDropShadow dx="0" dy="2" stdDeviation="3" floodOpacity="0.3"/>
              </filter>
            </defs>
            <CartesianGrid 
              strokeDasharray="3 3" 
              stroke={isDark ? '#333' : '#e0e0e0'} 
              vertical={false}
            />
            <XAxis 
              dataKey="hour" 
              stroke={isDark ? '#9e9e9e' : '#666'}
              style={{ fontSize: '12px' }}
              axisLine={{ stroke: isDark ? '#444' : '#ccc' }}
              tickLine={false}
            />
            <YAxis 
              stroke={isDark ? '#9e9e9e' : '#666'}
              style={{ fontSize: '12px' }}
              axisLine={{ stroke: isDark ? '#444' : '#ccc' }}
              tickLine={false}
              domain={[0, 100]}
              ticks={[0, 25, 50, 75, 100]}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: isDark ? '#1e1e1e' : '#fff',
                border: `2px solid ${isDark ? '#444' : '#e0e0e0'}`,
                borderRadius: '12px',
                boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
              }}
              labelStyle={{
                color: isDark ? '#fff' : '#000',
                fontWeight: 600,
              }}
            />
            <Area 
              type="monotone" 
              dataKey="congestion" 
              stroke="#1976d2" 
              strokeWidth={3}
              fill="url(#congestionGradient)"
              filter="url(#shadow)"
              dot={{ 
                fill: '#1976d2', 
                strokeWidth: 2, 
                r: 4,
                stroke: '#fff'
              }}
              activeDot={{ 
                r: 6, 
                fill: '#1976d2',
                stroke: '#fff',
                strokeWidth: 2
              }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Location-based Predictions */}
      <div
        className={`rounded-2xl p-5 mb-6 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow)' }}
      >
        <div className="mb-4">
          <h3 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            Hotspot Predictions
          </h3>
          <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Expected congestion by location
          </p>
        </div>

        <div className="space-y-3">
          {[
            { name: 'FC Road Junction', level: 85, time: '5:00 PM - 7:00 PM' },
            { name: 'Shivajinagar Circle', level: 72, time: '5:30 PM - 6:30 PM' },
            { name: 'Deccan Gymkhana', level: 68, time: '6:00 PM - 7:30 PM' },
            { name: 'Swargate Square', level: 55, time: '5:15 PM - 6:45 PM' },
          ].map((location, index) => {
            const locationStatus = getStatusColor(location.level);
            
            return (
              <div
                key={index}
                className={`p-4 rounded-xl border ${
                  isDark ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
                }`}
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-start gap-2 flex-1">
                    <MapPin className={`w-4 h-4 mt-0.5 ${isDark ? 'text-gray-400' : 'text-gray-600'}`} />
                    <div className="flex-1">
                      <div className={`text-sm mb-1 ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                        {location.name}
                      </div>
                      <div className="flex items-center gap-2 text-xs">
                        <Clock className={`w-3 h-3 ${isDark ? 'text-gray-500' : 'text-gray-500'}`} />
                        <span className={isDark ? 'text-gray-500' : 'text-gray-500'}>
                          {location.time}
                        </span>
                      </div>
                    </div>
                  </div>
                  
                  <div className={`px-3 py-1 rounded-full text-xs ${locationStatus.bg} ${locationStatus.text}`}>
                    {location.level}%
                  </div>
                </div>
                
                <div className={`w-full h-1.5 rounded-full mt-3 ${isDark ? 'bg-gray-700' : 'bg-gray-200'}`}>
                  <div 
                    className={`h-1.5 rounded-full ${
                      location.level < 50 ? 'bg-[#4caf50]' : 
                      location.level < 75 ? 'bg-[#ff9800]' : 'bg-[#ef5350]'
                    }`}
                    style={{ width: `${location.level}%` }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* AI Model Info */}
      <div
        className={`rounded-2xl p-5 ${isDark ? 'bg-gradient-to-br from-[#1976d2]/20 to-[#0d47a1]/20 border border-[#1976d2]/30' : 'bg-gradient-to-br from-[#e3f2fd] to-[#bbdefb]'}`}
      >
        <div className="flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-[#1976d2] mt-0.5" />
          <div>
            <div className={`text-sm mb-1 ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
              AI Model Information
            </div>
            <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-700'}`}>
              Predictions powered by advanced ML algorithms trained on historical traffic patterns, weather data, and real-time sensor inputs.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
