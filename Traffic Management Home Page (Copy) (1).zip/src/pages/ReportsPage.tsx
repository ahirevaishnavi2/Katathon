import { FileText, Download, Calendar, TrendingUp, BarChart3, ExternalLink, Globe } from 'lucide-react';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { toast } from 'sonner@2.0.3';

interface ReportsPageProps {
  isDark?: boolean;
}

const weeklyTrafficData = [
  { day: 'Mon', vehicles: 12400 },
  { day: 'Tue', vehicles: 13200 },
  { day: 'Wed', vehicles: 11800 },
  { day: 'Thu', vehicles: 14100 },
  { day: 'Fri', vehicles: 15200 },
  { day: 'Sat', vehicles: 10500 },
  { day: 'Sun', vehicles: 9800 },
];

const violationTrendData = [
  { month: 'Jan', count: 234 },
  { month: 'Feb', count: 198 },
  { month: 'Mar', count: 256 },
  { month: 'Apr', count: 189 },
  { month: 'May', count: 223 },
  { month: 'Jun', count: 176 },
];

const violationTypeData = [
  { name: 'Speeding', value: 45, color: '#ef5350' },
  { name: 'Red Light', value: 32, color: '#ff9800' },
  { name: 'Wrong Lane', value: 28, color: '#1976d2' },
  { name: 'Others', value: 19, color: '#9e9e9e' },
];

export default function ReportsPage({ isDark }: ReportsPageProps) {
  const handleOpenWebAnalytics = () => {
    toast.success('Opening web analytics dashboard...', {
      position: 'top-center',
    });
    // In a real app, this would open the web analytics portal
    // window.open('https://analytics.gatyah.com', '_blank');
  };

  const availableReports = [
    {
      title: 'Daily Traffic Summary',
      description: 'Comprehensive daily traffic analysis',
      date: '2024-11-25',
      type: 'PDF',
      size: '2.4 MB',
    },
    {
      title: 'Weekly Violations Report',
      description: 'Traffic violations breakdown',
      date: '2024-11-20',
      type: 'CSV',
      size: '1.1 MB',
    },
    {
      title: 'Monthly Analytics',
      description: 'Monthly traffic patterns and insights',
      date: '2024-11-01',
      type: 'PDF',
      size: '5.2 MB',
    },
    {
      title: 'Camera Performance Report',
      description: 'Camera uptime and quality metrics',
      date: '2024-11-15',
      type: 'PDF',
      size: '1.8 MB',
    },
  ];

  return (
    <div className="flex-1 overflow-y-auto pb-24 px-4 py-6">
      {/* Page Title */}
      <div className="mb-6">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <h1 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
              Reports & Analytics
            </h1>
            <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Download and analyze traffic data
            </p>
          </div>
          <button
            onClick={handleOpenWebAnalytics}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl border-2 transition-all ${
              isDark
                ? 'border-[#1976d2] text-[#1976d2] hover:bg-[#1976d2] hover:text-white'
                : 'border-[#1976d2] text-[#1976d2] hover:bg-[#1976d2] hover:text-white'
            }`}
          >
            <Globe className="w-4 h-4" />
            <span className="text-sm">Web Portal</span>
          </button>
        </div>
      </div>

      {/* Web Analytics Banner */}
      <div
        className={`rounded-2xl p-5 mb-6 ${
          isDark 
            ? 'bg-gradient-to-br from-[#1976d2]/20 to-[#1565c0]/20 border border-[#1976d2]/30' 
            : 'bg-gradient-to-br from-[#e3f2fd] to-[#bbdefb] border border-[#1976d2]/20'
        }`}
        style={{ boxShadow: 'var(--shadow)' }}
      >
        <div className="flex items-start gap-4">
          <div className={`p-3 rounded-xl ${isDark ? 'bg-[#1976d2]/30' : 'bg-[#1976d2]/20'}`}>
            <BarChart3 className="w-6 h-6 text-[#1976d2]" />
          </div>
          <div className="flex-1">
            <h3 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
              Advanced Analytics Portal
            </h3>
            <p className={`text-sm mb-3 ${isDark ? 'text-gray-400' : 'text-gray-700'}`}>
              Access comprehensive analytics, custom dashboards, and advanced reporting tools on our web platform for deeper insights.
            </p>
            <button
              onClick={handleOpenWebAnalytics}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#1976d2] to-[#1565c0] text-white hover:shadow-lg transition-all text-sm"
            >
              <ExternalLink className="w-4 h-4" />
              <span>Open Web Dashboard</span>
            </button>
          </div>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div
          className={`rounded-2xl p-5 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
          style={{ boxShadow: 'var(--shadow)' }}
        >
          <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Reports Generated
          </div>
          <div className={`text-2xl mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            124
          </div>
          <div className="flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-[#4caf50]" />
            <span className="text-xs text-[#4caf50]">+12 this week</span>
          </div>
        </div>

        <div
          className={`rounded-2xl p-5 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
          style={{ boxShadow: 'var(--shadow)' }}
        >
          <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Data Analyzed
          </div>
          <div className={`text-2xl mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            2.4 TB
          </div>
          <div className="flex items-center gap-1">
            <TrendingUp className="w-3 h-3 text-[#4caf50]" />
            <span className="text-xs text-[#4caf50]">+0.3 TB</span>
          </div>
        </div>
      </div>

      {/* Weekly Traffic Chart */}
      <div
        className={`rounded-2xl p-5 mb-6 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow)' }}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
              Weekly Traffic Volume
            </h3>
            <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Vehicle count by day
            </p>
          </div>
          <button className={`p-2 rounded-lg ${isDark ? 'hover:bg-gray-800' : 'hover:bg-gray-100'}`}>
            <Download className={`w-5 h-5 ${isDark ? 'text-gray-400' : 'text-gray-600'}`} />
          </button>
        </div>

        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={weeklyTrafficData}>
            <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#333' : '#e0e0e0'} />
            <XAxis 
              dataKey="day" 
              stroke={isDark ? '#9e9e9e' : '#666'}
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke={isDark ? '#9e9e9e' : '#666'}
              style={{ fontSize: '12px' }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: isDark ? '#1e1e1e' : '#fff',
                border: `1px solid ${isDark ? '#333' : '#e0e0e0'}`,
                borderRadius: '12px',
              }}
            />
            <Bar dataKey="vehicles" fill="#2e7d32" radius={[8, 8, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Violation Trends */}
      <div
        className={`rounded-2xl p-5 mb-6 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow)' }}
      >
        <div className="mb-4">
          <h3 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            Violation Trends
          </h3>
          <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            6-month violation history
          </p>
        </div>

        <ResponsiveContainer width="100%" height={200}>
          <LineChart data={violationTrendData}>
            <CartesianGrid strokeDasharray="3 3" stroke={isDark ? '#333' : '#e0e0e0'} />
            <XAxis 
              dataKey="month" 
              stroke={isDark ? '#9e9e9e' : '#666'}
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke={isDark ? '#9e9e9e' : '#666'}
              style={{ fontSize: '12px' }}
            />
            <Tooltip 
              contentStyle={{
                backgroundColor: isDark ? '#1e1e1e' : '#fff',
                border: `1px solid ${isDark ? '#333' : '#e0e0e0'}`,
                borderRadius: '12px',
              }}
            />
            <Line 
              type="monotone" 
              dataKey="count" 
              stroke="#1976d2" 
              strokeWidth={3}
              dot={{ fill: '#1976d2', r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* Violation Distribution */}
      <div
        className={`rounded-2xl p-5 mb-6 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow)' }}
      >
        <div className="mb-4">
          <h3 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
            Violation Distribution
          </h3>
          <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            By violation type
          </p>
        </div>

        <div className="flex items-center justify-between">
          <ResponsiveContainer width="50%" height={180}>
            <PieChart>
              <Pie
                data={violationTypeData}
                cx="50%"
                cy="50%"
                innerRadius={40}
                outerRadius={70}
                paddingAngle={5}
                dataKey="value"
              >
                {violationTypeData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
            </PieChart>
          </ResponsiveContainer>

          <div className="flex-1 space-y-2">
            {violationTypeData.map((item, index) => (
              <div key={index} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div 
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: item.color }}
                  />
                  <span className={isDark ? 'text-gray-300' : 'text-gray-700'}>
                    {item.name}
                  </span>
                </div>
                <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                  {item.value}%
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Available Reports */}
      <div
        className={`rounded-2xl p-5 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow)' }}
      >
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
              Available Reports
            </h3>
            <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Download generated reports
            </p>
          </div>
          <button className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#2e7d32] to-[#1b5e20] text-white text-sm">
            Generate New
          </button>
        </div>

        <div className="space-y-3">
          {availableReports.map((report, index) => (
            <div
              key={index}
              className={`p-4 rounded-xl border transition-all hover:shadow-md ${
                isDark ? 'bg-gray-800 border-gray-700' : 'bg-gray-50 border-gray-200'
              }`}
            >
              <div className="flex items-start gap-3">
                <div className={`p-2 rounded-lg ${isDark ? 'bg-[#1976d2]/20' : 'bg-[#e3f2fd]'}`}>
                  <FileText className="w-5 h-5 text-[#1976d2]" />
                </div>

                <div className="flex-1 min-w-0">
                  <h4 className={`text-sm mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                    {report.title}
                  </h4>
                  <p className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                    {report.description}
                  </p>
                  
                  <div className="flex items-center gap-3 text-xs">
                    <div className="flex items-center gap-1">
                      <Calendar className={`w-3 h-3 ${isDark ? 'text-gray-500' : 'text-gray-500'}`} />
                      <span className={isDark ? 'text-gray-500' : 'text-gray-500'}>
                        {report.date}
                      </span>
                    </div>
                    <span className={`px-2 py-0.5 rounded ${
                      isDark ? 'bg-gray-700 text-gray-400' : 'bg-gray-200 text-gray-600'
                    }`}>
                      {report.type}
                    </span>
                    <span className={isDark ? 'text-gray-500' : 'text-gray-500'}>
                      {report.size}
                    </span>
                  </div>
                </div>

                <button
                  className={`p-2 rounded-lg transition-all ${
                    isDark ? 'hover:bg-gray-700 text-gray-300' : 'hover:bg-gray-200 text-gray-700'
                  }`}
                >
                  <Download className="w-5 h-5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
