import { Send, Mic, MicOff, Sparkles, MapPin, Route, Clock, TrendingUp, Leaf, AlertCircle, X, Bot, User } from 'lucide-react';
import { useState, useRef, useEffect } from 'react';

interface Message {
  id: number;
  type: 'user' | 'bot';
  text: string;
  timestamp: Date;
  suggestions?: string[];
}

interface QuickAction {
  id: number;
  icon: any;
  label: string;
  prompt: string;
  color: string;
}

interface ChatbotPageProps {
  isDark?: boolean;
}

export function ChatbotPage({ isDark }: ChatbotPageProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      type: 'bot',
      text: "Hi! I'm your GATYAH AI assistant. I can help you with routes, traffic updates, air quality, and eco-friendly travel options. How can I assist you today?",
      timestamp: new Date(),
      suggestions: [
        "Find the fastest route to work",
        "Show me quiet walking paths",
        "What's the air quality near me?",
      ],
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const quickActions: QuickAction[] = [
    { id: 1, icon: Route, label: 'Best Route', prompt: 'Find me the best eco-friendly route to Phoenix Mall', color: 'bg-blue-100 text-blue-600' },
    { id: 2, icon: MapPin, label: 'Nearby POIs', prompt: 'Show me nearby EV charging stations', color: 'bg-green-100 text-green-600' },
    { id: 3, icon: Clock, label: 'Traffic Now', prompt: 'What\'s the traffic situation on FC Road right now?', color: 'bg-amber-100 text-amber-600' },
    { id: 4, icon: Leaf, label: 'Quiet Routes', prompt: 'Find me a quiet walking route with low noise and good air quality', color: 'bg-emerald-100 text-emerald-600' },
    { id: 5, icon: TrendingUp, label: 'My Stats', prompt: 'Show me my carbon savings and eco-score this week', color: 'bg-purple-100 text-purple-600' },
    { id: 6, icon: AlertCircle, label: 'Alerts', prompt: 'What active alerts are there in my area?', color: 'bg-red-100 text-red-600' },
  ];

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = (text: string) => {
    if (!text.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      type: 'user',
      text: text.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInputText('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const botResponse = generateBotResponse(text);
      setMessages(prev => [...prev, botResponse]);
      setIsTyping(false);
    }, 1500 + Math.random() * 1000);
  };

  const generateBotResponse = (userText: string): Message => {
    const lowerText = userText.toLowerCase();
    let responseText = '';
    let suggestions: string[] = [];

    if (lowerText.includes('route') || lowerText.includes('direction')) {
      responseText = "🗺️ I found 3 routes for you:\n\n" +
        "✅ Eco-Friendly Route: 18 min (5.2 km)\n• 420g CO₂ saved\n• Light traffic\n• Passes through 2 parks\n\n" +
        "⚡ Balanced Route: 15 min (6.8 km)\n• 180g CO₂ saved\n• Moderate traffic\n\n" +
        "🚗 Fastest Route: 12 min (7.5 km)\n• Heavy traffic\n\n" +
        "I recommend the Eco-Friendly Route! Would you like me to start navigation?";
      suggestions = ["Start eco-friendly route", "Compare all routes", "Avoid tolls"];
    } else if (lowerText.includes('traffic')) {
      responseText = "🚦 Current traffic status:\n\n" +
        "• FC Road: Heavy congestion (delays 8-12 min)\n" +
        "• MG Road: Moderate traffic\n" +
        "• JM Road: Light traffic\n" +
        "• Senapati Bapat: Flowing smoothly\n\n" +
        "Peak hour expected until 7:30 PM. Consider taking alternate routes via Karve Road.";
      suggestions = ["Show alternate routes", "Set traffic alerts", "Best time to leave"];
    } else if (lowerText.includes('air quality') || lowerText.includes('aqi')) {
      responseText = "🌬️ Air Quality Index (AQI) in your area:\n\n" +
        "📍 Current Location: AQI 87 (Moderate)\n" +
        "🌳 Koregaon Park: AQI 62 (Good)\n" +
        "🏭 Hadapsar: AQI 134 (Unhealthy for sensitive groups)\n" +
        "🌲 Bund Garden: AQI 58 (Good)\n\n" +
        "Recommendation: Consider routes through park areas for better air quality.";
      suggestions = ["Find clean air routes", "Set AQI alerts", "View AQI map"];
    } else if (lowerText.includes('quiet') || lowerText.includes('noise')) {
      responseText = "🤫 Found peaceful walking routes for you:\n\n" +
        "🌳 Sarasbaug Park Loop (2.1 km)\n• Noise level: 45 dB (Very quiet)\n• Tree-lined path with benches\n\n" +
        "🌲 Bund Garden to Empress Garden (3.4 km)\n• Noise level: 52 dB (Quiet)\n• Scenic riverside path\n\n" +
        "Perfect for a peaceful walk or cycling!";
      suggestions = ["Start navigation", "Show more quiet routes", "Save this route"];
    } else if (lowerText.includes('ev') || lowerText.includes('charging')) {
      responseText = "⚡ EV Charging stations near you:\n\n" +
        "🔌 EV Hub FC Road (850m away)\n• 4 fast chargers available\n• Estimated wait: 5 min\n\n" +
        "🔌 EV Station Koregaon Park (2.1 km)\n• 6 chargers, 2 available\n\n" +
        "🔌 EV Point Kothrud (3.8 km)\n• All chargers available\n\n" +
        "Would you like directions to the nearest one?";
      suggestions = ["Navigate to closest", "Check prices", "Reserve a spot"];
    } else if (lowerText.includes('carbon') || lowerText.includes('eco') || lowerText.includes('stats')) {
      responseText = "🌱 Your Eco-Stats this week:\n\n" +
        "✨ Carbon Saved: 2.8 kg CO₂\n" +
        "🚶 Walked: 12.4 km\n" +
        "🚴 Cycled: 8.2 km\n" +
        "🚇 Public Transit: 15 trips\n" +
        "⚡ Eco-routes taken: 11\n\n" +
        "You're in the top 15% of eco-conscious users! Keep up the great work! 🎉";
      suggestions = ["View detailed report", "Join challenges", "Share achievements"];
    } else if (lowerText.includes('alert')) {
      responseText = "⚠️ Active alerts in your area:\n\n" +
        "🚧 Road work on University Road (until Nov 15)\n" +
        "🌧️ Rain expected 6-8 PM (moderate)\n" +
        "🚦 Traffic signal malfunction at Deccan Junction\n" +
        "🎉 Car-Free Sunday in Koregaon Park (Nov 10)\n\n" +
        "Would you like notifications for updates?";
      suggestions = ["Enable alerts", "View alert map", "Report an issue"];
    } else {
      responseText = "I understand you're asking about: \"" + userText + "\"\n\n" +
        "I can help you with:\n" +
        "• 🗺️ Finding optimal routes\n" +
        "• 🚦 Real-time traffic updates\n" +
        "• 🌬️ Air quality information\n" +
        "• 🌳 Quiet, peaceful routes\n" +
        "• ⚡ EV charging stations\n" +
        "• 📊 Your eco-stats and carbon savings\n\n" +
        "What would you like to know more about?";
      suggestions = ["Find a route", "Check traffic", "Show AQI map"];
    }

    return {
      id: messages.length + 2,
      type: 'bot',
      text: responseText,
      timestamp: new Date(),
      suggestions,
    };
  };

  const handleQuickAction = (prompt: string) => {
    handleSendMessage(prompt);
  };

  const handleSuggestionClick = (suggestion: string) => {
    handleSendMessage(suggestion);
  };

  const toggleVoiceInput = () => {
    setIsListening(!isListening);
    
    if (!isListening) {
      // Simulate voice input
      setTimeout(() => {
        setIsListening(false);
        setInputText("Find me the fastest route to Koregaon Park");
      }, 2000);
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className={`flex-1 flex flex-col relative overflow-hidden ${
      isDark ? 'bg-gradient-to-b from-gray-900 to-gray-800' : 'bg-gradient-to-b from-blue-50 to-white'
    }`}>
      {/* Chat Header with AI Assistant Info */}
      <div className={`border-b px-4 py-3 shadow-sm ${
        isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
      }`}>
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center shadow-lg">
            <Sparkles className="w-5 h-5 text-white" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className={isDark ? 'text-gray-100' : 'text-gray-900'}>GATYAH AI</span>
              <div className="flex items-center gap-1 bg-green-100 px-2 py-0.5 rounded-full">
                <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
                <span className="text-xs text-green-700">Online</span>
              </div>
            </div>
            <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>Your smart travel assistant</p>
          </div>
        </div>
      </div>

      {/* Quick Actions */}
      {messages.length <= 2 && (
        <div className={`p-4 border-b ${
          isDark ? 'border-gray-700 bg-gray-800' : 'border-gray-100 bg-white'
        }`}>
          <p className={`text-xs mb-3 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Quick Actions</p>
          <div className="grid grid-cols-3 gap-2">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <button
                  key={action.id}
                  onClick={() => handleQuickAction(action.prompt)}
                  className={`${action.color} rounded-xl p-3 hover:scale-105 transition-transform flex flex-col items-center gap-1.5 shadow-sm`}
                >
                  <Icon className="w-5 h-5" />
                  <span className="text-xs text-center leading-tight">{action.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.map((message) => (
          <div key={message.id} className="space-y-2">
            <div className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'} items-end gap-2`}>
              {message.type === 'bot' && (
                <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
                  <Bot className="w-4 h-4 text-white" />
                </div>
              )}
              
              <div className={`max-w-[75%] ${message.type === 'user' ? 'order-first' : ''}`}>
                <div
                  className={`rounded-2xl px-4 py-3 shadow-sm ${
                    message.type === 'user'
                      ? 'bg-blue-600 text-white rounded-br-sm'
                      : isDark 
                        ? 'bg-gray-700 text-gray-100 border border-gray-600 rounded-bl-sm'
                        : 'bg-white text-gray-900 border border-gray-100 rounded-bl-sm'
                  }`}
                >
                  <p className="whitespace-pre-line text-sm leading-relaxed">{message.text}</p>
                </div>
                <p className={`text-xs mt-1 px-1 ${message.type === 'user' ? 'text-right' : 'text-left'} ${
                  isDark ? 'text-gray-500' : 'text-gray-400'
                }`}>
                  {formatTime(message.timestamp)}
                </p>
              </div>

              {message.type === 'user' && (
                <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
                  <User className="w-4 h-4 text-white" />
                </div>
              )}
            </div>

            {/* Suggestions */}
            {message.suggestions && message.suggestions.length > 0 && message.id === messages[messages.length - 1].id && (
              <div className="flex flex-wrap gap-2 ml-10">
                {message.suggestions.map((suggestion, idx) => (
                  <button
                    key={idx}
                    onClick={() => handleSuggestionClick(suggestion)}
                    className="bg-white border-2 border-blue-200 text-blue-700 text-xs px-3 py-2 rounded-full hover:bg-blue-50 hover:border-blue-300 transition-all shadow-sm hover:shadow-md"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}

        {/* Typing Indicator */}
        {isTyping && (
          <div className="flex items-end gap-2">
            <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center flex-shrink-0 shadow-md">
              <Bot className="w-4 h-4 text-white" />
            </div>
            <div className={`rounded-2xl rounded-bl-sm px-4 py-3 shadow-sm border ${
              isDark ? 'bg-gray-700 border-gray-600' : 'bg-white border-gray-100'
            }`}>
              <div className="flex items-center gap-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Voice Listening Overlay */}
      {isListening && (
        <div className="absolute inset-0 bg-blue-600 bg-opacity-95 flex flex-col items-center justify-center z-50 animate-in fade-in duration-200">
          <div className="relative">
            <div className="w-32 h-32 bg-white rounded-full flex items-center justify-center shadow-2xl">
              <Mic className="w-16 h-16 text-blue-600" />
            </div>
            <div className="absolute inset-0 w-32 h-32 bg-white rounded-full animate-ping opacity-50"></div>
            <div className="absolute inset-0 w-32 h-32 bg-white rounded-full animate-ping opacity-30" style={{ animationDelay: '0.5s' }}></div>
          </div>
          <p className="text-white text-xl mt-8 mb-2">Listening...</p>
          <p className="text-blue-200 text-sm mb-8">Speak your request now</p>
          <button
            onClick={toggleVoiceInput}
            className="bg-white text-blue-600 px-6 py-3 rounded-full hover:bg-blue-50 transition-colors shadow-lg"
          >
            Stop Listening
          </button>
        </div>
      )}

      {/* Input Area */}
      <div className={`border-t p-4 shadow-lg ${
        isDark ? 'bg-gray-800 border-gray-700' : 'bg-white border-gray-200'
      }`}>
        <div className="flex items-end gap-3">
          <div className={`flex-1 rounded-2xl border-2 focus-within:border-blue-400 transition-colors ${
            isDark ? 'bg-gray-700 border-gray-600' : 'bg-gray-50 border-gray-200'
          }`}>
            <input
              ref={inputRef}
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage(inputText)}
              placeholder="Ask me anything..."
              className={`w-full bg-transparent px-4 py-3 outline-none placeholder-gray-400 ${
                isDark ? 'text-gray-100' : 'text-gray-900'
              }`}
            />
          </div>
          
          {/* Voice Button */}
          <button
            onClick={toggleVoiceInput}
            className={`p-3 rounded-2xl transition-all shadow-lg hover:scale-105 ${
              isListening
                ? 'bg-red-500 hover:bg-red-600'
                : 'bg-gradient-to-br from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700'
            }`}
          >
            {isListening ? (
              <MicOff className="w-6 h-6 text-white" />
            ) : (
              <Mic className="w-6 h-6 text-white" />
            )}
          </button>

          {/* Send Button */}
          <button
            onClick={() => handleSendMessage(inputText)}
            disabled={!inputText.trim()}
            className={`p-3 rounded-2xl transition-all shadow-lg hover:scale-105 ${
              inputText.trim()
                ? 'bg-gradient-to-br from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800'
                : 'bg-gray-200'
            }`}
          >
            <Send className={`w-6 h-6 ${inputText.trim() ? 'text-white' : 'text-gray-400'}`} />
          </button>
        </div>
      </div>
    </div>
  );
}
