import { AlertTriangle, MapPin, Clock, ChevronRight, Filter, X, CheckCircle, TrendingUp, Zap } from 'lucide-react';
import { useState } from 'react';

interface AlertsPageProps {
  isDark?: boolean;
}

type AlertStatus = 'active' | 'resolved' | 'unattended' | 'in-progress';

interface Alert {
  id: string;
  title: string;
  location: string;
  time: string;
  severity: 'high' | 'medium' | 'low';
  description: string;
  status: AlertStatus;
  details?: {
    affectedVehicles: number;
    estimatedDelay: string;
    reportedBy: string;
    trafficDensity: number;
  };
}

export default function AlertsPage({ isDark }: AlertsPageProps) {
  const [filter, setFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [alerts, setAlerts] = useState<Alert[]>([
    {
      id: 'A-001',
      title: 'Heavy Traffic Congestion',
      location: 'FC Road Junction',
      time: '5 mins ago',
      severity: 'high',
      description: 'Major traffic buildup due to accident',
      status: 'active',
      details: {
        affectedVehicles: 250,
        estimatedDelay: '15-20 mins',
        reportedBy: 'Traffic Camera #12',
        trafficDensity: 85,
      },
    },
    {
      id: 'A-002',
      title: 'Road Closure',
      location: 'Shivajinagar Main Road',
      time: '12 mins ago',
      severity: 'high',
      description: 'Construction work in progress',
      status: 'in-progress',
      details: {
        affectedVehicles: 180,
        estimatedDelay: '30+ mins',
        reportedBy: 'Municipal Authority',
        trafficDensity: 72,
      },
    },
    {
      id: 'A-003',
      title: 'Poor Air Quality',
      location: 'Deccan Gymkhana',
      time: '25 mins ago',
      severity: 'medium',
      description: 'AQI levels rising above 150',
      status: 'unattended',
      details: {
        affectedVehicles: 120,
        estimatedDelay: 'N/A',
        reportedBy: 'Air Quality Sensor',
        trafficDensity: 45,
      },
    },
    {
      id: 'A-004',
      title: 'Signal Malfunction',
      location: 'Swargate Square',
      time: '1 hour ago',
      severity: 'medium',
      description: 'Traffic signal not functioning',
      status: 'resolved',
      details: {
        affectedVehicles: 95,
        estimatedDelay: '5-10 mins',
        reportedBy: 'Camera System',
        trafficDensity: 50,
      },
    },
    {
      id: 'A-005',
      title: 'Moderate Congestion',
      location: 'JM Road',
      time: '1 hour ago',
      severity: 'low',
      description: 'Increased vehicle density',
      status: 'active',
      details: {
        affectedVehicles: 60,
        estimatedDelay: '5 mins',
        reportedBy: 'AI Analysis',
        trafficDensity: 35,
      },
    },
    {
      id: 'A-006',
      title: 'Weather Alert',
      location: 'City Wide',
      time: '2 hours ago',
      severity: 'low',
      description: 'Light rain expected',
      status: 'active',
      details: {
        affectedVehicles: 1200,
        estimatedDelay: 'Variable',
        reportedBy: 'Weather Service',
        trafficDensity: 40,
      },
    },
  ]);

  const getSeverityStyle = (severity: string) => {
    switch (severity) {
      case 'high':
        return {
          bg: isDark ? 'bg-[#d32f2f]/20' : 'bg-[#ffebee]',
          text: 'text-[#ef5350]',
          border: 'border-[#ef5350]',
          icon: 'text-[#ef5350]',
        };
      case 'medium':
        return {
          bg: isDark ? 'bg-[#ff9800]/20' : 'bg-[#fff3e0]',
          text: 'text-[#ff9800]',
          border: 'border-[#ff9800]',
          icon: 'text-[#ff9800]',
        };
      case 'low':
        return {
          bg: isDark ? 'bg-[#1976d2]/20' : 'bg-[#e3f2fd]',
          text: 'text-[#1976d2]',
          border: 'border-[#1976d2]',
          icon: 'text-[#1976d2]',
        };
      default:
        return {
          bg: isDark ? 'bg-gray-700' : 'bg-gray-100',
          text: isDark ? 'text-gray-300' : 'text-gray-700',
          border: 'border-gray-400',
          icon: isDark ? 'text-gray-400' : 'text-gray-600',
        };
    }
  };

  const getStatusStyle = (status: AlertStatus) => {
    switch (status) {
      case 'resolved':
        return { bg: 'bg-[#4caf50]/20', text: 'text-[#4caf50]', label: 'Resolved' };
      case 'in-progress':
        return { bg: 'bg-[#ff9800]/20', text: 'text-[#ff9800]', label: 'In Progress' };
      case 'unattended':
        return { bg: 'bg-[#ef5350]/20', text: 'text-[#ef5350]', label: 'Unattended' };
      default:
        return { bg: 'bg-[#1976d2]/20', text: 'text-[#1976d2]', label: 'Active' };
    }
  };

  const updateAlertStatus = (alertId: string, newStatus: AlertStatus) => {
    setAlerts(alerts.map(alert => 
      alert.id === alertId ? { ...alert, status: newStatus } : alert
    ));
    if (selectedAlert?.id === alertId) {
      setSelectedAlert({ ...selectedAlert, status: newStatus });
    }
  };

  const filteredAlerts = filter === 'all' 
    ? alerts 
    : alerts.filter(alert => alert.severity === filter);

  const activeCount = alerts.filter(a => a.status === 'active').length;
  const highSeverityCount = alerts.filter(a => a.severity === 'high' && a.status === 'active').length;
  const inProgressCount = alerts.filter(a => a.status === 'in-progress').length;
  const unattendedCount = alerts.filter(a => a.status === 'unattended').length;

  return (
    <div className="flex-1 overflow-y-auto pb-24 px-4 py-6">
      {/* Page Title */}
      <div className="mb-6">
        <h1 className={`mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
          Alerts & Notifications
        </h1>
        <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
          Real-time traffic and system alerts
        </p>
      </div>

      {/* Enhanced Summary Cards */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div
          className={`rounded-2xl p-5 relative overflow-hidden ${isDark ? 'bg-gradient-to-br from-[#1e1e1e] to-[#2a2a2a]' : 'bg-gradient-to-br from-white to-gray-50'}`}
          style={{ boxShadow: 'var(--shadow-lg)' }}
        >
          <div className="absolute top-2 right-2 opacity-10">
            <AlertTriangle className="w-16 h-16" />
          </div>
          <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Active Alerts
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <div className={`text-4xl ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
              {activeCount}
            </div>
            <TrendingUp className="w-4 h-4 text-[#ef5350]" />
          </div>
          <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
            Requires attention
          </div>
        </div>

        <div
          className={`rounded-2xl p-5 relative overflow-hidden ${isDark ? 'bg-gradient-to-br from-[#d32f2f]/20 to-[#b71c1c]/20' : 'bg-gradient-to-br from-[#ffebee] to-[#ffcdd2]'}`}
          style={{ boxShadow: 'var(--shadow-lg)' }}
        >
          <div className="absolute top-2 right-2 opacity-20">
            <Zap className="w-16 h-16 text-[#ef5350]" />
          </div>
          <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            High Priority
          </div>
          <div className="flex items-baseline gap-2 mb-1">
            <div className="text-4xl text-[#ef5350]">
              {highSeverityCount}
            </div>
            <div className="px-2 py-0.5 rounded-full bg-[#ef5350]/20 text-[#ef5350] text-xs">
              Critical
            </div>
          </div>
          <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
            Critical issues
          </div>
        </div>

        <div
          className={`rounded-2xl p-5 relative overflow-hidden ${isDark ? 'bg-gradient-to-br from-[#ff9800]/20 to-[#f57c00]/20' : 'bg-gradient-to-br from-[#fff3e0] to-[#ffe0b2]'}`}
          style={{ boxShadow: 'var(--shadow-lg)' }}
        >
          <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            In Progress
          </div>
          <div className="text-3xl text-[#ff9800] mb-1">
            {inProgressCount}
          </div>
          <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
            Being handled
          </div>
        </div>

        <div
          className={`rounded-2xl p-5 relative overflow-hidden ${isDark ? 'bg-gradient-to-br from-[#1976d2]/20 to-[#1565c0]/20' : 'bg-gradient-to-br from-[#e3f2fd] to-[#bbdefb]'}`}
          style={{ boxShadow: 'var(--shadow-lg)' }}
        >
          <div className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Unattended
          </div>
          <div className="text-3xl text-[#1976d2] mb-1">
            {unattendedCount}
          </div>
          <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>
            Awaiting response
          </div>
        </div>
      </div>

      {/* Filter Buttons */}
      <div
        className={`rounded-2xl p-2 mb-6 flex gap-2 ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
        style={{ boxShadow: 'var(--shadow)' }}
      >
        {[
          { label: 'All', value: 'all' as const },
          { label: 'High', value: 'high' as const },
          { label: 'Medium', value: 'medium' as const },
          { label: 'Low', value: 'low' as const },
        ].map((btn) => (
          <button
            key={btn.value}
            onClick={() => setFilter(btn.value)}
            className={`flex-1 py-2 px-3 rounded-xl text-sm transition-all ${
              filter === btn.value
                ? 'bg-gradient-to-r from-[#2e7d32] to-[#1b5e20] text-white shadow-md'
                : isDark
                ? 'text-gray-400 hover:bg-gray-800'
                : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            {btn.label}
          </button>
        ))}
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.length === 0 ? (
          <div
            className={`rounded-2xl p-8 text-center ${isDark ? 'bg-[#1e1e1e]' : 'bg-white'}`}
            style={{ boxShadow: 'var(--shadow)' }}
          >
            <AlertTriangle className={`w-12 h-12 mx-auto mb-3 ${isDark ? 'text-gray-600' : 'text-gray-400'}`} />
            <div className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              No alerts found
            </div>
          </div>
        ) : (
          filteredAlerts.map((alert) => {
            const style = getSeverityStyle(alert.severity);
            const statusStyle = getStatusStyle(alert.status);

            return (
              <div
                key={alert.id}
                className={`rounded-2xl p-5 border-l-4 transition-all ${style.border} ${
                  isDark ? 'bg-[#1e1e1e]' : 'bg-white'
                } ${alert.status === 'resolved' ? 'opacity-60' : ''}`}
                style={{ boxShadow: 'var(--shadow)' }}
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-start gap-3 flex-1">
                    <div className={`p-2 rounded-lg ${style.bg}`}>
                      <AlertTriangle className={`w-5 h-5 ${style.icon}`} />
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <h3 className={`text-sm ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                          {alert.title}
                        </h3>
                        <span className={`text-xs px-2 py-0.5 rounded-full ${statusStyle.bg} ${statusStyle.text}`}>
                          {statusStyle.label}
                        </span>
                      </div>
                      <p className={`text-xs mb-2 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                        {alert.description}
                      </p>
                      
                      <div className="flex items-center gap-4 text-xs">
                        <div className="flex items-center gap-1">
                          <MapPin className={`w-3 h-3 ${isDark ? 'text-gray-500' : 'text-gray-500'}`} />
                          <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                            {alert.location}
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-1">
                          <Clock className={`w-3 h-3 ${isDark ? 'text-gray-500' : 'text-gray-500'}`} />
                          <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>
                            {alert.time}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className={`px-3 py-1 rounded-full text-xs ${style.bg} ${style.text}`}>
                    {alert.severity.toUpperCase()}
                  </div>
                </div>

                <div className="flex gap-2 mt-4">
                  <button
                    onClick={() => setSelectedAlert(alert)}
                    className={`flex-1 py-2 px-4 rounded-xl border transition-all ${
                      isDark
                        ? 'border-gray-700 text-gray-300 hover:bg-gray-800'
                        : 'border-gray-300 text-gray-700 hover:bg-gray-50'
                    }`}
                  >
                    View Details
                  </button>
                  
                  {/* Status Dropdown */}
                  <select
                    value={alert.status}
                    onChange={(e) => updateAlertStatus(alert.id, e.target.value as AlertStatus)}
                    className={`flex-1 py-2 px-4 rounded-xl transition-all ${
                      isDark
                        ? 'bg-[#2e7d32] text-white hover:bg-[#1b5e20] border-none'
                        : 'bg-[#2e7d32] text-white hover:bg-[#1b5e20] border-none'
                    }`}
                    style={{ cursor: 'pointer' }}
                  >
                    <option value="active">Active</option>
                    <option value="in-progress">In Progress</option>
                    <option value="unattended">Unattended</option>
                    <option value="resolved">Resolved</option>
                  </select>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Alert Details Modal */}
      {selectedAlert && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div
            className={`w-full max-w-md rounded-3xl p-6 ${
              isDark ? 'bg-[#1e1e1e]' : 'bg-white'
            }`}
            style={{ boxShadow: 'var(--shadow-lg)' }}
          >
            {/* Header */}
            <div className="flex items-start justify-between mb-5">
              <div className="flex-1">
                <h2 className={`text-lg mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                  Alert Details
                </h2>
                <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                  {selectedAlert.id}
                </p>
              </div>
              <button
                onClick={() => setSelectedAlert(null)}
                className={`p-2 rounded-xl ${
                  isDark ? 'hover:bg-gray-800' : 'hover:bg-gray-100'
                }`}
              >
                <X className={`w-5 h-5 ${isDark ? 'text-gray-400' : 'text-gray-600'}`} />
              </button>
            </div>

            {/* Alert Title */}
            <div className={`mb-5 p-4 rounded-xl ${getSeverityStyle(selectedAlert.severity).bg}`}>
              <div className="flex items-center gap-3">
                <AlertTriangle className={`w-6 h-6 ${getSeverityStyle(selectedAlert.severity).icon}`} />
                <div className="flex-1">
                  <h3 className={`text-sm mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>
                    {selectedAlert.title}
                  </h3>
                  <p className={`text-xs ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
                    {selectedAlert.description}
                  </p>
                </div>
              </div>
            </div>

            {/* Details Grid */}
            <div className="grid grid-cols-2 gap-3 mb-5">
              <div className={`p-3 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
                <div className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                  Location
                </div>
                <div className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                  {selectedAlert.location}
                </div>
              </div>

              <div className={`p-3 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
                <div className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                  Reported
                </div>
                <div className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                  {selectedAlert.time}
                </div>
              </div>

              <div className={`p-3 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
                <div className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                  Affected Vehicles
                </div>
                <div className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                  {selectedAlert.details?.affectedVehicles}
                </div>
              </div>

              <div className={`p-3 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
                <div className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                  Estimated Delay
                </div>
                <div className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                  {selectedAlert.details?.estimatedDelay}
                </div>
              </div>

              <div className={`p-3 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
                <div className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                  Traffic Density
                </div>
                <div className="flex items-center gap-2">
                  <div className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                    {selectedAlert.details?.trafficDensity}%
                  </div>
                  <div className={`flex-1 h-1.5 rounded-full ${isDark ? 'bg-gray-700' : 'bg-gray-200'}`}>
                    <div
                      className="h-1.5 rounded-full bg-[#ff9800]"
                      style={{ width: `${selectedAlert.details?.trafficDensity}%` }}
                    />
                  </div>
                </div>
              </div>

              <div className={`p-3 rounded-xl ${isDark ? 'bg-gray-800' : 'bg-gray-50'}`}>
                <div className={`text-xs mb-1 ${isDark ? 'text-gray-500' : 'text-gray-600'}`}>
                  Reported By
                </div>
                <div className={`text-sm ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>
                  {selectedAlert.details?.reportedBy}
                </div>
              </div>
            </div>

            {/* Actions */}
            <button
              onClick={() => setSelectedAlert(null)}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-[#2e7d32] to-[#1b5e20] text-white hover:shadow-lg transition-all"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {/* Load More */}
      {filteredAlerts.length > 0 && (
        <button
          className={`w-full mt-6 py-3 rounded-xl border-2 transition-all ${
            isDark
              ? 'border-gray-700 text-gray-300 hover:bg-gray-800'
              : 'border-gray-300 text-gray-700 hover:bg-gray-50'
          }`}
        >
          Load More Alerts
        </button>
      )}
    </div>
  );
}
