import { MapPin, Leaf, Wind, TrendingUp, AlertTriangle, ArrowRight, Zap } from 'lucide-react';
import { useState } from 'react';
import type { PageType } from '../App';

interface HomePageProps {
  navigateTo: (page: PageType) => void;
  isDark?: boolean;
}

export function HomePage({ navigateTo, isDark }: HomePageProps) {
  const [currentStreak] = useState(7);
  const [todayScore] = useState(85);

  // AQI levels: Good (0-50), Moderate (51-100), Unhealthy (101-150), etc.
  const aqi = 45;
  const aqiStatus = aqi <= 50 ? 'Good' : aqi <= 100 ? 'Moderate' : 'Unhealthy';
  const aqiColor = aqi <= 50 ? 'bg-green-500' : aqi <= 100 ? 'bg-yellow-500' : 'bg-red-500';

  return (
    <div className="flex-1 overflow-y-auto pb-20">
      {/* Top Bar - Location & AQI */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-5 py-8">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-start gap-3 flex-1 min-w-0">
            <MapPin className="w-5 h-5 mt-1 flex-shrink-0" />
            <div className="min-w-0">
              <div className="text-xs opacity-90 mb-1">Current Location</div>
              <div className="text-base truncate">FC Road, Pune</div>
            </div>
          </div>
          
          {/* AQI Badge */}
          <div className="bg-white bg-opacity-20 backdrop-blur-sm rounded-2xl px-4 py-3 min-w-[90px]">
            <div className="text-xs opacity-90 mb-1 text-center">AQI</div>
            <div className="flex items-center justify-center gap-2 mb-1">
              <div className={`w-2 h-2 rounded-full ${aqiColor}`}></div>
              <span className="text-xl">{aqi}</span>
            </div>
            <div className="text-xs text-center">{aqiStatus}</div>
          </div>
        </div>
      </div>

      {/* Main Content Cards */}
      <div className="px-5 py-6 space-y-5">
        {/* Quick Route Card */}
        <div 
          onClick={() => navigateTo('map')}
          className={`rounded-2xl shadow-lg border p-6 hover:shadow-xl transition-all cursor-pointer ${
            isDark 
              ? 'bg-gray-800 border-gray-700' 
              : 'bg-white border-gray-200'
          }`}
        >
          <div className="flex items-start justify-between mb-5">
            <div className="flex items-start gap-4 flex-1">
              <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-green-600 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md">
                <Zap className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1 pt-1">
                <h3 className={`text-lg mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>Quick Route</h3>
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>Eco-friendly route to home</p>
              </div>
            </div>
            <ArrowRight className={`w-5 h-5 mt-4 ${isDark ? 'text-gray-500' : 'text-gray-400'}`} />
          </div>
          
          <div className="grid grid-cols-2 gap-4 mb-5">
            <div>
              <div className={`text-xs mb-1 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>Estimated time</div>
              <div className={`text-base ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>18 mins</div>
            </div>
            <div>
              <div className={`text-xs mb-1 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>CO₂ saved</div>
              <div className="text-base text-green-600">420g</div>
            </div>
          </div>
          
          <button className="w-full bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white py-3.5 rounded-xl transition-all shadow-md hover:shadow-lg mt-5">
          &nbsp;&nbsp;Start Navigation
          </button>
        </div>

        {/* Quiet Walks Card */}
        <div 
          onClick={() => navigateTo('map')}
          className={`rounded-2xl shadow-lg border p-6 hover:shadow-xl transition-all cursor-pointer ${
            isDark 
              ? 'bg-gray-800 border-gray-700' 
              : 'bg-white border-gray-200'
          }`}
        >
          <div className="flex items-start justify-between mb-5">
            <div className="flex items-start gap-4 flex-1">
              <div className="w-14 h-14 bg-gradient-to-br from-purple-500 to-purple-600 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md">
                <Wind className="w-7 h-7 text-white" />
              </div>
              <div className="flex-1 pt-1">
                <h3 className={`text-lg mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>Quiet Walks</h3>
                <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>Best time: 6:30 AM - 7:30 AM</p>
              </div>
            </div>
            <ArrowRight className={`w-5 h-5 mt-4 ${isDark ? 'text-gray-500' : 'text-gray-400'}`} />
          </div>
          
          <div className="space-y-3 mb-5">
            <div className="flex items-center justify-between text-sm">
              <span className={isDark ? 'text-gray-400' : 'text-gray-600'}>Noise Level</span>
              <span className="text-green-600">Low (35 dB)</span>
            </div>
            <div className={`w-full rounded-full h-2.5 ${isDark ? 'bg-gray-700' : 'bg-gray-200'}`}>
              <div className="bg-gradient-to-r from-green-500 to-green-600 h-2.5 rounded-full shadow-sm" style={{ width: '30%' }}></div>
            </div>
          </div>
          
          <button className="w-full bg-gradient-to-r from-purple-600 to-purple-700 hover:from-purple-700 hover:to-purple-800 text-white py-3.5 rounded-xl transition-all shadow-md hover:shadow-lg mt-5">
          &nbsp;&nbsp;Explore Routes
          </button>
        </div>

        {/* Today's Score Card */}
        <div className="bg-gradient-to-br from-blue-600 via-blue-700 to-blue-800 rounded-2xl shadow-xl p-6 text-white">
          <div className="flex items-start gap-4 mb-6">
            <div className="w-14 h-14 bg-white bg-opacity-20 backdrop-blur-sm rounded-2xl flex items-center justify-center flex-shrink-0 shadow-lg">
              <Leaf className="w-7 h-7 text-white" />
            </div>
            <div className="flex-1 pt-1">
              <h3 className="text-lg mb-1">Today's Score</h3>
              <p className="text-sm text-blue-100">Keep up the great work!</p>
            </div>
          </div>
          
          <div className="flex items-end gap-8 mb-5">
            {/* Score Meter */}
            <div className="flex-1">
              <div className="text-xs text-blue-100 mb-2">Sustainability Points</div>
              <div className="text-5xl mb-3">{todayScore}</div>
              <div className="flex items-center gap-2 text-blue-100 text-sm">
                <TrendingUp className="w-4 h-4" />
                <span>+12 from yesterday</span>
              </div>
            </div>
            
            {/* Streak */}
            <div className="text-center">
              <div className="w-20 h-20 bg-white bg-opacity-20 backdrop-blur-sm rounded-2xl flex items-center justify-center mb-2 shadow-lg">
                <div className="text-3xl">🔥</div>
              </div>
              <div className="text-sm text-blue-100">{currentStreak} day streak</div>
            </div>
          </div>
          
          <div className="w-full bg-white bg-opacity-20 backdrop-blur-sm rounded-full h-3 shadow-inner">
            <div className="bg-white h-3 rounded-full shadow-md transition-all" style={{ width: `${todayScore}%` }}></div>
          </div>
        </div>

        {/* Alerts Card */}
        <div 
          className={`rounded-2xl shadow-lg border-2 p-6 hover:shadow-xl transition-all ${
            isDark 
              ? 'bg-gray-800 border-orange-900' 
              : 'bg-white border-orange-200'
          }`}
        >
          <div className="flex items-start gap-4 mb-5">
            <div className={`w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0 shadow-md ${
              isDark ? 'bg-orange-900/50' : 'bg-orange-100'
            }`}>
              <AlertTriangle className="w-7 h-7 text-orange-600" />
            </div>
            <div className="flex-1 pt-1">
              <h3 className={`text-lg mb-1 ${isDark ? 'text-gray-100' : 'text-gray-900'}`}>Active Alerts</h3>
              <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>2 alerts in your area</p>
            </div>
          </div>
          
          <div className="space-y-3 mb-5">
            <div className={`flex items-start gap-3 p-4 rounded-xl ${
              isDark ? 'bg-orange-900/30' : 'bg-orange-50'
            }`}>
              <div className="w-2 h-2 bg-orange-500 rounded-full mt-1.5 flex-shrink-0"></div>
              <div className="flex-1 min-w-0">
                <div className={`text-sm mb-1 ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>Heavy traffic on FC Road</div>
                <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>Updated 5 mins ago</div>
              </div>
            </div>
            
            <div className={`flex items-start gap-3 p-4 rounded-xl ${
              isDark ? 'bg-yellow-900/30' : 'bg-yellow-50'
            }`}>
              <div className="w-2 h-2 bg-yellow-500 rounded-full mt-1.5 flex-shrink-0"></div>
              <div className="flex-1 min-w-0">
                <div className={`text-sm mb-1 ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>AQI rising in Shivajinagar</div>
                <div className={`text-xs ${isDark ? 'text-gray-500' : 'text-gray-500'}`}>Updated 12 mins ago</div>
              </div>
            </div>
          </div>
          
          <button className="w-full border-2 border-orange-600 text-orange-600 hover:bg-orange-600 hover:text-white py-3.5 rounded-xl transition-all shadow-md mt-5">
          &nbsp;&nbsp;View All Alerts
          </button>
        </div>

        {/* Quick Actions Grid */}
        <div className="grid grid-cols-2 gap-4">
          <button 
            onClick={() => navigateTo('map')}
            className={`rounded-2xl shadow-lg border p-5 hover:shadow-xl transition-all ${
              isDark 
                ? 'bg-gray-800 border-gray-700' 
                : 'bg-white border-gray-200'
            }`}
          >
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 mx-auto shadow-md ${
              isDark ? 'bg-blue-900/50' : 'bg-blue-100'
            }`}>
              <MapPin className="w-6 h-6 text-blue-600" />
            </div>
            <div className={`text-sm text-center ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>Saved Places</div>
          </button>
          
          <button 
            onClick={() => navigateTo('profile')}
            className={`rounded-2xl shadow-lg border p-5 hover:shadow-xl transition-all ${
              isDark 
                ? 'bg-gray-800 border-gray-700' 
                : 'bg-white border-gray-200'
            }`}
          >
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 mx-auto shadow-md ${
              isDark ? 'bg-green-900/50' : 'bg-green-100'
            }`}>
              <Leaf className="w-6 h-6 text-green-600" />
            </div>
            <div className={`text-sm text-center ${isDark ? 'text-gray-200' : 'text-gray-900'}`}>My Impact</div>
          </button>
        </div>
      </div>
    </div>
  );
}
