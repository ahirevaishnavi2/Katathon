import { useEffect } from 'react';
import logoImage from 'figma:asset/7d2f3bc2a6f01951ff61d51e3f541feb142273c0.png';

interface SplashScreenProps {
  onComplete: () => void;
}

export default function SplashScreen({ onComplete }: SplashScreenProps) {
  useEffect(() => {
    const timer = setTimeout(() => {
      onComplete();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onComplete]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#2e7d32] via-[#1976d2] to-[#0d47a1] flex flex-col items-center justify-center p-6">
      {/* Animated Logo */}
      <div className="relative mb-8">
        <div className="absolute inset-0 bg-white/20 rounded-full blur-3xl animate-pulse" />
        <img 
          src={logoImage} 
          alt="GATYAH Logo" 
          className="w-32 h-32 object-contain relative z-10 animate-in zoom-in duration-1000"
        />
      </div>

      {/* App Name */}
      <h1 className="text-white text-4xl mb-2 animate-in fade-in slide-in-from-bottom-4 duration-700">
        Gyatah
      </h1>
      <p className="text-white/80 text-lg mb-12 animate-in fade-in slide-in-from-bottom-4 duration-700 delay-200">
        Smart Traffic Management
      </p>

      {/* Loading Animation */}
      <div className="flex gap-2 animate-in fade-in duration-700 delay-500">
        <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
        <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
        <div className="w-3 h-3 bg-white rounded-full animate-bounce" style={{ animationDelay: '0.4s' }} />
      </div>

      {/* Tagline */}
      <p className="absolute bottom-12 text-white/60 text-sm animate-in fade-in duration-700 delay-1000">
        Where Motion Is Intelligent
      </p>
    </div>
  );
}