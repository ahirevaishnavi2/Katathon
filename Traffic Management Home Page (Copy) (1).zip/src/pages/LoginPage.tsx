import { useState } from 'react';
import { Mail, Lock, Eye, EyeOff, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import logoImage from 'figma:asset/7d2f3bc2a6f01951ff61d51e3f541feb142273c0.png';

interface LoginPageProps {
  onLogin: () => void;
  onNavigateToSignup: () => void;
  isDark: boolean;
}

export function LoginPage({ onLogin, onNavigateToSignup, isDark }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onLogin();
  };

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? 'bg-[#121212]' : 'bg-[#f5f7fa]'}`}>
      {/* Header with Logo */}
      <div className="p-6 flex justify-center">
        <div className="flex flex-col items-center">
          <img src={logoImage} alt="GATYAH Logo" className="w-20 h-20 mb-3" />
          <h1 className={`text-2xl ${isDark ? 'text-white' : 'text-[#333333]'}`}>GATYAH</h1>
          <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Where Motion Is Intelligent
          </p>
        </div>
      </div>

      {/* Login Form */}
      <div className="flex-1 flex items-center justify-center px-6 pb-12">
        <div className="w-full max-w-md">
          <div
            className={`rounded-2xl p-8 shadow-lg ${
              isDark ? 'bg-[#1e1e1e]' : 'bg-white'
            }`}
            style={{ boxShadow: isDark ? '0 10px 30px rgba(0,0,0,0.3)' : '0 10px 30px rgba(0,0,0,0.08)' }}
          >
            <h2 className={`text-2xl mb-2 ${isDark ? 'text-white' : 'text-[#333333]'}`}>
              Welcome Back
            </h2>
            <p className={`mb-8 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Sign in to continue to your account
            </p>

            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Email Input */}
              <div>
                <label className={`block mb-2 ${isDark ? 'text-gray-300' : 'text-[#333333]'}`}>
                  Email
                </label>
                <div className="relative">
                  <Mail className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} />
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your.email@example.com"
                    className={`pl-12 h-12 rounded-xl ${
                      isDark 
                        ? 'bg-[#121212] border-[#333333] text-white placeholder:text-gray-500' 
                        : 'bg-[#f5f7fa] border-[#e0e0e0] text-[#333333]'
                    }`}
                    required
                  />
                </div>
              </div>

              {/* Password Input */}
              <div>
                <label className={`block mb-2 ${isDark ? 'text-gray-300' : 'text-[#333333]'}`}>
                  Password
                </label>
                <div className="relative">
                  <Lock className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} />
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className={`pl-12 pr-12 h-12 rounded-xl ${
                      isDark 
                        ? 'bg-[#121212] border-[#333333] text-white placeholder:text-gray-500' 
                        : 'bg-[#f5f7fa] border-[#e0e0e0] text-[#333333]'
                    }`}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className={`absolute right-3 top-1/2 -translate-y-1/2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Forgot Password */}
              <div className="text-right">
                <button
                  type="button"
                  className="text-[#1976d2] hover:underline"
                >
                  Forgot Password?
                </button>
              </div>

              {/* Login Button */}
              <Button
                type="submit"
                className="w-full h-12 rounded-xl bg-[#2e7d32] hover:bg-[#1b5e20] text-white"
                style={{ transition: 'all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)' }}
              >
                Sign In
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </form>

            {/* Sign Up Link */}
            <div className={`mt-6 text-center ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Don't have an account?{' '}
              <button
                onClick={onNavigateToSignup}
                className="text-[#1976d2] hover:underline"
              >
                Sign Up
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
