import { useState } from 'react';
import { Mail, Lock, User, Eye, EyeOff, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import logoImage from 'figma:asset/7d2f3bc2a6f01951ff61d51e3f541feb142273c0.png';

interface SignupPageProps {
  onSignup: () => void;
  onNavigateToLogin: () => void;
  isDark: boolean;
}

export function SignupPage({ onSignup, onNavigateToLogin, isDark }: SignupPageProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === confirmPassword) {
      onSignup();
    }
  };

  return (
    <div className={`min-h-screen flex flex-col ${isDark ? 'bg-[#121212]' : 'bg-[#f5f7fa]'}`}>
      {/* Header with Logo */}
      <div className="p-6 flex justify-center">
        <div className="flex flex-col items-center">
          <img src={logoImage} alt="GATYAH Logo" className="w-20 h-20 mb-3" />
          <h1 className={`text-2xl ${isDark ? 'text-white' : 'text-[#333333]'}`}>GATYAH</h1>
          <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
            Where Motion Is Intelligent
          </p>
        </div>
      </div>

      {/* Signup Form */}
      <div className="flex-1 flex items-center justify-center px-6 pb-12">
        <div className="w-full max-w-md">
          <div
            className={`rounded-2xl p-8 shadow-lg ${
              isDark ? 'bg-[#1e1e1e]' : 'bg-white'
            }`}
            style={{ boxShadow: isDark ? '0 10px 30px rgba(0,0,0,0.3)' : '0 10px 30px rgba(0,0,0,0.08)' }}
          >
            <h2 className={`text-2xl mb-2 ${isDark ? 'text-white' : 'text-[#333333]'}`}>
              Create Account
            </h2>
            <p className={`mb-6 ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Sign up to get started with GATYAH
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Name Input */}
              <div>
                <label className={`block mb-2 ${isDark ? 'text-gray-300' : 'text-[#333333]'}`}>
                  Full Name
                </label>
                <div className="relative">
                  <User className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} />
                  <Input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="John Doe"
                    className={`pl-12 h-12 rounded-xl ${
                      isDark 
                        ? 'bg-[#121212] border-[#333333] text-white placeholder:text-gray-500' 
                        : 'bg-[#f5f7fa] border-[#e0e0e0] text-[#333333]'
                    }`}
                    required
                  />
                </div>
              </div>

              {/* Email Input */}
              <div>
                <label className={`block mb-2 ${isDark ? 'text-gray-300' : 'text-[#333333]'}`}>
                  Email
                </label>
                <div className="relative">
                  <Mail className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} />
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="your.email@example.com"
                    className={`pl-12 h-12 rounded-xl ${
                      isDark 
                        ? 'bg-[#121212] border-[#333333] text-white placeholder:text-gray-500' 
                        : 'bg-[#f5f7fa] border-[#e0e0e0] text-[#333333]'
                    }`}
                    required
                  />
                </div>
              </div>

              {/* Password Input */}
              <div>
                <label className={`block mb-2 ${isDark ? 'text-gray-300' : 'text-[#333333]'}`}>
                  Password
                </label>
                <div className="relative">
                  <Lock className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} />
                  <Input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Create a password"
                    className={`pl-12 pr-12 h-12 rounded-xl ${
                      isDark 
                        ? 'bg-[#121212] border-[#333333] text-white placeholder:text-gray-500' 
                        : 'bg-[#f5f7fa] border-[#e0e0e0] text-[#333333]'
                    }`}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className={`absolute right-3 top-1/2 -translate-y-1/2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Confirm Password Input */}
              <div>
                <label className={`block mb-2 ${isDark ? 'text-gray-300' : 'text-[#333333]'}`}>
                  Confirm Password
                </label>
                <div className="relative">
                  <Lock className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${isDark ? 'text-gray-400' : 'text-gray-500'}`} />
                  <Input
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="Confirm your password"
                    className={`pl-12 pr-12 h-12 rounded-xl ${
                      isDark 
                        ? 'bg-[#121212] border-[#333333] text-white placeholder:text-gray-500' 
                        : 'bg-[#f5f7fa] border-[#e0e0e0] text-[#333333]'
                    }`}
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className={`absolute right-3 top-1/2 -translate-y-1/2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}
                  >
                    {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Sign Up Button */}
              <Button
                type="submit"
                className="w-full h-12 rounded-xl bg-[#2e7d32] hover:bg-[#1b5e20] text-white mt-6"
                style={{ transition: 'all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275)' }}
              >
                Create Account
                <ArrowRight className="ml-2 w-5 h-5" />
              </Button>
            </form>

            {/* Login Link */}
            <div className={`mt-6 text-center ${isDark ? 'text-gray-400' : 'text-gray-600'}`}>
              Already have an account?{' '}
              <button
                onClick={onNavigateToLogin}
                className="text-[#1976d2] hover:underline"
              >
                Sign In
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
